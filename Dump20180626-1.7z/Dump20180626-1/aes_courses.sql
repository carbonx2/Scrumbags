-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: localhost    Database: aes
-- ------------------------------------------------------
-- Server version	8.0.11

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `courses`
--

DROP TABLE IF EXISTS `courses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `courses` (
  `ID` varchar(2) NOT NULL,
  `Subject` varchar(2) DEFAULT NULL,
  `Name` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `FK_Subject_idx` (`Subject`),
  CONSTRAINT `FK_Subject1` FOREIGN KEY (`Subject`) REFERENCES `subjects` (`id`)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci ;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `courses`
--

LOCK TABLES `courses` WRITE;
/*!40000 ALTER TABLE `courses` DISABLE KEYS */;
INSERT INTO `courses` VALUES ('00','02','Algebra1'),('01','02','Calculus'),('02','02','Differential and Integral Calculus'),('03','02','Algebra2'),('04','02','Euclidean geometry'),('05','02','Discrete mathematics'),('06','01','DNA Sequences'),('07','01','Natural Selection'),('08','01','Genetics'),('09','01','Metabolism and enzymology'),('10','01','Basic Pharmacology'),('11','01','Molecular biology'),('12','03','Introduction to Modern Art'),('13','03','Symbolism'),('14','03','Medieval Art'),('15','03','Pablo Picasso-Cubism'),('16','03','Surrealism'),('17','03','the history of art'),('18','04','Matam'),('19','04','Malam'),('20','04','Atam'),('21','04','Algorithms'),('22','04','Operating Systems'),('23','04','Automata and computation'),('24','05','psychology'),('25','05','sociology'),('26','05','Theology'),('27','05','linguistics'),('28','05','economy'),('29','05','human resource manager'),('30','06','football'),('31','06','basketball'),('32','06','yoga'),('33','06','Pilates'),('34','06','Running Marathon'),('35','06','Baseball');
/*!40000 ALTER TABLE `courses` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-06-26 15:02:24
