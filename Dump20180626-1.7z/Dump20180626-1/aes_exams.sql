-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: localhost    Database: aes
-- ------------------------------------------------------
-- Server version	8.0.11

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `exams`
--

DROP TABLE IF EXISTS `exams`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exams` (
  `ID` varchar(6) NOT NULL,
  `Course` varchar(2) DEFAULT NULL,
  `Subject` varchar(2) DEFAULT NULL,
  `Author` varchar(9) DEFAULT NULL,
  `CreationDate` varchar(10) DEFAULT NULL,
  `ExamTime` int(11) DEFAULT NULL,
  `Note` text,
  `Available` int(11) DEFAULT '1',
  PRIMARY KEY (`ID`),
  KEY `eSubject_idx` (`Subject`),
  KEY `eCourse_idx` (`Course`),
  KEY `FK_Author_idx` (`Author`),
  CONSTRAINT `FK_Author` FOREIGN KEY (`Author`) REFERENCES `teachers` (`id`),
  CONSTRAINT `FK_Course` FOREIGN KEY (`Course`) REFERENCES `courses` (`id`),
  CONSTRAINT `FK_Subject` FOREIGN KEY (`Subject`) REFERENCES `subjects` (`id`)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci ;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exams`
--

LOCK TABLES `exams` WRITE;
/*!40000 ALTER TABLE `exams` DISABLE KEYS */;
INSERT INTO `exams` VALUES ('010600','06','01','307862557','26/06/2018',3,'',1),('010700','07','01','307862557','24/06/2018',3,'You Can do it!!!',1),('020000','00','02','313740664','24/06/2018',5,'Luck YOu!',1),('020100','01','02','307862557','24/06/2018',5,'Good luck Students!',1),('020300','03','02','307862557','26/06/2018',3,'Testing',1),('020500','05','02','313740664','24/06/2018',4,'',1),('031300','13','03','307862557','24/06/2018',2,'',1),('041800','18','04','204677736','26/06/2018',5,'Good luckkk',1),('042000','20','04','204677736','24/06/2018',2,'',1),('042001','20','04','204677736','24/06/2018',5,'luck',1),('042200','22','04','307862557','24/06/2018',2,'I love Operting System !',1),('052600','26','05','204677736','26/06/2018',5,'',1),('052601','26','05','204677736','26/06/2018',5,'Good luck students!',1),('052700','27','05','307862557','26/06/2018',4,'',1),('052800','28','05','204677736','24/06/2018',10,'',1),('052801','28','05','204677736','24/06/2018',15,'',1),('052802','28','05','204677736','24/06/2018',2,'',1),('063100','31','06','204677736','24/06/2018',5,'',1),('063101','31','06','204677736','24/06/2018',4,'Godd luck :\n\nDo not be nervous',1),('063200','32','06','204677736','24/06/2018',3,'',1),('063300','33','06','307862557','24/06/2018',10,'',1),('063301','33','06','313740664','24/06/2018',3,'',1),('063400','34','06','204677736','24/06/2018',10,'Good Luck!',1);
/*!40000 ALTER TABLE `exams` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-06-26 15:02:25
