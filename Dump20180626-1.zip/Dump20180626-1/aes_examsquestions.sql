-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: localhost    Database: aes
-- ------------------------------------------------------
-- Server version	8.0.11

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `examsquestions`
--

DROP TABLE IF EXISTS `examsquestions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `examsquestions` (
  `Exam` varchar(6) NOT NULL,
  `Question` varchar(5) NOT NULL,
  `Score` int(11) DEFAULT NULL,
  `NoteForStudent` tinytext,
  `NoteForTeacher` tinytext,
  PRIMARY KEY (`Exam`,`Question`),
  KEY `FK_Question_idx` (`Question`),
  CONSTRAINT `FK_Exam` FOREIGN KEY (`Exam`) REFERENCES `exams` (`id`) ON DELETE CASCADE,
  CONSTRAINT `FK_Question` FOREIGN KEY (`Question`) REFERENCES `questions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `examsquestions`
--

LOCK TABLES `examsquestions` WRITE;
/*!40000 ALTER TABLE `examsquestions` DISABLE KEYS */;
INSERT INTO `examsquestions` VALUES ('010600','01002',40,'null','null'),('010600','01003',35,'null','null'),('010600','01004',25,'goos luck','null'),('010700','01002',25,'null','null'),('010700','01003',25,'null','null'),('010700','01004',25,'null','null'),('010700','01005',25,'null','null'),('020000','02001',50,'null','null'),('020000','02002',50,'null','null'),('020100','02001',25,'null','null'),('020100','02002',75,'null','Good luck!'),('020300','02001',65,'null','very nice'),('020300','02002',35,'null','null'),('020500','02002',40,'easy','good luck'),('020500','02003',60,'null','null'),('031300','03003',25,'null','null'),('031300','03004',25,'null','null'),('031300','03005',25,'null','null'),('031300','03007',25,'null','null'),('041800','04000',40,'null','null'),('041800','04001',30,'null','null'),('041800','04002',30,'null','null'),('042000','04002',50,'null','null'),('042000','04003',50,'null','null'),('042001','04000',40,'null','null'),('042001','04001',20,'hard','null'),('042001','04002',20,'null','null'),('042001','04003',20,'null','null'),('042200','04000',30,'null','null'),('042200','04001',20,'null','good luck!'),('042200','04002',50,'null','You Know!'),('052600','05005',45,'null','null'),('052600','05006',20,'null','null'),('052600','05007',35,'null','null'),('052601','05001',20,'null','null'),('052601','05004',35,'null','null'),('052601','05006',30,'null','null'),('052601','05011',15,'null','null'),('052700','05001',30,'null','null'),('052700','05002',16,'nice','null'),('052700','05005',27,'null','null'),('052700','05007',27,'null','null'),('052800','05002',25,'null','A L P H A'),('052800','05006',25,'null','null'),('052800','05010',25,'null','null'),('052800','05011',25,'null','null'),('052801','05003',20,'null','null'),('052801','05006',20,'null','null'),('052801','05009',20,'null','null'),('052801','05010',20,'null','null'),('052801','05011',20,'null','null'),('052802','05004',20,'null','null'),('052802','05005',20,'null','null'),('052802','05006',30,'null','null'),('052802','05007',10,'null','null'),('052802','05008',20,'null','null'),('063100','06004',25,'null','null'),('063100','06005',25,'null','null'),('063100','06007',25,'null','null'),('063100','06009',25,'null','null'),('063101','06006',20,'null','null'),('063101','06007',50,'Easy! gift','null'),('063101','06008',30,'null','null'),('063200','06002',25,'null','null'),('063200','06003',25,'null','null'),('063200','06005',25,'null','null'),('063200','06007',25,'null','null'),('063300','06001',25,'null','null'),('063300','06002',25,'null','null'),('063300','06003',25,'null','null'),('063300','06004',25,'null','null'),('063301','06000',25,'null','null'),('063301','06001',25,'null','null'),('063301','06006',25,'null','null'),('063301','06007',25,'null','null'),('063400','06001',25,'hard!','null'),('063400','06005',25,'null','null'),('063400','06007',10,'null','null'),('063400','06008',25,'goo gane','null'),('063400','06009',15,'null','null');
/*!40000 ALTER TABLE `examsquestions` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-06-26 15:02:22
