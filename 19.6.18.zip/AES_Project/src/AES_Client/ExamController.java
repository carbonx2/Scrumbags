package AES_Client;

import java.util.ArrayList;
import java.util.HashMap;

import AES_Classes.Exam;
import AES_Classes.Examinee;
import AES_Classes.FinishedExam;
import AES_Classes.ManualExamFile;
import AES_Classes.Packet;
import AES_Classes.Student;
import ClientGUI.MainClient;;

public class ExamController {
	
	public static final int examResponseRequest = -1;
	
	/**
	   * This method adding exam to Data base
	   *
	   * @param exam The exam we want to add
	   * Build packet with the exam and add exam request
	   * Send this packet to server by client 
	   * @return response of request
	   */
	public static String addExamToRepository(Exam exam) {
		Packet packet = new Packet("AddExam", exam);
		int requestID = MainClient.client.sendToServerAJ(packet);
		return MainClient.client.getResponse(requestID).getOperation();
	}
	/**
	   * This method get list of exam from Data base
	   *
	   * Build packet with GetExamsList request
	   * Send this packet to server by client 
	   * @return list of exam in the data base
	   */
	public static ArrayList<Exam> getExamsList() {
		Packet packet = new Packet("GetExamsList", null);
		int requestID = MainClient.client.sendToServerAJ(packet);
		return (ArrayList<Exam>) MainClient.client.getResponse(requestID).getData();
	}
	/**
	   * This method get list of exam from Data base by the subject id
	   *
	   * Build packet with GetExamsList request and subject id
	   * Send this packet to server by client 
	   * @return list of exam in the data base by the selected subject id
	   */
	public static ArrayList<Exam> getExamsListBySubject(String subject) {
		Packet packet = new Packet("GetExamsListBySubject", subject);
		int requestID = MainClient.client.sendToServerAJ(packet);
		return (ArrayList<Exam>) MainClient.client.getResponse(requestID).getData();
	}
	/**
	   * This method removing exam from Data base
	   *
	   * @param exam The exam we want to remove
	   * Build packet with the exam and RemoveExam request
	   * Send this packet to server by client 
	   * @return response of request
	   */
	public static String removeExam(String examID) {
		Packet packet = new Packet("RemoveExam", examID);
		int requestID = MainClient.client.sendToServerAJ(packet);
		return MainClient.client.getResponse(requestID).getOperation();
	}
	/**
	   * This method add exam to activate exam in Data base
	   * @param executionCode The exam code that we want to add
	   * @param exam The exam we want to add
	   * @param teacherID The teacher that execute the exam id
	   *  packet with the exam , exam code execute , who execute the exam and RemoveExam request
	   * Send this packet to server by client 
	   * @return if success to add exam
	   */	
	public static boolean executeExam(String executionCode,Exam exam, String teacherID)
	{
		ArrayList<Object> data = new ArrayList<Object>();
		data.add(executionCode);
		data.add(exam);
		data.add(teacherID);
		Packet packet = new Packet("ExecuteExam", data);
		int requestID = MainClient.client.sendToServerAJ(packet);
		String response = MainClient.client.getResponse(requestID).getOperation();
		if(response.equals("Success"))
			return true;
		return false;
	}
	/**
	   * This method verify the exam code in active exams
	   * @param examCode The exam code to verify
	   * @param studentID The student that want to take exam id
	   *  packet with the exam code  , who wants to take exam by this code and CheckExamCode request
	   * Send this packet to server by client 
	   * @return response of the request
	   */	
	public static String checkExamCode(String examCode, String studentID)
	{
		ArrayList <String> data = new ArrayList<String>();
		data.add(examCode);
		data.add(studentID);
		Packet packet = new Packet("CheckExamCode",data);
		int requestID = MainClient.client.sendToServerAJ(packet);
		return MainClient.client.getResponse(requestID).getOperation();
		
	}
	/**
	   * This method return exam to student by exam code
	   * @param examCode The exam code to take 
	   *  packet with the exam code and TakeExam request
	   * @return The exam student want to take
	   */		
	public static Exam takeExam(String examCode)	{
		
		Packet packet = new Packet("TakeExam", examCode);
		int requestID = MainClient.client.sendToServerAJ(packet);
		return (Exam) MainClient.client.getResponse(requestID).getData();		
			
		
	}
	/**
	   * This method begins student exam
	   * @param student The student who to the exam
	   * @param exam The student exam
	   * @param examExecutionCode The code of this exam
	   *  packet with the exam code  , who wants to take exam by this code, the specific exam and StartExam request
	   * Send this packet to server by client 
	   * @return response of the request
	   * @return examine of the required exam
	   */	
	public static ArrayList<Object> startExam(Student student, Exam exam, String examExecutionCode)
	{
		
		ArrayList<Object> data = new ArrayList<Object>();
		data.add(student);
		data.add(exam);
		data.add(examExecutionCode);
		Packet packet = new Packet("StartExam", data);
		data = new ArrayList<Object>();
		int requestID = MainClient.client.sendToServerAJ(packet);		
		packet = MainClient.client.getResponse(requestID);
		data.add(packet.getOperation());
		data.add(packet.getData());		
		return data;
	}
	/**
	   * This method get the activate exam from Data base
	   *
	   * Build packet with GetActiveExams request
	   * Send this packet to server by client 
	   * @return active exam in the data base
	   */
	public static HashMap<Exam, String> getActiveExams(String executorID)
	{
		Packet packet = new Packet("GetActiveExams",executorID);
		int requestID = MainClient.client.sendToServerAJ(packet);		
		packet = MainClient.client.getResponse(requestID);		
		return (HashMap<Exam,String>) packet.getData();
	}
	
	public static ArrayList<String> waitForCommand(){
		ArrayList<String> data = new ArrayList<String>();
		Packet packet = MainClient.client.getResponse(-1);
		data.add(packet.getOperation());
		data.add((String) packet.getData());
		return data;
	}
	/**
	   * This method remove\lock the activate exam from Data base
	   *@param executionCode The code of the active exam we want to lock
	   * Build packet with LockExam request and executed code of the exam
	   * Send this packet to server by client 
	   */	
	public static void  lockExam(String executionCode)
	{
		Packet packet = new Packet("LockExam",executionCode);
		int requestID = MainClient.client.sendToServerAJ(packet);		
		MainClient.client.getResponse(requestID);		
		
	}
	/**
	   * This method adding the activate exam to  finish exams in Data base
	   *@param exam The finish exam to add 
	   *@param examinee The student exam he wants to submit
	   *@param reson the status of submit
	   * Build packet with SubmitExam request and all parameters
	   * Send this packet to server by client 
	   */		
	public static void submitExam(FinishedExam exam, Examinee examinee, String reason) {
		ArrayList<Object> data = new ArrayList<Object>();
		data.add(exam);
		data.add(examinee);
		data.add(reason);
		Packet packet = new Packet("SubmitExam", data);
		MainClient.client.sendToServerAJ(packet);		
		
	}
	public static ArrayList<Object> takeManualExam(Student student, String examExecutionCode)
	{		
		ArrayList<Object> data = new ArrayList<Object>();
		data.add(student);	
		data.add(examExecutionCode);
		Packet packet = new Packet("TakeManualExam", data);
		data = new ArrayList<Object>();
		int requestID = MainClient.client.sendToServerAJ(packet);		
		packet = MainClient.client.getResponse(requestID);
		data.add(packet.getOperation());
		data.add(packet.getData());		
		return data;
	}
	
	public static void submitManualExam( ManualExamFile exam, Examinee examinee, String reason)
	{
		ArrayList<Object> data = new ArrayList<Object>();
		data.add(exam);
		data.add(examinee);
		data.add(reason);
		Packet packet = new Packet("SubmitManualExam", data);
	    MainClient.client.sendToServerAJ(packet);
			
	}
}
