package AES_Client;
import java.io.IOException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import AES_Classes.Packet;
import AES_Classes.Subject;
import AES_Classes.User;
import AES_Server.PacketHandler;
import ClientGUI.MainClient;
import OCSF.client.AbstractClient;

public class client extends AbstractClient {
	
	private static int requestID = 0;
	private HashMap<Integer,Packet> response;
	private ExecutorService pool;
	public static User user;
	
	/**
	   * Constructs an instance of the client.
	   *
	   * @param host The server to connect to. 
	   * @param port The port number to connect on.
	   * Create packet to response from server
	   * user is the client that login in Client GUI
	   */

	public client(String host, int port) throws IOException {
		super(host, port);		
		openConnection();		
		response= new HashMap<Integer,Packet>();
		pool=Executors.newCachedThreadPool();
		user=MainClient.client.user;				
	}
	/**
	 * The method wait for response from server
	   * @param responseID the method get response packet id 
	   * if response is null , waiting 
	   	**else return function to remove response
	   */

	public synchronized Packet getResponse(int responseID) {
		while(true)
		{
			if (response.get(responseID)!=null)
				return response.remove(responseID); 
			else
			{
				try {
					wait();
				} catch (InterruptedException e) {					
					e.printStackTrace();
				}
				
			}
		}	
	}
	/**
	   * This method handles all data that comes in from the server.
	   *
	   * @param msg The message from the server.
	   */

	@Override
	protected void handleMessageFromServer(Object msg) {
		
		pool.execute(new Runnable() {
			public void run()			{					
				handleResponse(msg);								
			}
		});
	}
	/**
	   * This method handles all data coming from the UI            
	   *
	   * @param message The message from the UI.    
	   */

	synchronized public void handleResponse(Object msg)
	{	
		Packet packet=(Packet)msg;		
		response.put(packet.getID(),packet);
		notifyAll();
	}
	/**
	   * This method send the required packet to server            
	   *
	   * @param packet The packet from the client we want to handle.    
	   */
	public final int sendToServerAJ(Packet packet)
	{
		int ID=generateID();
		packet.setID(ID);
		try {
			sendToServer(packet);
		} catch (IOException e) {			
			e.printStackTrace();
		}
		return ID;
	}
	/**
	   * This method Give request id            
	   *
	   */
	
	private final int generateID()
	{
		requestID=(requestID+1)% (Integer.MAX_VALUE-1);
		return requestID;
	}

}
	  


	  
