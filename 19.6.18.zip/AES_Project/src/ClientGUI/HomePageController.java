package ClientGUI;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Optional;
import java.util.ResourceBundle;

import AES_Classes.*;
import AES_Client.*;
import AES_Classes.Student;
import AES_Client.ExamController;
import ClientGUI.*;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Rectangle2D;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ButtonBar.ButtonData;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.TextInputDialog;
import javafx.scene.control.TreeItem;
import javafx.scene.control.TreeView;
import javafx.scene.control.cell.TextFieldListCell;
import javafx.scene.layout.AnchorPane;
import javafx.stage.FileChooser;
import javafx.stage.Modality;
import javafx.stage.Screen;
import javafx.stage.Stage;
import javafx.util.StringConverter;

public class HomePageController implements Initializable{
	
	/**==================================
	 *=General parameters========== 
	 *==================================
	 */
	public static User OnlineUser;
	int HomePagePermission;
	/**==================================
	 *=GUI Home page General parameters========== 
	 *==================================
	 */
	@FXML private Label txt_title;
	@FXML private TreeView<String> Options;
	@FXML private Button btn_logOut;
	/**==================================
	 *=Question options parameters========== 
	 *==================================
	 */
		/**==================================
		 *=Create Question Pane parameters========== 
		 *==================================
		 */
		@FXML private ComboBox<Subject> SubjectCQComboBox;
		@FXML private Label lbl_CQ;
		@FXML private Label MessageCQ;
		@FXML private AnchorPane CreateQuestionPane;
		public static Stage QuestionCreateWindow;
		/**==================================
		 *=Question View Pane parameters========== 
		 *==================================
		 */
		@FXML private ComboBox<Subject> SubjectComboBox;
		@FXML private ListView<Question> QuestionList= null;
		private ArrayList<Question> questionList;
		@FXML private TextArea QuestionPreview;
		@FXML private Button btn_editquestion;
		@FXML private Label lbl_Q;
		@FXML private Button btn_delete;
		@FXML private AnchorPane QuestionViewPane;
		public static Stage QuestionViewWindow;
		/**==================================
		 *=Exam options parameters========== 
		 *==================================
		 */
			/**==================================
			 *=Exam View Pane parameters========== 
			 *==================================
			 */
		@FXML private Label MessageE;
		@FXML private Label lbl_E;
		@FXML private ListView<Exam> ExamsList = null;
		private ArrayList<Exam> examsList;
		@FXML private ComboBox<Subject> SubjectEComboBox;
		@FXML private ComboBox<Course> CourseComboBox;
		@FXML private Button ReloadExamsButton;
		@FXML private Button btn_remove;
		@FXML private Button ViewExamButton;
		@FXML private Button ExecuteExamButton;
		@FXML private Label CourseNameLabel;
		@FXML private Label AuthorLabel;
		@FXML private Label DateLabel;
		@FXML private Label FreeTextLabel;
		@FXML private Label ExamTimeLabel;
		@FXML private AnchorPane ExamPreviewPane;
		@FXML private AnchorPane ExamViewPane;
		public static Stage ViewExamWindow;
		/**==================================
		 *=Create Exam Pane parameters========== 
		 *==================================
		 */		
		@FXML private Button ConfirmButton;
		@FXML private ComboBox<Course> CourseECComboBox;
		@FXML private ComboBox<Subject> SubjectECComboBox;
		@FXML private Label lbl_CE;
		@FXML private Label MessageCE;
		@FXML private AnchorPane CreateExamPane;
		public static Stage ExamCreateWindow;
		/**==================================
		 *=Active Exam Pane parameters========== 
		 *==================================
		 */	
		@FXML private AnchorPane ActiveExamPane;
		@FXML private AnchorPane ExecutedExamPreviewPane;
		@FXML private ListView<Exam> ExecutedExamsList;
		@FXML private Button ReloadExecutedExamsButton;
		@FXML private Button ViewExecutedExamButton;
		@FXML private Button LockExecutedExamButton;
		HashMap<Exam,String> executedExamsList;
		@FXML private Label ExecutedCourseNameLabel;
		@FXML private Label ExecutedDateLabel;
		@FXML private Label ExecutedAuthorLabel;
		@FXML private Label ExecutedExamTimeLabel;
		@FXML private Label ExecutedFreeTextLabel;
	/**==================================
	 *=Take Exam Pane parameters========== 
	 *==================================
	 */	
		@FXML private AnchorPane TakeExamPane;	
		@FXML private Button SubmitButton;
		@FXML private Button OpenButton;
		@FXML private Label FinishTimeLabel;
		@FXML private Label ExecutionCodeLabel;
		@FXML private TextField CodeTextField;
		@FXML private Label ErrorLabel;
		@FXML private Button SubmitManualButton;
		@FXML private Button DownloadButton;
		private String examExecutionCode;
		ManualExamFile manualExam;
		private Examinee examinee;
		public ExamGUIController examGuiController;
		public Scene examWindowScene;
		private static final int ALLOWED_CHARACTERS_NUMBER = 4;
		boolean correct = false;;

/**
 *=General Home page method
 *=Click Log Out                                 
 *=this method performed when client click button log out
 *=will log out the client from the system
*=ask him before if he wants to logout
 */
@FXML
public void ClickLogOut(ActionEvent event) {
		
		Platform.runLater(new Runnable(){
            
            public void run()
            {           
			Alert alert = new Alert(AlertType.CONFIRMATION);
			alert.setContentText("Are you sure you want to exit?");
			alert.setHeaderText(null);
			alert.setGraphic(null);
			Optional<ButtonType> result = alert.showAndWait();
			if(result.get() == ButtonType.OK){
				UserController.logoutUser(GUI_LoginController.user.getID());
				MainClient.swittchscene(MainClient.login);
			}else
			{
				alert.close();
			}                                    
         }                
        });          
        
    }
/**
 *=General Home page method when need to alert a message                             
 *=this method performed when we call to alert a message
 *@param title the title of alert window
 *@param message he message will present in the window
 */
public void alert(String title, String message)
{
	Alert alert = new Alert(AlertType.INFORMATION);
	alert.setTitle(title);
	alert.setHeaderText(null);
	alert.setContentText(message);
	alert.showAndWait();

}
/**
 *=General Home page function when need to alert a message                              
 *=this method performed when we call to confirm somthin in system
 *@param title the title of alert window
 *@param message he message will present in the window
 *= Click OK to confirm Or cancel 
*/
public boolean confirmationAlert(String title,String message)
{
	Alert alert = new Alert(AlertType.CONFIRMATION);
	alert.setContentText(message);
	alert.setHeaderText(title);
	alert.setGraphic(null);
	Optional<ButtonType> result = alert.showAndWait();

	if (result.get() == ButtonType.OK){
		alert.close();
		return true;

	}
	else {
		alert.close();
		return false;
	}		
}
/**
 *=General Home page method that present tree view for users
 *=This method create tree option By permissions of user                           
 */
public void CreateTreeView() {	
	
	TreeItem<String> teacher = new TreeItem<>("T-Options");
	TreeItem<String> student = new TreeItem<>("S-Options");
	TreeItem<String> manger = new TreeItem<>("M-Options");
	TreeItem<String> teacherQ = new TreeItem<>("Questions");
	TreeItem<String> teacherE = new TreeItem<>("Exams");
	TreeItem<String> studentE = new TreeItem<>("Exams");
	TreeItem<String> QList = new TreeItem<>("Questions List");
	TreeItem<String> EList = new TreeItem<>("Exam List");
	TreeItem<String> NewQ = new TreeItem<>("Create Question");
	TreeItem<String> NewE = new TreeItem<>("Create Exam");
	TreeItem<String> TakeExam = new TreeItem<>("Take Exam");
	TreeItem<String> ActiveExam = new TreeItem<>("Active Exams");
	
	//Teacher options in home page
	teacher.getChildren().add(teacherQ);
	teacherQ.setExpanded(true);
	teacher.getChildren().add(teacherE);
	teacherE.setExpanded(true);
	teacherQ.getChildren().add(QList);
	teacherQ.getChildren().add(NewQ);
	teacherE.getChildren().add(EList);
	teacherE.getChildren().add(NewE);
	teacherE.getChildren().add(ActiveExam);
	//Student options in home page
	student.getChildren().add(studentE);
	studentE.setExpanded(true);
	studentE.getChildren().add(TakeExam);
	
	//Set visible option to specific user
	switch(HomePagePermission) {
	
	case 1:
		OnlineUser =(Student) GUI_LoginController.user;
		Options.setRoot(student);
		Options.setShowRoot(false);	
		break;
	case 2:
		OnlineUser =(Teacher) GUI_LoginController.user;
		questionList  = QuestionController.getQuestionList();
		TecherFunctions();
		Options.setRoot(teacher);
		Options.setShowRoot(false);
		break;
	case 3:
		//fill school manger user
		Options.setRoot(manger);
		Options.setShowRoot(false);	
		break;
	}
	
}
/**
 *=This method take all containers and controllers in home page to Starting point
 *=before every action in home page all be invisible                           
 */
public void setAllinStartpoint() {
	
	//teacher controllers
	QuestionViewPane.setVisible(false);
	ExamPreviewPane.setVisible(false);
	CreateQuestionPane.setVisible(false);
	ActiveExamPane.setVisible(false);
	ExamViewPane.setVisible(false);
	ExecutedExamPreviewPane.setVisible(false);
	CreateExamPane.setVisible(false);
	CourseComboBox.getItems().clear();
	CourseECComboBox.getItems().clear();
	QuestionPreview.setVisible(false);
	btn_editquestion.setVisible(false);
	btn_delete.setVisible(false);
	ReloadExamsButton.setVisible(false);
	ViewExamButton.setVisible(false);
	btn_remove.setVisible(false);
	ExecuteExamButton.setVisible(false);
	QuestionList.setVisible(false);
	ExamsList.setVisible(false);
	ViewExecutedExamButton.setDisable(true);
	LockExecutedExamButton.setDisable(true);
	// student
	TakeExamPane.setVisible(false);
	SubmitButton.setVisible(false);
	OpenButton.setVisible(false);
	FinishTimeLabel.setVisible(false);
	SubmitManualButton.setVisible(false);
	DownloadButton.setVisible(false);
	
}
/**
 *=General method in Home page when user click some option in the tree view 
 *=when user selected some option will present in his home page                           
 */
@FXML 
public void ClickOptions() {	

	setAllinStartpoint();
	
	String Click = Options.getSelectionModel().getSelectedItem().getValue();
		
	switch(Click)
	{	
	case "Questions List":
		QuestionViewPane.setVisible(true); 
		updateSubjectBox(SubjectComboBox);
		 break; 
	case "Create Question":
		CreateQuestionPane.setVisible(true);
		updateSubjectBox(SubjectCQComboBox); 			  
	     break;
	case "Exam List":
		ExamViewPane.setVisible(true);
	  updateSubjectBox(SubjectEComboBox);
	  break;
	case "Create Exam":
		CreateExamPane.setVisible(true);
		updateSubjectBox(SubjectECComboBox);		
		  break;
	case "Active Exams":		
		ActiveExamPane.setVisible(true);
		updateExecutedExamList();
		  break;
	case "Take Exam":		
		TakeExamPane.setVisible(true);
				  break;
		  default:
			  break;
}

	}
/**==================================
 *=Teacher Home page methods========== 
 *==================================
 */
/**
	 *=This method update from DB the subject that will perform in comboBox 
	 *@param Subject the comboBox that we update
	 *before update clear all item in comboBox                         
	 */
	public void updateSubjectBox(ComboBox<Subject> Subject) {
		
		if(Subject.getItems() == null)
			return;
		Subject.getItems().clear();
		Subject.getItems().addAll(((Teacher)OnlineUser).getSubjects());
		Subject.setPromptText("Subject");
	}
	//Questions functions
	/**
	 *=This method delete question from DB when user click delete button
	 *@param event catch all events of button
	 *before delete question ask for confirmation                         
	 */
	@FXML
	public void ClickDeleteQuestion(ActionEvent event) {
		
		Question question = QuestionList.getSelectionModel().getSelectedItem();
		boolean answer =confirmationAlert("Remove Question","Are you sure you want to remove this question?");
		if(answer)
		{
			if(!(question.getAuthor().getID().equals(GUI_LoginController.user.getID())))
			{
				alert("Remove Question", "You do not have permission to remove questions' which were not composed by you");	
				return;
			}
			QuestionController.DeleteQuestion(question.getID());
			updateQuestionListBySubject(SubjectComboBox.getSelectionModel().getSelectedItem().getID());
			QuestionPreview.setVisible(false);
			btn_delete.setVisible(false);
			btn_editquestion.setVisible(false);
			alert("Remove Exam","Exam has been removed from the database");
		}
	}
	/**
	 *=This method show selected question from list details in home page
	 *@param Questionselected To preview the selected question, get is details               
	 */
	public void QuestionPreview(Question Questionselected) {
		
		Platform.runLater(new Runnable() {
			@Override
			public void run() {
		QuestionPreview.setText("Question details:\n\n ID: "+Questionselected.getID()+"\n Author: "+Questionselected.getAuthor().getName()+"\n\nQuestion: " + Questionselected.getQuestion()+"\n\nAnswer: "+Questionselected.getCorrectAnswer());
		QuestionPreview.setVisible(true);
			}
		});
	}
	 	//when user select items from combobox in View question
	/**
	 *=This method update question list of subject by selected comboBox value                   
	 */
	public void SubjectComboBoxAction() {
		
		QuestionPreview.setVisible(false);
		if(SubjectComboBox.getValue()==null)
			return;
		updateQuestionListBySubject(SubjectComboBox.getValue().getID());
		QuestionList.setVisible(true);	
		
	}
		//when user select items from combobox in create question
	/**
	 *=This method Opens a window to create a test according to a chosen subject                 
	 */
	public void SubjectCQComboBoxAction() {
				
				CreateQuestionController.subject = SubjectCQComboBox.getValue();
				QuestionCreateWindow = new Stage();
				QuestionCreateWindow.setTitle("Create question");
				QuestionCreateWindow.initModality(Modality.APPLICATION_MODAL);
		    	Parent root;
				try {
					FXMLLoader loader = new FXMLLoader();
					root = loader.load(getClass().getResource("QuestionCreateGUI.fxml").openStream());
					Scene scene = new Scene(root);
					QuestionCreateWindow.setScene(scene);
					QuestionCreateWindow.showAndWait();
					
					
				} catch (IOException e) {			
					e.printStackTrace();
				}
			
		}
		//when user wants to see question details
	/**
	 *This method Opens a Question Editing window according to the selected question                 
	 */
	@FXML 
	public void ClickQuestionEdit(ActionEvent event) {	
		
			QuestionViewWindow = new Stage();
			QuestionViewWindow.setTitle("Question View");
			QuestionViewWindow.initModality(Modality.APPLICATION_MODAL);
	    	Parent root;
			try {	
				QuestionViewGUIController.question = QuestionList.getSelectionModel().getSelectedItem();
				if(QuestionViewGUIController.question!=null) {
				root = FXMLLoader.load(getClass().getResource("QuesionViewDetails.fxml"));
				Scene scene = new Scene(root);
				QuestionViewWindow.setScene(scene);
				QuestionViewWindow.initOwner(SubjectComboBox.getScene().getWindow());
				QuestionViewWindow.showAndWait();
				updateQuestionListBySubject(SubjectComboBox.getValue().getID());
				}
				else
				{
					alert("Question view","You need to select question");
				}
			} catch (IOException e) {			
				e.printStackTrace();
			}
	    }
		//when user select items from combobox in view question the list of questions will be update
	/**
	 *=This method update question list of subject by selected subject id
	 *@param  Sid The selected subject id  
	 **before update clear all question from list                
	 */
	public void updateQuestionListBySubject(String Sid) {
		
		QuestionPreview.setVisible(false);
		QuestionList.getItems().clear();
		questionList = QuestionController.getQuestionListBySubject(Sid);
		
		if(!questionList.isEmpty()) {
			QuestionList.getItems().addAll(questionList);}
		
	}
	/**
	 *=This method update exam list of exams by selected subject id
	 *@param  subjectID The selected subject id 
	 *before update clear all exam from list                
	 */
	//Exam
		//when user select items from combobox view exam the list of exams will be update
	public void updateExamListBySubject(String subjectID) {
				ExamPreviewPane.setVisible(false);
				ExamsList.getItems().clear();
				examsList = ExamController.getExamsListBySubject(subjectID);
				ExamsList.getItems().addAll(examsList);
			}
		//when user select exam will showing him privew of exam
	/**
	 *=This method show selected exam present details in home page
	 *@param exam To preview the selected exam, get is details               
	 */
	public void showExamPreview(Exam exam) {
			ExamPreviewPane.setVisible(true);
			CourseNameLabel.setText(exam.getCourse().getName());
			DateLabel.setText(exam.getCreationDate());
			AuthorLabel.setText("" + exam.getAuthor().getName());
			FreeTextLabel.setText(exam.getNote());
			ExamTimeLabel.setText("Exam time: " + exam.getExamTime());
		}
		//when user select items from combobox in create exam 
	/**
	 *In View Exam pane
	 *=This method Show list of exam by selected subject id
	 * The method update course comboBox by the courses in this subject            
	 */
	public void subjectSelectionListner() {
				ExamPreviewPane.setVisible(false);
			if(SubjectEComboBox.getValue()==null) 
			return;
				updateCoursesBox(SubjectEComboBox.getValue().getID());
				updateExamListBySubject(SubjectEComboBox.getValue().getID());
				ExamsList.setVisible(true);
				ReloadExamsButton.setVisible(true);
			
		}
	/**
	 *=This method update exam list of exams by selected course id
	 *@param  courseID The selected course id 
	 *before update clear all exam from list                
	 */
	public void updateExamListByCourse(String courseID) {
			ExamPreviewPane.setVisible(false);
			ExamsList.getItems().clear();
			for (Exam exam : examsList) {
				if (exam.getCourse().getID().equals(courseID))
					ExamsList.getItems().add(exam);
	
			}
		}
	/**
	 * *in View exam pane
	 *=This method Show list of exam by selected course id            
	 */
	public void courseSelectionListner() {
			ExamPreviewPane.setVisible(false);
			if(CourseComboBox.getValue() == null)
				return;
			
			updateExamListByCourse(CourseComboBox.getValue().getID());
			ExamsList.setVisible(true);
			ReloadExamsButton.setVisible(true);
		}
	/**
	 *=This method update from DB the courses that will perform in comboBox by subject id
	 *@param subjectID the subject id of this courses
	 *before update clear all item in comboBox                         
	 */
	public void updateCoursesBox(String subjectID) {
		ExamPreviewPane.setVisible(false);
		if(CourseComboBox.getItems() == null)
			return;
		else {
		CourseComboBox.getItems().clear();
		CourseComboBox.getItems().addAll(((Teacher)GUI_LoginController.user).getCoursesOfSubject(subjectID));
		CourseComboBox.setPromptText("Course");	}
	}
	/**
	 *=This method update exam list               
	 */
	@FXML
	public void reloadExecutedClickedListener() {
		
		updateExecutedExamList();		

	}
	@FXML 
	public void reloadClickedListener() {
			ExamPreviewPane.setVisible(false);
			if (SubjectEComboBox.getValue() != null) {
				updateExamListBySubject(SubjectEComboBox.getValue().getID());
				if (CourseComboBox.getValue() != null)
					updateExamListByCourse(CourseComboBox.getValue().getID());
			} else
				ExamsList.getItems().clear();
	
	}
	/**
	 *=This method in View exam pane performed when user click to view exam
	 *=This method Opens a Question View window according to the selected exam                             
	 */
	@FXML 
	public void ClickViewExam(ActionEvent event) {
		
		if(ExamsList.getSelectionModel().getSelectedItem()== null)
		{
			alert("View Exam","You need to select an exam before you can view one");	
			return;		}
					
		ViewExamWindow = new Stage();
		ViewExamWindow.setTitle("View Exam");
		
		try {
			
			FXMLLoader loader = new FXMLLoader();
			Parent root1 = loader.load(getClass().getResource("ViewExamGUI.fxml").openStream());			
			ViewExamGUIController controller = loader.getController();
			controller.setQuestionsInExam(ExamsList.getSelectionModel().getSelectedItem().getQuestions());
			controller.setExam(ExamsList.getSelectionModel().getSelectedItem());			
			ViewExamWindow.setScene(new Scene(root1));
			ViewExamWindow.initModality(Modality.APPLICATION_MODAL);
			ViewExamWindow.initOwner(SubjectEComboBox.getScene().getWindow());
			ViewExamWindow.showAndWait();		
			
			
		} catch (IOException e) {			
			e.printStackTrace();
		}	
	}
	/**
	 *=This method in View exam pane performed when user click to remove exam
	 *=This method remove from repository the exam 
	 *before remove open confirmation window
	 *If the current teacher did not write the question he could not delete it                          
	 */
	@FXML
	public void ClickRemoveExam(ActionEvent event) {
		Exam exam = ExamsList.getSelectionModel().getSelectedItem();
		boolean answer =confirmationAlert("Remove Exam","Are you sure you want to remove the selected exam from the database?");
		if(answer)
		{
			if(!(exam.getAuthor().getID().equals(GUI_LoginController.user.getID())))
			{
				alert("Remove Exam", "You do not have permission to remove exams' which were not composed by you");	
				return;
			}
			ExamController.removeExam(exam.getID());
			reloadClickedListener();
			ExamPreviewPane.setVisible(false);
			btn_remove.setDisable(true);
			ViewExamButton.setDisable(true);
			alert("Remove Exam","Exam has been removed from the database");
		}
	}
	/**
	 * In Create Exam pane
	 *=This method Show list of exam by selected subject id
	 * The method update course comboBox by the courses in this subject            
	 */
	public void subjectSelectionListener() {
		if(SubjectECComboBox.getValue()==null) {
			return;
		}else {
		ConfirmButton.setDisable(true);
		updateCreateCoursesBox(SubjectECComboBox.getValue().getID());}
	}
	/**
	 *in create exam pane
	 *=This method disable confirmation button             
	 */
	public void courseSelectionListener() {
		ConfirmButton.setDisable(false);
	}
	/**
	 *=This method Opens a Exam Creating window according to the selected subject an course id by click submit after choose subject an course
	 *create new exam by the subject,course and author that want to create new exam                
	 */
	@FXML
	public void confirmButtonListener(ActionEvent event) {
		ExamCreateWindow = (Stage) ConfirmButton.getScene().getWindow();
		ExamCreateWindow.setTitle("Create exam");
		
		try {
			ExamCreateWindow = new Stage();
			ExamCreateWindow.setTitle("Create and submit exam");
			Course course = CourseECComboBox.getSelectionModel().getSelectedItem();
			Subject subject = SubjectECComboBox.getSelectionModel().getSelectedItem();
			Date date = new Date();  
		    SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");  
		    String strDate= formatter.format(date);  
		    FXMLLoader loader = new FXMLLoader(); 
		    Parent root = loader.load(getClass().getResource("CreateExam.fxml").openStream());			
			CreateExamsController  controller = loader.getController();
			Exam exam = new Exam(subject.getID()+course.getID(),course,subject,new Person(((Teacher)OnlineUser).getID(),((Teacher)OnlineUser).getName()),strDate,0);
			controller.setExam(exam);
			controller.updateQuestionsList();
			Scene scene = new Scene(root);
			ExamCreateWindow.setScene(scene);
			ExamCreateWindow.initModality(Modality.APPLICATION_MODAL);
			ExamCreateWindow.initOwner(SubjectECComboBox.getScene().getWindow());
			ExamCreateWindow.showAndWait();
			
			
			Rectangle2D primScreenBounds = Screen.getPrimary().getVisualBounds();
			ExamCreateWindow.setX((primScreenBounds.getWidth() - ExamCreateWindow.getWidth()) / 2);
			ExamCreateWindow.setY((primScreenBounds.getHeight() - ExamCreateWindow.getHeight()) / 2);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	  
	
	}
	/**
	 *=This method update course comboBox  of courses by selected subject id
	 *@param subjectID The selected subject id
	 */
	public void updateCreateCoursesBox(String subjectID) {
		if(CourseComboBox.getItems() == null) {
			return;
		}else {
		CourseECComboBox.getItems().clear();
		CourseECComboBox.getItems().addAll(((Teacher)OnlineUser).getCoursesOfSubject(subjectID));
		CourseECComboBox.setPromptText("Course");}
	}
	/**
	 *=This method present window to insert code execution an activate selected exam
	 *Ask for 4 charters of code activate 
	 * add exam to active exam list                
	 */
	public void executeButtonListener() {							
	
		TextInputDialog dialog = new TextInputDialog();		
		dialog.setTitle("Exam Execution");			
		dialog.setContentText("Enter 4 characters execution code: ");
		dialog.setHeaderText(null);
		Optional<String> result = dialog.showAndWait();
		if(result.isPresent())				
			if(result.get().length() == 4)				
				if(ExamController.executeExam(result.get(), ExamsList.getSelectionModel().getSelectedItem(), ((Teacher)GUI_LoginController.user).getID() )) {
					dialog.close();
					alert("Exam Execution","Exam was successfully executed!");
				}
				else
					alert("Exam Execution","Code already in use.");
			else
				alert("Exam Execution", "You need to enter 4 characters code");
	}
	/**
	 *=This method open active exam  by selected exam from Executed Exams List           
	 */
	public void viewExecutedExamListener()
	{
		if(ExecutedExamsList.getSelectionModel().getSelectedItem()== null)
		{
			alert("View Exam", "You need to select an exam before you can view one");	
			return;
		}
	
		Stage stage = new Stage();
		stage.setTitle("View Exam");		
		try {
			FXMLLoader loader = new FXMLLoader();
			Parent root = loader.load(getClass().getResource("ViewExamGUI.fxml").openStream());			
			ViewExamGUIController controller = loader.getController();
			controller.setQuestionsInExam(ExecutedExamsList.getSelectionModel().getSelectedItem().getQuestions());
			controller.setExam(ExecutedExamsList.getSelectionModel().getSelectedItem());	
			stage.setScene(new Scene(root));
			stage.initModality(Modality.APPLICATION_MODAL);
			stage.initOwner(ExecutedExamsList.getScene().getWindow());
			stage.showAndWait();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	/**
	 *=This method lock active exam by his code
	 *@param code The active exam code
	 *update list of active exam           
	 */
	public void lockExam(String code) {
		ExamController.lockExam(code);
		ExecutedExamPreviewPane.setVisible(false);
		updateExecutedExamList();
	}
	/**
	 *=This method Send the selected activate exam code to lockExam method when client press lock exam          
	 */
	public void lockExamButtonListener() {
		lockExam(executedExamsList.get(ExecutedExamsList.getSelectionModel().getSelectedItem()));
	}
	/**
	 *=This method update exam active list of exams that this specific teacher executed 
	 *before update clear all exam from list                
	 */
	public void updateExecutedExamList() {
		ExecutedExamsList.getItems().clear();
		executedExamsList = ExamController.getActiveExams(GUI_LoginController.user.getID());
		ExecutedExamsList.getItems().addAll(executedExamsList.keySet());
	}
	/**
	 *=This method show selected active exam present details in home page
	 *@param exam To preview the selected exam, get is details               
	 */
	public void showExecutedExamPreview(Exam exam) {
		ExecutedExamPreviewPane.setVisible(true);
		ExecutedCourseNameLabel.setText(exam.getCourse().getName());
		ExecutedDateLabel.setText(exam.getCreationDate());
		ExecutedAuthorLabel.setText("" + exam.getAuthor().getName());
		ExecutedExamTimeLabel.setText("Exam time: " + exam.getExamTime());
		ExecutedFreeTextLabel.setText(exam.getNote());
	}
	/**
	 *=When teacher is login all this set converters an action of controller that uses by teacher will be update.               
	 */
	public void TecherFunctions() {
	//ComboBox of view question
	SubjectComboBox.setConverter(new StringConverter<Subject>() {
		public String toString(Subject subject) {
			return subject.getName();
		}

		@Override
		public Subject fromString(String arg0) {
			return null;
		}

	});
	//ComboBox of view exam
	SubjectEComboBox.setConverter(new StringConverter<Subject>() {
		public String toString(Subject subject) {
			return subject.getName();
		}

		@Override
		public Subject fromString(String arg0) {
			return null;
		}

	});
	//ComboBox of create question
	SubjectCQComboBox.setConverter(new StringConverter<Subject>() {			

		@Override
		public String toString(Subject subject) {
			
			return subject.getName();
		}

		@Override
		public Subject fromString(String string) {
			// TODO Auto-generated method stub
			return null;
		}
	});
	//ComboBox of create exam
	SubjectECComboBox.setConverter(new StringConverter<Subject>() {
		public String toString(Subject subject) {
			return subject.getName();
		}

		@Override
		public Subject fromString(String arg0) {
			return null;
		}

	});

	//ComboBox of create question
	CourseComboBox.setConverter(new StringConverter<Course>() {

		public String toString(Course course) {
			return course.getName();
		}

		@Override
		public Course fromString(String arg0) {
			return null;
		}

	});
	//ComboBox of create exam
	CourseECComboBox.setConverter(new StringConverter<Course>() {

		public String toString(Course course) {
			return course.getName();
		}

		@Override
		public Course fromString(String arg0) {
			return null;
		}

	});
	// Converter exam list
	ExamsList.setCellFactory(lv -> {
		TextFieldListCell<Exam> cell = new TextFieldListCell<Exam>();
		cell.setConverter(new StringConverter<Exam>() {
			@Override
			public String toString(Exam exam) {
				return exam.getCreationDate() + "      Course: " + exam.getCourse().getName() + "      Author: "
						+ exam.getAuthor().getName();
			}

			@Override
			public Exam fromString(String string) {
				return null;
			}
		});
		return cell;
	});
	// add listener to  question list
	QuestionList.getSelectionModel().selectedItemProperty().addListener(e -> {
		btn_editquestion.setVisible(true);
		btn_delete.setVisible(true);
		Question selectedQuestion = QuestionList.getSelectionModel().getSelectedItem();
		if(selectedQuestion!=null) {QuestionPreview(selectedQuestion);}
		else {
			btn_delete.setVisible(false);
			btn_editquestion.setVisible(false);
		}
		});
	// Converter question list
	QuestionList.setCellFactory(lv -> {
		TextFieldListCell<Question> cell = new TextFieldListCell<Question>();
		cell.setConverter(new StringConverter<Question>() {
			@Override
			public String toString(Question question) {
				return question.getQuestion();
			}

			@Override
			public Question fromString(String string) {
				return null;
			}
		});
		return cell;
	});
	// add listener to  exam list
	ExamsList.getSelectionModel().selectedItemProperty().addListener(e -> {
			Exam exam = ExamsList.getSelectionModel().getSelectedItem();
			if (exam != null)
				showExamPreview(exam);
			ViewExamButton.setVisible(true);
			ExecuteExamButton.setVisible(true);
			btn_remove.setVisible(true);
		
	});
	// Converter exam list
	ExamsList.setCellFactory(lv -> {
		TextFieldListCell<Exam> cell = new TextFieldListCell<Exam>();
		cell.setConverter(new StringConverter<Exam>() {
			@Override
			public String toString(Exam exam) {
				return "ID:"+exam.getID()+", subject:"+exam.getSubject().getName()+", course:"+exam.getCourse().getName();
			}

			@Override
			public Exam fromString(String string) {
				return null;
			}
		});
		return cell;
	});
	// Converter active exam list
	ExecutedExamsList.setCellFactory(lv -> {
		TextFieldListCell<Exam> cell = new TextFieldListCell<Exam>();
		cell.setConverter(new StringConverter<Exam>() {
			@Override
			public String toString(Exam exam) {
				return "Code: "+executedExamsList.get(exam) + "      Course: " + exam.getCourse().getName() + "      Author: "
						+ exam.getAuthor().getName();
			}

			@Override
			public Exam fromString(String string) {
				return null;
			}
		});
		return cell;
	});
	// add listener to active exam list
	ExecutedExamsList.getSelectionModel().selectedItemProperty().addListener(e -> {
		Exam exam = ExecutedExamsList.getSelectionModel().getSelectedItem();			
		if (exam != null)
		{
			showExecutedExamPreview(exam);			    
			LockExecutedExamButton.setDisable(false);			    
			ViewExecutedExamButton.setDisable(false);
			
		}
		else {
			LockExecutedExamButton.setDisable(true);			    
			ViewExecutedExamButton.setDisable(true);
		}
	});
	
}
/**==================================
 *=Student Home page methods========== 
 *==================================
 */	
	/**
	*this method enable submit button after take exam
	*/	
	public void enableSubmitButton()
	{
		SubmitButton.setDisable(false);
	}
	/**
	*this method disable submit button before take exam
	*/	
	public void disableSubmit()
	{
		SubmitButton.setDisable(true);
	}
	/**
	*This method call exam controller to submit exam 
	*/	
	public void submitExam() {
		examGuiController.submitExam("ByUser","Success");

	}
	/**
	*This method Open exam GUI when user press open button
	*Will only be possible once they have entered the exam once
	*/	
	public void openButtonListener()
	{
		if(examWindowScene!=null)
		{
			Stage stage = new Stage();
			stage.setTitle("Exam");	
			stage.setScene(examWindowScene);
			stage.initModality(Modality.APPLICATION_MODAL);
			stage.initOwner(TakeExamPane.getScene().getWindow());
			stage.showAndWait();
		}
	}
	/**
	*This method After entering a test 4 characters code, identifies the appropriate test and activates accordingly
	*Open options window to choose exam type : Online , manual or cancel
	* Online : open exam window for student 
	* manual : create word file to save in computer
	* Cancel: exit this window
	*/
	public void codeTextFieldListener() {
		examExecutionCode = CodeTextField.getText();
		if(examExecutionCode.length()!=4) {
			ErrorLabel.setVisible(true);
			ErrorLabel.setText("Code length should be 4 characters");
			return;
		}
		String result = ExamController.checkExamCode(examExecutionCode,GUI_LoginController.user.getID());	
		switch(result) {
		case "Success":	
			Alert alert = new Alert(AlertType.CONFIRMATION);			
			
			CodeTextField.setVisible(false);
			ExecutionCodeLabel.setVisible(false);
			ErrorLabel.setVisible(false);
			
			alert.setTitle("Choose exam type");
			alert.setHeaderText(null);
			
			alert.setContentText("Choose online to fill the exam online or manual to download a pdf for submission");
			ButtonType buttonTypeOnline = new ButtonType("Online");
			ButtonType buttonTypeManual = new ButtonType("Manual");
			ButtonType buttonTypeCancel = new ButtonType("Cancel", ButtonData.CANCEL_CLOSE);
			alert.getButtonTypes().setAll(buttonTypeOnline, buttonTypeManual, buttonTypeCancel);
			Optional<ButtonType> result2 = alert.showAndWait();
			if (result2.get() == buttonTypeOnline){
				setOnlineScene();
				
				Exam exam = ExamController.takeExam(examExecutionCode);									
				Stage stage = new Stage();
				stage.setTitle("Exam");		
				try {
					FXMLLoader loader = new FXMLLoader();
					Parent root = loader.load(getClass().getResource("ExamGUI.fxml").openStream());			
					examGuiController = loader.getController();						 							
					examGuiController.setExamCode(examExecutionCode);
					examGuiController.setExam(exam);	
					examGuiController.setTakeExamPageController(this);
					examWindowScene = new Scene(root);
					stage.setScene(examWindowScene);
					stage.initModality(Modality.APPLICATION_MODAL);
					stage.initOwner(SubmitManualButton.getScene().getWindow());
					stage.showAndWait();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}					
			} else if (result2.get() == buttonTypeManual) {
				setManualScene();				
				
			} else
			{
				alert.hide();
				SubmitButton.getScene().getWindow().hide();
			}
			break;
		case "ExamCodeDoesntExist":
			ErrorLabel.setVisible(true);
			ErrorLabel.setText("Exam code does not exist");
			break;
		case "TookExamAlready":
			ErrorLabel.setVisible(true);
			ErrorLabel.setText("Exam already submitted or time is up");
			break;
		}
	}
	
	public void setOnlineScene()
	{
		SubmitButton.setVisible(true);
		SubmitButton.setDisable(true);
		OpenButton.setVisible(true);
		FinishTimeLabel.setVisible(true);
	}
	
	public void setManualScene()
	{
		DownloadButton.setVisible(true);
		SubmitManualButton.setVisible(true);
		downloadButtonListener();
		
	}
	/**
	*This method Set in finish exam the time student need to end time and show him the time
	*@param finishTime The time to finish exam
	* Online : open exam window for student 
	*/
	public void setExamFinishTime(Date finishTime)
	{
		SimpleDateFormat formatter = new SimpleDateFormat("HH:mm");
		String time = formatter.format(finishTime);			
		FinishTimeLabel.setText("Finish Time: "+time);
	}
	public void closeWindow()
	{
		SubmitButton.getScene().getWindow().hide();
	}
	public void downloadButtonListener() {
		FileChooser fileChooser = new FileChooser();
		fileChooser.setTitle("Save Exam");
		fileChooser.setInitialFileName(GUI_LoginController.user.getID()+".docx");
		File file = fileChooser.showSaveDialog(SubmitButton.getScene().getWindow());
		if(file == null)
			return;
		ArrayList<Object> data = ExamController.takeManualExam((Student)GUI_LoginController.user, examExecutionCode);
		
		String answer = (String) data.get(0);
		if(answer.equals("ExamIsNotActive"))
		{	alert("Error","The exam is not active anymore");
			closeWindow();
			return;
		}	
		
		try {	
			
			ArrayList dataAnswer = (ArrayList) data.get(1);
			examinee = (Examinee) dataAnswer.get(1);
			manualExam = (ManualExamFile)dataAnswer.get(2);			
			setExamFinishTime(examinee.getFinishTime());
			FileOutputStream fos = new FileOutputStream(file);
			BufferedOutputStream bos = new BufferedOutputStream(fos);
			bos.write(manualExam.getMybytearray());
			bos.close();
			new Thread(new Runnable() {
				
				public void run() {
					ArrayList<String> data = ExamController.waitForCommand();
					String command = data.get(0);
					
					while(true){
					switch(command)
					{
					case "LockExam":		
						ExamController.submitExam(null, examinee, command);	
						alert("Exam Lock","The exam has been locked");
						SubmitButton.getScene().getWindow().hide();
						return;			
					
					/*case "TimeExtension":
						timeExtension += Integer.parseInt(answer.get(1));
						break;*/
						
					case "Timeout":
						ExamController.submitExam(null, examinee, command);	
						Platform.runLater(new Runnable()
						{

							@Override
							public void run() {
								alert("Time Out","The exam time has ran out");
								SubmitButton.getScene().getWindow().hide();
								
							}
						});
					
						return;
						
					case "Submitted":
						return;
					}
					
					}
				}
				
				
			}).start();
			
		} catch (Exception e) {			
			e.printStackTrace();
		}
		
	}
	public void submitManualExam() {
		FileChooser fileChooser = new FileChooser();
		fileChooser.setTitle("Send Exam");	
		File file = fileChooser.showOpenDialog(SubmitButton.getScene().getWindow());		
		byte [] mybytearray  = new byte [(int) file.length()];
	    FileInputStream fis;
		try {
			fis = new FileInputStream(file);
			BufferedInputStream bis = new BufferedInputStream(fis);	  		
			manualExam.initArray(mybytearray.length);			  
			bis.read(manualExam.getMybytearray(), 0, mybytearray.length);
			ExamController.submitManualExam(manualExam, examinee, "ByUser");
			alert("ByUser","Success");
			closeWindow();
			
		} catch (Exception e) {		
			e.printStackTrace();
		}					  
	   
		
	}
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		// TODO Auto-generated method stub
		
		this.HomePagePermission = GUI_LoginController.user.getPermission();
		CreateTreeView();
		
	}	
	
}
