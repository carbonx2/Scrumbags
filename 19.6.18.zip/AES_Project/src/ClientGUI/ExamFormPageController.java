package ClientGUI;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

import AES_Classes.QuestionInExam;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.layout.VBox;

public class ExamFormPageController implements Initializable{ 

	/**==================================
	 *=ExamFormPageController parameters========== 
	 *==================================
	 */
	private ArrayList<QuestionPaneController> controllers;
	@FXML
	private VBox OurVBox;
	/**
	 *                            
	 *=This method add question to QuestionPane 
	 *@param question To add in exam
	 *@param numberOfQuestions number of questions in exam
	 *QuestionPane will show all question that we add
	 */
	public void addQuestion(QuestionInExam question, int numberOfQuestions) {
		numberOfQuestions++;
		FXMLLoader loader = new FXMLLoader();
		Node node;
		try {
			node = loader.load(getClass().getResource("QuestionPane.fxml").openStream());
			QuestionPaneController controller = loader.getController();
			controller.setQuestion(question, numberOfQuestions);
			controllers.add(controller);
			OurVBox.getChildren().add(node);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	/**
	 *                            
	 *This method set note to question in Question Pane
	 */
	public void setNotes() {
		for (QuestionPaneController controller : controllers) {
			controller.setNotes();
		}
	}
	/**
	 *                            
	 *This method set score to question in Question Pane
	 */	
	public void setScores() {
		for (QuestionPaneController controller : controllers) {
			controller.setScore();
		}
	}
	/**
	 *                            
	 *This method return score sum of all question in Question Pane
	 */	
	public int getScores() {
		int score=0;
		for (QuestionPaneController controller : controllers)
			score+=controller.getScore();
		return score;
	}
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		// TODO Auto-generated method stub
		controllers = new ArrayList<QuestionPaneController>();
	}
	
}

