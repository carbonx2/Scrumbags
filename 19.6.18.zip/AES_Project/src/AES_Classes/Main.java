package AES_Classes;
import java.io.File;
import java.io.FileOutputStream;
import java.util.List;
 
/**
 * Created by ONUR BASKIRT on 28.01.2016.
*/
public class Main {
    //Main Function
    public static void main(String[] args) throws Exception {
      
    	
    	File theDir = new File("Exams/1");
    	if (!theDir.exists()) 
    		theDir.mkdirs();
    	File file = new File("Exams/1/exam.docx");       	
    	FileOutputStream stream = new FileOutputStream(file);
    	
    




 
       
}
}