package Classes;

import java.io.Serializable;
import java.util.ArrayList;

public class QuestionInExam extends Question implements Serializable {
	private Integer score;
	private String noteForTeacher;
	private String noteForStudent;

	public QuestionInExam(Question question, int score) {
		super(question);
		this.score = score;
		this.noteForStudent = null;
		this.noteForTeacher = null;
	}

	public void setNoteForStudent(String note) {		
		if(note.trim().length() != 0)
			this.noteForStudent = note;
	}

	public void setNoteForTeacher(String note) {		
		if(note.trim().length() != 0)
			this.noteForTeacher = note;
	}
	
	public String getNoteForTeacher() {
		return noteForTeacher;
	}
	
	public String getNoteForStudent() {
		return noteForStudent;
	}

	public Integer getScore() {
		return score;
	}

	public void setScore(int score) {
		this.score = score;
	}
	
	public String toString() {
		return super.toString()+"\n student: "+noteForStudent+" teacher: "+noteForTeacher+" score: "+score;
		
	}

}
