package ClientGui;

import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

import Classes.Exam;
import Classes.QuestionInExam;
import javafx.beans.binding.Bindings;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Insets;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Pagination;
import javafx.scene.control.ScrollPane;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;

public class ViewExamWindowController implements Initializable {
	 
	    @FXML
	    private Pagination pagination;
	
	    public static final int itemsPerPage = 4;
		public ArrayList<QuestionInExam> questionsInExam;
		private ArrayList<ExamFormPageController> pagesList;
		private ArrayList<VBox> layoutList;
		@FXML
	    private AnchorPane OurAnchorPane;	

		@FXML
		public Button CancelButton;
		@FXML
		public Button SubmitButton;
		private ExamPreviewPageController firstPageController;
		private Node firstPageLayout;
		private Exam exam;
	
	    
		
		
		public void setQuestionsInExam(ArrayList<QuestionInExam> questionsInExam) {
			
			this.questionsInExam = questionsInExam;
			setPageCount();

		}
		
		public void setExam(Exam exam) {
			
			this.exam = exam;
		}
		
	    
	    public ScrollPane createPage(int pageIndex) {
	    		
			try {
				ScrollPane scrollPane = new ScrollPane();
				scrollPane.getStylesheets().add("FixScrollbar.css");
				scrollPane.setStyle("-fx-background-color:white");
				if (pageIndex == 0) {					
					Node layout;					
					if (firstPageController == null) {
						FXMLLoader loader = new FXMLLoader();				
												
						layout = loader.load(getClass().getResource("/ClientGui/ViewExamPreviewPage.fxml").openStream());						
						ViewExamPreviewPageController controller = loader.getController();						
						controller.setExamPreview(exam);												
						firstPageLayout = layout;
					}
					layout = firstPageLayout;
					scrollPane.setContent(layout);
					return scrollPane;
				}
				
				int page = (pageIndex - 1) * itemsPerPage;
				VBox layout;						
				if (layoutList.size() < pageIndex) {					
				    layout = new VBox();
				    layout.setStyle("-fx-background-color:white");

				    Node questionLayout;
					layoutList.add(layout);
					
					for (int i = page; i < page + itemsPerPage && i < questionsInExam.size(); i++)					{	
						FXMLLoader loader = new FXMLLoader();						
						questionLayout = loader.load(getClass().getResource("/ClientGui/ViewExamQuestionPane.fxml").openStream());			
					
						ViewExamQuestionPaneController controller = loader.getController();			
						controller.setQuestion(questionsInExam.get(i), (layoutList.size()-1)*4+(i-page)+1);
						layout.getChildren().add(questionLayout);
						
					}
				}				
				layout = layoutList.get(pageIndex-1);
				scrollPane.setContent(layout);				
				return scrollPane;
			} catch (Exception e) {
				e.printStackTrace();			
				return null;
			}
		}

		public void setPageCount() {			
			if (questionsInExam.size() % itemsPerPage == 0)
				pagination.setPageCount(questionsInExam.size() / itemsPerPage + 1);

			else
				pagination.setPageCount(questionsInExam.size() / itemsPerPage + 2);

		}
	    
	    
	    
	    
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		pagination.setPageFactory((Integer pageIndex) -> createPage(pageIndex));
		firstPageController = null;
		firstPageLayout = null;		;
		layoutList = new ArrayList<VBox>();	
	}

}
