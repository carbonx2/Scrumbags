/*package ClientGui;

import Classes.Exam;

public class FinishedExam extends Exam {
	
	public FinishedExam(Exam exam,)
}
*/