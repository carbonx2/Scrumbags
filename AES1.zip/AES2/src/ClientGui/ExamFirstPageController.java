package ClientGui;

import java.net.URL;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Observable;
import java.util.ResourceBundle;
import java.util.Timer;
import java.util.TimerTask;

import javax.sound.midi.Sequence;

import Classes.Exam;
import Classes.Student;
import Client.ExamController;
import javafx.animation.Animation;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.beans.InvalidationListener;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableIntegerValue;
import javafx.beans.value.ObservableValue;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextField;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import javafx.util.Duration;

public class ExamFirstPageController implements Initializable {

	@FXML
	private Label CourseNameLabel;

	@FXML
	private Label AuthorLabel;

	@FXML
	private Label DateLabel;

	@FXML
	private Label ExamTimeLabel;

	@FXML
	private ScrollPane NoteScrollPane;

	@FXML
	private Label ExamNotesLabel;

	@FXML
	private Label IDLabel;

	@FXML
	private TextField IDTextField;

	ExamWindowController controller;
	
	Integer remainingTime;
	
	ObservableIntegerValue RT;

	Exam exam;

	Date startTime;



	String examCode;
	Timer timer;
	public static final int MILLISECONDS = 1000;
	public static final int SECONDS = 60;
	public static int timeExtension;

	public void idListener()
	{
		if(IDTextField.getText().trim().equals(Client.Client.user.getID()))
		{
			disableEffect();
			IDLabel.setVisible(false);
			IDTextField.setVisible(false);
			controller.setPageCount();
			Calendar calendar = Calendar.getInstance();
			calendar.add(calendar.MINUTE, exam.getExamTime());
			Date finishTime = calendar.getTime();
			controller.setExamFinishTime(finishTime);
			remainingTime = exam.getExamTime();
			setRemainingTime();
			new Thread(new Runnable() {

				@Override
				public void run() {
					
					while(true)
					{
						
						ArrayList<String> answer = ExamController.startExam((Student)Client.Client.user, exam, examCode);						
						switch(answer.get(0))
						{
						case "LockExam":					
							controller.timeout(answer.get(0));
							return;
							
						case "TimeExtension":
							timeExtension += Integer.parseInt(answer.get(1));
							break;
						case "Timeout":
							controller.timeout(answer.get(0));
								return;

						default:
							controller.timeout(answer.get(0));
							return;
							
							
						}
					}
				}
			}
					).start();

		}
	}
	
	
	public void setRemainingTime()
	{
		controller.setRemainingTime(remainingTime);
		new Thread(new Runnable() {
			
			public void run()
			{
				while(remainingTime>0)
				{						
					
					try {
						Thread.sleep(60000);
					} catch (InterruptedException e) {						
						e.printStackTrace();
					}
					synchronized(remainingTime)
					{
						remainingTime-=1;
						controller.setRemainingTime(remainingTime);
					}
					
				}
		}
	}).start();;
	}
	public void setExamWindowController(ExamWindowController controller)
	{
		this.controller = controller;
	}
	public void setExamFirstPage(Exam exam) {		
		DateLabel.setText(exam.getCreationDate());
		CourseNameLabel.setText(exam.getCourse().getName());
		AuthorLabel.setText(exam.getAuthor().getName());
		ExamNotesLabel.setText(exam.getNote());
		ExamTimeLabel.setText(ExamTimeLabel.getText()+" "+exam.getExamTime());	
		this.exam = exam;
	}
	public void setExamCode(String examCode)
	{
		this.examCode = examCode;
	}

	public void disableEffect()
	{
		CourseNameLabel.setEffect(null);
		AuthorLabel.setEffect(null);
		DateLabel.setEffect(null);
		ExamTimeLabel.setEffect(null);
		NoteScrollPane.setEffect(null);
		ExamNotesLabel.setEffect(null);
	}
	
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {		
		startTime = new Date();
		timeExtension = 0;	
		
		
	}
}
