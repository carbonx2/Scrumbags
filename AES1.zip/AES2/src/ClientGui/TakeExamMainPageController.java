package ClientGui;

import java.io.IOException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Optional;
import java.util.ResourceBundle;

import Classes.Exam;
import Client.ExamController;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.TextInputDialog;
import javafx.scene.layout.AnchorPane;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ButtonBar.ButtonData;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;

public class TakeExamMainPageController implements Initializable {

	@FXML
    private AnchorPane page;
	
	@FXML
	Label FinishTimeLabel;
	
	private static final int ALLOWED_CHARACTERS_NUMBER = 4;
	
	
	
	
	
	
	public void setExamFinishTime(Date finishTime)
	{
		SimpleDateFormat formatter = new SimpleDateFormat("HH:mm");
		String time = formatter.format(finishTime);			
		FinishTimeLabel.setText(FinishTimeLabel.getText()+" "+time);
	}
	
	
	public void alert(String title, String message)
	{
		Alert alert = new Alert(AlertType.INFORMATION);
		alert.setTitle(title);
		alert.setHeaderText(null);
		alert.setContentText(message);
		alert.showAndWait();
	}
	
	
	public void getUserInput() {
		TextInputDialog dialog = new TextInputDialog();		
		dialog.setTitle("Take Exam");			
		dialog.setContentText("Enter "+ALLOWED_CHARACTERS_NUMBER+" characters execution code: ");
		dialog.setHeaderText(null);
		Optional<String> result = dialog.showAndWait();
		if(result.isPresent())				
			if(result.get().length() == ALLOWED_CHARACTERS_NUMBER)			
				if(ExamController.checkExamCode(result.get())) {
					Alert alert = new Alert(AlertType.CONFIRMATION);
					alert.setTitle("Choose exam type");
					alert.setHeaderText(null);
					alert.setContentText("Choose online to fill the exam online or manual to download a pdf for submission");
					ButtonType buttonTypeOnline = new ButtonType("Online");
					ButtonType buttonTypeManual = new ButtonType("Manual");
					ButtonType buttonTypeCancel = new ButtonType("Cancel", ButtonData.CANCEL_CLOSE);

					alert.getButtonTypes().setAll(buttonTypeOnline, buttonTypeManual, buttonTypeCancel);

					Optional<ButtonType> result2 = alert.showAndWait();
					if (result2.get() == buttonTypeOnline){
						Exam exam = ExamController.takeExam(result.get());					
												
						Stage stage = new Stage();
						stage.setTitle("Exam");		
						try {
							FXMLLoader loader = new FXMLLoader();
							Parent root = loader.load(getClass().getResource("/ClientGui/ExamWindow.fxml").openStream());			
							ExamWindowController controller = loader.getController();
							controller.setQuestionsInExam(exam.getQuestions());
							controller.setExam(exam);	
							controller.setExamCode(result.get());
							controller.setTakeExamPageController(this);
							stage.setScene(new Scene(root));
							stage.initModality(Modality.APPLICATION_MODAL);
							stage.initOwner(page.getScene().getWindow());
							stage.showAndWait();
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						
						
						
						
					} else if (result2.get() == buttonTypeManual) {
					    
					} else if (result2.get() == buttonTypeCancel) {
					    
					} else {
					    
					}		
				}
				else
					alert("","Wrong code");
			else
			alert("Exam Execution", "You need to enter 4 characters code");
	}
	
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		
	}

}
