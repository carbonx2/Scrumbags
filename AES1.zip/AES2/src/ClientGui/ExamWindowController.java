package ClientGui;

import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.ResourceBundle;

import Classes.Exam;
import Classes.QuestionInExam;
import javafx.application.Platform;
import javafx.beans.binding.Bindings;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Insets;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Pagination;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;

public class ExamWindowController implements Initializable {
	 
	    @FXML
	    private Pagination pagination;
	    @FXML
	    private Label RemainingTimeLabel;
	    public static final int itemsPerPage = 4;
		public ArrayList<QuestionInExam> questionsInExam;
		private ArrayList<ExamFormPageController> pagesList;
		private ArrayList<VBox> layoutList;
		@FXML
	    private AnchorPane OurAnchorPane;	
			
		
		private Node firstPageLayout;
		private ExamFirstPageController firstPageController;
		private ArrayList<ExamQuestionPaneController> questionsList;
		private Exam exam;
		String examCode;
	    private TakeExamMainPageController takeExamMainPageController;
		
		
	    
	    
	    public void setRemainingTime(Integer remainingTime)
	    {	    	
	    	Platform.runLater(new Runnable(){

				@Override
				public void run() {
					RemainingTimeLabel.setText("Remaining Time: "+remainingTime +" Minutes");					
				}	    		
	    	});
	    	
	    }
	    public void alert(String title, String message)
		{
	    	
			Alert alert = new Alert(AlertType.INFORMATION);
			alert.setTitle(title);
			alert.setHeaderText(null);
			alert.setContentText(message);
			alert.showAndWait();
			}
	        
	    
	    public void setExamFinishTime(Date finishTime)
	    {
	    	takeExamMainPageController.setExamFinishTime(finishTime);
	    }
	    
	    public void setTakeExamPageController(TakeExamMainPageController takeExamMainPageController)
	    {
	    	this.takeExamMainPageController = takeExamMainPageController;
	    }
	    
	    
		public void setQuestionsInExam(ArrayList<QuestionInExam> questionsInExam) {
			
			this.questionsInExam = questionsInExam;
			pagination.setPageCount(1);			

		}
		
		public void timeout(String reason)
		{
			Platform.runLater(new Runnable(){

				@Override
				public void run() {
					
					alert("Timeout","Exam time has ran out");
					pagination.getScene().getWindow().hide();
					
					
				}
				
			});
			
		}
		
		
		
		public void setExam(Exam exam) {			
			this.exam = exam;
		}
		public void setExamCode(String examCode)
		{
			this.examCode = examCode;
		}
		
		public ArrayList<ExamFormPageController> getPagesList()
		{
			return pagesList;
		}
		
		public ArrayList<QuestionInExam> getExamQuestions()
		{
			return questionsInExam;
		}
	    
	    public ScrollPane createPage(int pageIndex) {
	    		
			try {
				ScrollPane scrollPane = new ScrollPane();
				scrollPane.getStylesheets().add("FixScrollbar.css");
				scrollPane.setStyle("-fx-background-color:white");
				if (pageIndex == 0) {					
					Node layout;					
					if (firstPageController == null) {
						FXMLLoader loader = new FXMLLoader();				
												
						layout = loader.load(getClass().getResource("/ClientGui/ExamFirstPage.fxml").openStream());						
						firstPageController = loader.getController();	
						firstPageController.setExamWindowController(this);
						firstPageController.setExamFirstPage(exam);
						firstPageController.setExamCode(examCode);
						firstPageLayout = layout;						
					}
					layout = firstPageLayout;
					scrollPane.setContent(layout);
					return scrollPane;
				}
				
				int page = (pageIndex - 1) * itemsPerPage;
				VBox layout;						
				if (layoutList.size() < pageIndex) {					
				    layout = new VBox();
				    layout.setStyle("-fx-background-color:white");

				    Node questionLayout;
					layoutList.add(layout);
					
					for (int i = page; i < page + itemsPerPage && i < questionsInExam.size(); i++)					{	
						FXMLLoader loader = new FXMLLoader();						
						questionLayout = loader.load(getClass().getResource("/ClientGui/ExamQuestionPane.fxml").openStream());	
					
						ExamQuestionPaneController controller = loader.getController();			
						controller.setQuestion(questionsInExam.get(i), (layoutList.size()-1)*4+(i-page)+1);
						layout.getChildren().add(questionLayout);
						questionsList.add(controller);
						
					}
				}				
				layout = layoutList.get(pageIndex-1);
				scrollPane.setContent(layout);				
				return scrollPane;
			} catch (Exception e) {
				e.printStackTrace();			
				return null;
			}
		}

		public void setPageCount() {			
			if (questionsInExam.size() % itemsPerPage == 0)
				pagination.setPageCount(questionsInExam.size() / itemsPerPage + 1);

			else
				pagination.setPageCount(questionsInExam.size() / itemsPerPage + 2);

		}
	    
	    
	    
	    
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		pagination.setPageFactory((Integer pageIndex) -> createPage(pageIndex));
		firstPageController = null;
		firstPageLayout = null;		;
		layoutList = new ArrayList<VBox>();	
		questionsList = new ArrayList<ExamQuestionPaneController>();		
		
	}

}
