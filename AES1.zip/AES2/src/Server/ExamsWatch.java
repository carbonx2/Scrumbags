package Server;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;

import java.util.SortedSet;import java.util.TreeSet;

import Classes.Exam;
import Classes.Examinee;
import Classes.Student;
import ocsf.server.ConnectionToClient;

public class ExamsWatch {

	
	public static SortedSet<Examinee> activeExaminees = null ;
	public static HashMap<String,ConnectionToClient> connectionsExaminees;

	public static void addExaminee(ConnectionToClient client, Student student, Exam exam, String examExecutionCode )
	{
		System.out.println("3");
		if(activeExaminees == null)
		{	
			System.out.println("4");
			activeExaminees = new TreeSet<Examinee>();
			connectionsExaminees = new HashMap<String, ConnectionToClient>();
			startWatch();
		}
		System.out.println("5");
		Calendar cal = Calendar.getInstance();
		Date startTime =  cal.getTime();
		cal.add(Calendar.MINUTE, exam.getExamTime());	
		Date finishTime = cal.getTime();	

		Examinee examinee = new Examinee(student,exam,examExecutionCode, startTime, finishTime);
		
		activeExaminees.add(examinee);
		connectionsExaminees.put(student.getID(),client);
		
	}

	
	private static void startWatch()
	{
		ArrayList<Examinee> examineesToRemove= new ArrayList<Examinee>();
		new Thread(new Runnable() {
			@Override
			public void run() {
				while(true)
				{		
					
					try {
						Thread.sleep(1000);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
					Date currentTime = new Date();
					for(Examinee examinee : activeExaminees)			
					{
						if(examinee.getFinishTime().compareTo(currentTime)==1)
							break;
						else
						{
							examineesToRemove.add(examinee);					
							ExamController.endExam(connectionsExaminees.remove(examinee.getID()));
							
						}
					}	
					activeExaminees.removeAll(examineesToRemove);
					examineesToRemove.clear();
				}
			}
		}).start();
	}
}
