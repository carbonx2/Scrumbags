package Client;

import java.util.ArrayList;

import Classes.Exam;
import Classes.Packet;
import Classes.Student;
import ClientGui.Main;

public class ExamController {
	
	public static final int examResponseRequest = -1;
	
	public static String addExamToRepository(Exam exam) {
		Packet packet = new Packet("AddExam", exam);
		int requestID = Main.client.sendToServerAJ(packet);
		return Main.client.getResponse(requestID).getOperation();
	}

	public static ArrayList<Exam> getExamsList() {
		Packet packet = new Packet("GetExamsList", null);
		int requestID = Main.client.sendToServerAJ(packet);
		return (ArrayList<Exam>) Main.client.getResponse(requestID).getData();
	}

	public static ArrayList<Exam> getExamsListBySubject(String subject) {
		Packet packet = new Packet("GetExamsListBySubject", subject);
		int requestID = Main.client.sendToServerAJ(packet);
		return (ArrayList<Exam>) Main.client.getResponse(requestID).getData();
	}

	public static String removeExam(String examID) {
		Packet packet = new Packet("RemoveExam", examID);
		int requestID = Main.client.sendToServerAJ(packet);
		return Main.client.getResponse(requestID).getOperation();
	}
	
	public static boolean executeExam(String executionCode, String examID, String teacherID)
	{
		ArrayList<String> data = new ArrayList<String>();
		data.add(executionCode);
		data.add(examID);
		data.add(teacherID);
		Packet packet = new Packet("ExecuteExam", data);
		int requestID = Main.client.sendToServerAJ(packet);
		String response = Main.client.getResponse(requestID).getOperation();
		if(response.equals("Success"))
			return true;
		return false;
	}
	
	public static boolean checkExamCode(String examCode)
	{
		Packet packet = new Packet("CheckExamCode",examCode);
		int requestID = Main.client.sendToServerAJ(packet);
		String response = Main.client.getResponse(requestID).getOperation();
		if(response.equals("Success"))
			return true;
		return false; 
	}
	
	public static Exam takeExam(String examCode)	{
		
		Packet packet = new Packet("TakeExam", examCode);
		int requestID = Main.client.sendToServerAJ(packet);
		return (Exam) Main.client.getResponse(requestID).getData();		
			
		
	}
	
	public static ArrayList startExam(Student student, Exam exam, String examExecutionCode)
	{
		ArrayList<Object> data = new ArrayList<Object>();
		data.add(student);
		data.add(exam);
		data.add(examExecutionCode);
		Packet packet = new Packet("StartExam", data);
		int requestID = Main.client.sendToServerAJ(packet);		
		if( Main.client.getResponse(requestID).getOperation().equals("Success")) {
			Packet response = Main.client.getResponse(examResponseRequest);	
			data = new ArrayList<Object>();
			switch(response.getOperation()) {
			case "Timeout":
				data.add("Timeout");
				break;
			}
		}
		
		
		return data;
				
	
	}
}
