package AES_Classes;

import java.io.Serializable;
import java.sql.Date;
import java.util.ArrayList;


public class Exam implements Serializable {
	private String ID;
	private Course course;
	private Subject subject;
	private Person author;
	private Date creationDate;
	private ArrayList<Question> questions;
	private int[] scores;
	private int examTime;
	
	public Exam(String ID, Course course, Subject subject, Person author, Date creationDate,	
			ArrayList<Question> questions, int[] scores, int examTime) {
		super();
		this.ID = ID;
		this.course = course;
		this.subject = subject;
		this.author = author;
		this.creationDate = creationDate;
		this.questions = questions;
		this.scores = scores;
		this.examTime = examTime;
	}


	public String getID() {
		return ID;
	}
	
	public Course getCourse() {
		return course;
	}

	public Subject getSubject() {
		return subject;
	}

	public Person getAuthor() {
		return author;
	}

	public Date getCreationDate() {
		return creationDate;
	}

	public ArrayList<Question> getQuestions() {
		return questions;
	}

	public int[] getScores() {
		return scores;
	}

	public int getExamTime() {
		return examTime;
	}
}
