package AES_Classes;

public class Note {
	private String text;
	private int x;
	private int y;
	private Permission permission;
	
}
