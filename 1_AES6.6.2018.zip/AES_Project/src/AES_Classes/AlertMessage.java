package AES_Classes;

import javafx.application.Platform;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class AlertMessage {
	
	
	public static void Display(String title ,String msg) {
		
		Platform.runLater(new Runnable() {
			
		    @Override
		public void run() {
		
		Stage Alertwindow = new Stage();
		Alertwindow.initModality(Modality.APPLICATION_MODAL);
		Alertwindow.setTitle(title);
		Alertwindow.setWidth(250);
		Alertwindow.setHeight(100);
		
		Label message = new Label(msg);
		Button ClickToClose = new Button("OK");
		ClickToClose.setOnAction(e -> Alertwindow.close());
		
		VBox layout = new VBox(10);
		layout.getChildren().addAll(ClickToClose,message);
		layout.setAlignment(Pos.CENTER);
		
		Scene AlertScene = new Scene(layout);
		Alertwindow.setScene(AlertScene);
		Alertwindow.showAndWait();
		    }
		});
	}
}
