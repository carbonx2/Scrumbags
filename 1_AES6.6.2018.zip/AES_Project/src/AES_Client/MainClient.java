package AES_Client;

import java.io.IOException;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

public class MainClient extends Application {

	final static int DEFAULT_PORT = 5556;
	public static client client;
	public static boolean connected =false;
	public static Stage stage;

	@Override
	public void start(Stage primaryStage) throws Exception {
		// TODO Auto-generated method stub
		
		
		try {
			FXMLLoader loader = new FXMLLoader(MainClient.class.getResource("GUI_Login.fxml"));
			AnchorPane page = (AnchorPane) loader.load();
			Scene scene = new Scene(page, 600, 420);
			stage = primaryStage;
			stage.setTitle("AES LogIn");
			stage.setScene(scene);
			stage.show();
			connect("localhost",DEFAULT_PORT);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	public static boolean connect(String address,int port)
	{
		try {
			client = new client(address, port);	
		    connected=true;
		    return true;
			}
			
	    
	    catch(Exception e)
	    {	   	
	       	System.out.println(e.getMessage());
	    	connected=false;
	    	return false;
	    }
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		launch(args);
	}
	
	public static void swittchscene(Scene scene) {
		{
			Platform.runLater(new Runnable() {
				
			    @Override
			public void run() {
			stage.setScene(scene);
			    }
			});
		}
	}

}
