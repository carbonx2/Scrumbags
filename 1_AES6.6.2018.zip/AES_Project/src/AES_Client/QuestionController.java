package AES_Client;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

import AES_Classes.Packet;
import AES_Classes.Question;
import AES_Classes.Subject;
import AES_Classes.Teacher;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TreeItem;
import javafx.scene.control.TreeView;


public class QuestionController implements Initializable{
	
	Teacher teacher = (Teacher) LoginController.user; 
	static ArrayList<Question> questions;
	@FXML private static ListView<String> QuestionList;
	int HomePagePermission;
	@FXML private Label txt_loginUsername;
	@FXML private TreeView<String> Options;
	@FXML private Button btn_logOut;
	@FXML public static ComboBox<Subject> SubjectComboBox ;
	
	@FXML
	private void ClickSubject() {
		
		String Choice = SubjectComboBox.getValue().getName();
		if(Choice == "Matmatics") {
			int ID=MainClient.client.sendToServerAJ(new Packet("GetQuestionListBySubject","02"));
			questions = (ArrayList<Question>)MainClient.client.getResponse(ID).getData();
			QuestionList.getItems().clear();
			System.out.println("here");
			for(Question question:questions)    	
			QuestionList.getItems().add(question.getQuestion());
		}		
		
	}
	@FXML
	private void ClickLogOut(ActionEvent event) {
		
		Platform.runLater(new Runnable(){
            
            public void run()
            {                        
              try {
				MainClient.client.sendToServer(new Packet("LogOut",LoginController.user.getID()));
				//close   
		    	MainClient.stage.close();
			} catch (IOException e) {				
				e.printStackTrace();
			}	
                                     
         }                
        });          
        
    }
public void CreateTreeView() {	
		
		TreeItem<String> teacher = new TreeItem<>("T-Options");
		TreeItem<String> student = new TreeItem<>("S-Options");
		TreeItem<String> manger = new TreeItem<>("M-Options");
		TreeItem<String> teacherQ = new TreeItem<>("Questions");
		TreeItem<String> teacherE = new TreeItem<>("Exams");
		TreeItem<String> QList = new TreeItem<>("Questions List");
		TreeItem<String> EList = new TreeItem<>("Exam List");
		TreeItem<String> NewQ = new TreeItem<>("Create Question");
		TreeItem<String> NewE = new TreeItem<>("Create Exam");
		
		teacher.getChildren().add(teacherQ);
		teacherQ.setExpanded(true);
		teacher.getChildren().add(teacherE);
		teacherE.setExpanded(true);
		teacherQ.getChildren().add(QList);
		teacherQ.getChildren().add(NewQ);
		teacherE.getChildren().add(EList);
		teacherE.getChildren().add(NewE);
		
					
		if(HomePagePermission == 2) {
						
			Options.setRoot(teacher);
			Options.setShowRoot(false);
			
		}
		if(HomePagePermission == 3) {
			
			Options.setRoot(manger);
			Options.setShowRoot(false);			
		}		
	}
	
	@FXML
public void ClickOptions() {
	
		Platform.runLater(new Runnable(){
            
            public void run()
            {                        
              try {
		TreeItem<String> Click = Options.getSelectionModel().getSelectedItem();
		
		switch(Click.getValue()) 
		{
		
		  case "Exam List":
			  System.out.println("Exam List");
		       break;
		  case "Create Question":
			  System.out.println("Create Question");			  
		       break;
		  case "Create Exam":
			  System.out.println("Create Exam");			  
		       break;
		  default:
			  break;
		}
              }catch (Exception e) {				
  				e.printStackTrace();
  			}	
                                       
           }                
          });          
	}
@FXML
public static void getQuestionList()
	{
	int ID=MainClient.client.sendToServerAJ(new Packet("GetQuestionsList",null));
	questions = (ArrayList<Question>)MainClient.client.getResponse(ID).getData();
	QuestionList.getItems().clear();
	for(Question question:questions)    	
	QuestionList.getItems().add(question.getQuestion());
}

public static void updateCorrectAnswer(String ID,int indexNumber)
{
	ArrayList arrayList = new ArrayList();
	arrayList.add(ID);
	arrayList.add(indexNumber);
	MainClient.client.sendToServerAJ(new Packet("UpdateAnswer",arrayList));
	getQuestionList();
}

public void UpdateSubjectBox() {
	// TODO Auto-generated method stub
	SubjectComboBox.getItems().addAll(teacher.getSubjects());
	
}
@Override
public void initialize(URL arg0, ResourceBundle arg1) {
	// TODO Auto-generated method stub
	
	this.HomePagePermission = LoginController.user.getPermission();
	CreateTreeView();
	//UpdateSubjectBox();
	btn_logOut.setOnAction(this::ClickLogOut);

	
}

	
}
