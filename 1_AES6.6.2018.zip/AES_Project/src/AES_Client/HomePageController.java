package AES_Client;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import AES_Classes.Packet;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TreeItem;
import javafx.scene.control.TreeTableView;
import javafx.scene.control.TreeView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.HBox;

public class HomePageController implements Initializable{

	int HomePagePermission;
	@FXML private Label txt_loginUsername;
	@FXML private TreeView<String> Options;
	@FXML private Button btn_logOut;
		
	@FXML
	private void ClickLogOut(ActionEvent event) {
		
		Platform.runLater(new Runnable(){
            
            public void run()
            {                        
              try {
				MainClient.client.sendToServer(new Packet("LogOut",LoginController.user.getID()));
				//close   
		    	MainClient.stage.close();
			} catch (IOException e) {				
				e.printStackTrace();
			}	
                                     
         }                
        });          
        
    }
	
	public void CreateTreeView() {	
		
		TreeItem<String> teacher = new TreeItem<>("T-Options");
		TreeItem<String> student = new TreeItem<>("S-Options");
		TreeItem<String> manger = new TreeItem<>("M-Options");
		TreeItem<String> teacherQ = new TreeItem<>("Questions");
		TreeItem<String> teacherE = new TreeItem<>("Exams");
		TreeItem<String> QList = new TreeItem<>("Questions List");
		TreeItem<String> EList = new TreeItem<>("Exam List");
		TreeItem<String> NewQ = new TreeItem<>("Create Question");
		TreeItem<String> NewE = new TreeItem<>("Create Exam");
		
		teacher.getChildren().add(teacherQ);
		teacherQ.setExpanded(true);
		teacher.getChildren().add(teacherE);
		teacherE.setExpanded(true);
		teacherQ.getChildren().add(QList);
		teacherQ.getChildren().add(NewQ);
		teacherE.getChildren().add(EList);
		teacherE.getChildren().add(NewE);
		
					
		if(HomePagePermission == 2) {
						
			Options.setRoot(teacher);
			Options.setShowRoot(false);
			
		}
		if(HomePagePermission == 3) {
			
			Options.setRoot(manger);
			Options.setShowRoot(false);			
		}		
	}
	
	@FXML
	public void ClickOptions() {

		//TreeItem<String> Click = Options.getSelectionModel().getSelectedItem();
		String Click = Options.getSelectionModel().getSelectedItem().toString();
		System.out.println(Click);
		switch(Click)
		{
		case "TreeItem [ value: Questions List ]":
			
			  try {
				     
      			FXMLLoader loader1 = new FXMLLoader(MainClient.class.getResource("QuetionView.fxml"));
      			AnchorPane page1 = (AnchorPane) loader1.load();
      			Scene scene1 = new Scene(page1, 720, 430);
      			MainClient.swittchscene(scene1);
      			
     			        			
				} catch (IOException e) {				
					e.printStackTrace();
				}	
	                                     


			 break; 
		case "Exam List":
		  System.out.println("Exam List");
		  break;
		case "Create Question":
		       
			  System.out.println("Create Question");			  
		     break;
		case "Create Exam":
			  System.out.println("Create Exam");
			  break;
			  default:
				  break;
	}
	
		}


	
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		// TODO Auto-generated method stub
		
		this.HomePagePermission = LoginController.user.getPermission();
		CreateTreeView();
		btn_logOut.setOnAction(this::ClickLogOut);
		
	}
	
}
