package AES_Server;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;

import AES_Classes.Author;
import AES_Classes.Course;
import AES_Classes.Question;
import AES_Classes.Subject;

public class CourseAndSubjectController {

	public static HashSet<Subject> getSubjectList(String id){
		try {
			Statement stmt1 = Server.conn.createStatement();
			Statement stmt2 = Server.conn.createStatement();
			ResultSet rs = stmt1.executeQuery("SELECT * FROM TEACHERSUBJECTS WHERE TEACHER='"+id+"';");
			
			HashSet<Subject> ListOfSubjects = new HashSet<Subject>();
			while(rs.next())
			{
				ResultSet rs1 = stmt2.executeQuery("SELECT * FROM SUBJECTS WHERE ID='"+rs.getString(1)+"';");
				while(rs1.next()) {
				Subject subject =new Subject(rs1.getString(1),rs1.getString(2));
				ListOfSubjects.add(subject);
				}
			}
			
			return ListOfSubjects;
			
		} catch (SQLException e) {
			System.out.println("mybe here subject");
			e.printStackTrace();
			return null;
		}
	}
	
	public static HashSet<Course> getCourseList(String id){
		try {
			Statement stmt1 = Server.conn.createStatement();
			Statement stmt2 = Server.conn.createStatement();
		
			ResultSet rs = stmt1.executeQuery("SELECT * FROM TEACHERCOURSES WHERE TEACHER='"+id+"';");
			
			HashSet<Course> ListOfCourses = new HashSet<Course>();
			while(rs.next())
			{
				ResultSet rs1 = stmt2.executeQuery("SELECT * FROM COURSES WHERE ID='"+rs.getString(2)+"';");
				while(rs1.next())
				{
				Course course =new Course(rs1.getString(1),rs1.getString(2),rs1.getString(3));
				ListOfCourses.add(course);
				}
			}
			
			return ListOfCourses;
			
		} catch (SQLException e) {	
			System.out.println(e);
			e.printStackTrace();
			return null;
		}
	}
}
