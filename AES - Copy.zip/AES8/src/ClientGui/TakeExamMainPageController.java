package ClientGui;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Optional;
import java.util.ResourceBundle;

import Classes.Exam;
import Classes.Examinee;
import Classes.ManualExamFile;
import Classes.Student;
import Client.ExamController;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.TextInputDialog;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonBar.ButtonData;
import javafx.stage.FileChooser;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

public class TakeExamMainPageController implements Initializable {
	
	private String examExecutionCode;
	
	@FXML
    private Button SubmitManualButton;

    @FXML
    private Button DownloadButton;
    
    @FXML
	private Label ErrorLabel;
	
    @FXML
    private Button SubmitButton;

    @FXML
    private Button OpenButton;

    @FXML
    private Label FinishTimeLabel;

    @FXML
    private Label ExecutionCodeLabel;

    @FXML
    private TextField CodeTextField;
    
	@FXML
	private AnchorPane page;
	
	
	ManualExamFile manualExam;
	private Examinee examinee;
	public ExamWindowController examWindowController;
	public Scene examWindowScene;
	private static final int ALLOWED_CHARACTERS_NUMBER = 4;

	boolean correct = false;;


	public void enableSubmitButton()
	{
		SubmitButton.setDisable(false);
	}
	
	public void disableSubmit()
	{
		SubmitButton.setDisable(true);
	}

	public void submitExam() {
		examWindowController.submitExam("ByUser","Success");

	}

	
	public void openButtonListener()
	{
		if(examWindowScene!=null)
		{
			Stage stage = new Stage();
			stage.setTitle("Exam");	
			stage.setScene(examWindowScene);
			stage.initModality(Modality.APPLICATION_MODAL);
			stage.initOwner(page.getScene().getWindow());
			stage.showAndWait();
		}		

	}

	public void codeTextFieldListener() {
		examExecutionCode = CodeTextField.getText();
		if(examExecutionCode.length()!=4) {
			ErrorLabel.setVisible(true);
			ErrorLabel.setText("Code length should be 4 characters");
			return;
		}
		String result = ExamController.checkExamCode(examExecutionCode,MainClient.client.user.getID());	
		switch(result) {
		case "Success":	
			Alert alert = new Alert(AlertType.CONFIRMATION);			
			
			CodeTextField.setVisible(false);
			ExecutionCodeLabel.setVisible(false);
			ErrorLabel.setVisible(false);
			
			alert.setTitle("Choose exam type");
			alert.setHeaderText(null);
			
			alert.setContentText("Choose online to fill the exam online or manual to download a pdf for submission");
			ButtonType buttonTypeOnline = new ButtonType("Online");
			ButtonType buttonTypeManual = new ButtonType("Manual");
			ButtonType buttonTypeCancel = new ButtonType("Cancel", ButtonData.CANCEL_CLOSE);
			alert.getButtonTypes().setAll(buttonTypeOnline, buttonTypeManual, buttonTypeCancel);
			Optional<ButtonType> result2 = alert.showAndWait();
			if (result2.get() == buttonTypeOnline){
				setOnlineScene();
				
				Exam exam = ExamController.takeExam(examExecutionCode);									
				Stage stage = new Stage();
				stage.setTitle("Exam");		
				try {
					FXMLLoader loader = new FXMLLoader();
					Parent root = loader.load(getClass().getResource("/ClientGui/ExamWindow.fxml").openStream());			
					examWindowController = loader.getController();						 							
					examWindowController.setExamCode(examExecutionCode);
					examWindowController.setExam(exam);	
					examWindowController.setTakeExamPageController(this);
					examWindowScene = new Scene(root);
					stage.setScene(examWindowScene);
					stage.initModality(Modality.APPLICATION_MODAL);
					stage.initOwner(page.getScene().getWindow());
					stage.showAndWait();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}					
			} else if (result2.get() == buttonTypeManual) {
				setManualScene();
				
				
			} else
			{
				alert.hide();
				SubmitButton.getScene().getWindow().hide();
			}
			break;
		case "ExamCodeDoesntExist":
			ErrorLabel.setVisible(true);
			ErrorLabel.setText("Exam code does not exist");
			break;
		case "TookExamAlready":
			ErrorLabel.setVisible(true);
			ErrorLabel.setText("Exam already submitted or time is up");
			break;
		}
	}
	
	public void setOnlineScene()
	{
		SubmitButton.setVisible(true);
		SubmitButton.setDisable(true);
		OpenButton.setVisible(true);
		FinishTimeLabel.setVisible(true);
	}
	
	public void setManualScene()
	{
		DownloadButton.setVisible(true);
		SubmitManualButton.setVisible(true);
		downloadButtonListener();
		
	}
	
	public void setExamFinishTime(Date finishTime)
	{
		SimpleDateFormat formatter = new SimpleDateFormat("HH:mm");
		String time = formatter.format(finishTime);			
		FinishTimeLabel.setText(FinishTimeLabel.getText()+" "+time);
		FinishTimeLabel.setVisible(true);
	}


	public void alert(String title, String message)
	{		

		Alert alert = new Alert(AlertType.INFORMATION);
		alert.setTitle(title);
		alert.setHeaderText(null);
		alert.setContentText(message);		
		alert.showAndWait();				



	}
	
	

	public void closeWindow()
	{
		SubmitButton.getScene().getWindow().hide();
	}
	
	public void downloadButtonListener() {
		FileChooser fileChooser = new FileChooser();
		fileChooser.setTitle("Save Exam");
		fileChooser.setInitialFileName(MainClient.client.user.getID()+".docx");
		File file = fileChooser.showSaveDialog(SubmitButton.getScene().getWindow());
		if(file == null)
			return;
		ArrayList<Object> data = ExamController.takeManualExam((Student) MainClient.client.user, examExecutionCode);
		
		String answer = (String) data.get(0);
		if(answer.equals("ExamIsNotActive"))
		{	alert("Error","The exam is not active anymore");
			closeWindow();
			return;
		}	
		
		try {	
			
			ArrayList dataAnswer = (ArrayList) data.get(1);
			examinee = (Examinee) dataAnswer.get(1);
			manualExam = (ManualExamFile)dataAnswer.get(2);			
			setExamFinishTime(examinee.getFinishTime());
			FileOutputStream fos = new FileOutputStream(file);
			BufferedOutputStream bos = new BufferedOutputStream(fos);
			bos.write(manualExam.getMybytearray());
			bos.close();
			new Thread(new Runnable() {
				
				public void run() {
					ArrayList<String> data = ExamController.waitForCommand();
					String command = data.get(0);
					
					while(true){
					switch(command)
					{
					case "LockExam":		
						ExamController.submitExam(null, examinee, command);	
						alert("Exam Lock","The exam has been locked");
						SubmitButton.getScene().getWindow().hide();
						return;			
					
					/*case "TimeExtension":
						timeExtension += Integer.parseInt(answer.get(1));
						break;*/
						
					case "Timeout":
						ExamController.submitExam(null, examinee, command);	
						Platform.runLater(new Runnable()
						{

							@Override
							public void run() {
								alert("Time Out","The exam time has ran out");
								SubmitButton.getScene().getWindow().hide();
								
							}
						});
					
						return;
						
					case "Submitted":
						return;
					}
					
					}
				}
				
				
			}).start();
			
		} catch (Exception e) {			
			e.printStackTrace();
		}
		
	}
	
	public void submitManualExam() {
		FileChooser fileChooser = new FileChooser();
		fileChooser.setTitle("Send Exam");	
		File file = fileChooser.showOpenDialog(SubmitButton.getScene().getWindow());		
		byte [] mybytearray  = new byte [(int) file.length()];
	    FileInputStream fis;
		try {
			fis = new FileInputStream(file);
			BufferedInputStream bis = new BufferedInputStream(fis);	  		
			manualExam.initArray(mybytearray.length);			  
			bis.read(manualExam.getMybytearray(), 0, mybytearray.length);
			ExamController.submitManualExam(manualExam, examinee, "ByUser");
			alert("ByUser","Success");
			closeWindow();
			
		} catch (Exception e) {		
			e.printStackTrace();
		}					  
	   
		
	}
	
	
	 

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		
			}

}
