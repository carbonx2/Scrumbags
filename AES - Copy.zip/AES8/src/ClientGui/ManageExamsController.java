package ClientGui;

import java.io.IOException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.ResourceBundle;
import java.util.TreeSet;

import Classes.Course;
import Classes.Exam;
import Classes.ExecutedExam;
import Classes.FinishedExam;
import Classes.Subject;
import Classes.Teacher;
import Client.Client;
import Client.ExamController;
import javafx.application.Platform;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Cell;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.ListCell;
import javafx.scene.control.ListView;
import javafx.scene.control.Tab;
import javafx.scene.control.TextInputDialog;
import javafx.scene.control.cell.TextFieldListCell;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.BorderPane;
import javafx.scene.paint.Color;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.util.Callback;
import javafx.util.StringConverter;

public class ManageExamsController implements Initializable {
	Teacher teacher = (Teacher) Client.user;
	ArrayList<Exam> examsList;
	HashMap<Exam,String> executedExamsList;
	HashMap<ExecutedExam,HashSet<FinishedExam>> finishedExamsList;
	@FXML
	private Button ReloadFinishedExamsButton;
	@FXML
	private Tab ExamsTab;	

	@FXML
	private BorderPane ExamsPane;

	@FXML
	private AnchorPane ButtonsPane;

	@FXML
	private Button CreateExamButton;

	@FXML
	private Button RemoveExamButton;

	@FXML
	private Button ViewExamButton;

	@FXML
	private Button ExecuteExamButton;

	@FXML
	private AnchorPane ExamPane;

	@FXML
	private ListView<Exam> ExamsList;

	@FXML
	private ComboBox<Course> CourseComboBox;

	@FXML
	private ComboBox<Subject> SubjectComboBox;

	@FXML
	private Button ReloadExamsButton;

	@FXML
	private Button ReloadExecutedExamsButton;

	@FXML
	private AnchorPane ExamPreviewPane;

	@FXML
	private Label CourseNameLabel;

	@FXML
	private Label AuthorLabel;

	@FXML
	private Label DateLabel;

	@FXML
	private Label FreeTextLabel;

	@FXML
	private Label ExamTimeLabel;

	@FXML
	private Tab ExecutedExamsTab;

	@FXML
	private Tab FinishedExamsTab;

	@FXML
	private ListView<Exam> ExecutedExamsList;

	@FXML
	private AnchorPane ExecutedExamPreviewPane;

	@FXML
	private Label ExecutedCourseNameLabel;

	@FXML
	private Label ExecutedAuthorLabel;

	@FXML
	private Label ExecutedDateLabel;

	@FXML
	private Label ExecutedFreeTextLabel;

	@FXML
	private Label ExecutedExamTimeLabel;

	@FXML
	private Button LockExecutedExamButton;

	@FXML
	private Button ViewExecutedExamButton;

	@FXML
	private ListView<ExecutedExam> FinishedExamsList;

	@FXML
	private ListView<FinishedExam> StudentExamsList;

	@FXML
	private Button ReviewFinishedExamButton;

	@FXML
	private ListView<Integer> CheatingGroupList;


	public void checkCheating()
	{

		for(ExecutedExam exam : finishedExamsList.keySet()) {
			int groupNumber =1;
			FinishedExam[] list = new FinishedExam[finishedExamsList.get(exam).size()];
			finishedExamsList.get(exam).toArray(list);
			for(int i = 0 ; i < list.length-1 ; i++) {
				for(int j = i+1 ; j < list.length; j++){
					if(list[i].getAnswers().equals(list[j].getAnswers())&&list[i].getGrade()<100) {
						if(list[i].getCheatingGroupNumber()==-1)
							list[i].setCheatingGroupNumber(groupNumber++);
					list[j].setCheatingGroupNumber(list[i].getCheatingGroupNumber());
					}


				}    		
			}
		}

	}

	public void setCheatingGroupList()
	{		
		CheatingGroupList.getItems().clear();
		int maxNumber = findMaxGroupNumber(StudentExamsList.getItems());		
		if(maxNumber == -1)
			return ;

		for(int i=1 ; i<=maxNumber; i++) 		
			(CheatingGroupList).getItems().add(i);

	}

	public int findMaxGroupNumber(ObservableList<FinishedExam> examsList)
	{
		int maxNumber = -1;
		for(FinishedExam exam : examsList)
			maxNumber = exam.getCheatingGroupNumber()>maxNumber?exam.getCheatingGroupNumber():maxNumber;

			return maxNumber;	
	}

	public void reviewButtonListener()
	{
		Stage examReviewStage = new Stage();
		examReviewStage.setTitle("Exam Review Page");
		Parent root;
		try {
			FXMLLoader loader = new FXMLLoader();
			root = loader.load(getClass().getResource("/ClientGui/FinishedExamWindow.fxml").openStream());
			FinishedExamWindowController controller = loader.getController();			
			controller.setExam(StudentExamsList.getSelectionModel().getSelectedItem());
			controller.setManageExamsController(this);
			examReviewStage.setOnCloseRequest(e -> {
				e.consume();
				if(confirmationAlert("", "Are you sure you want to exit? all unsaved information will be lost."))
					examReviewStage.close();
				
			});
			Scene scene = new Scene(root);
			examReviewStage.setScene(scene);			
			examReviewStage.initModality(Modality.APPLICATION_MODAL);
			examReviewStage.initOwner(ReviewFinishedExamButton.getScene().getWindow());

			examReviewStage.showAndWait();

		} catch (IOException e) {

			e.printStackTrace();
		}

	}

	public void reloadClickedListener() {

		if (SubjectComboBox.getValue() != null) {
			updateExamListBySubject(SubjectComboBox.getValue().getID());
			if (CourseComboBox.getValue() != null)
				updateExamListByCourse(CourseComboBox.getValue().getID());
		} else
			ExamsList.getItems().clear();

	}

	public void reloadExecutedClickedListener() {
		updateExecutedExamList();		
	}

	public void reloadFinishedExamsButtonListener() {
		updateFinishedExamsList();
	}
	
	public void removeExam(Exam exam) {
		boolean answer =confirmationAlert("Remove Exam","Are you sure you want to remove the selected exam from the database?");
		if(answer)
		{
			if(!(exam.getAuthor().getID().equals(Client.user.getID())))
			{
				alert("Remove Exam", "You do not have permission to remove exams' which were not composed by you");	
				return;
			}
			ExamController.removeExam(exam.getID());
			reloadClickedListener();
			ExamPreviewPane.setVisible(false);
			RemoveExamButton.setDisable(true);
			ViewExamButton.setDisable(true);
			alert("Remove Exam","Exam has been removed from the database");
		}
	}

	public void executeExamTabListener()
	{
		updateExecutedExamList();
	}

	public void showExamPreview(Exam exam) {
		ExamPreviewPane.setVisible(true);
		CourseNameLabel.setText(exam.getCourse().getName());
		DateLabel.setText(exam.getCreationDate());
		AuthorLabel.setText("" + exam.getAuthor().getName());
		ExamTimeLabel.setText("Exam time: " + exam.getExamTime());
		FreeTextLabel.setText(exam.getNote());
	}

	public void subjectSelectionListner() {
		updateCoursesBox(SubjectComboBox.getValue().getID());
		updateExamListBySubject(SubjectComboBox.getValue().getID());
	}

	public void courseSelectionListner() {
		updateExamListByCourse(CourseComboBox.getValue().getID());
	}

	public void updateCoursesBox(String subjectID) {
		CourseComboBox.getItems().addAll(teacher.getCoursesOfSubject(subjectID));
	}

	public void updateExamListByCourse(String courseID) {
		ExamsList.getItems().clear();
		for (Exam exam : examsList) {
			if (exam.getCourse().getID().equals(courseID))
				ExamsList.getItems().add(exam);

		}
	}

	public void updateExamListBySubject(String subjectID) {
		ExamsList.getItems().clear();
		examsList = ExamController.getExamsListBySubject(subjectID);
		ExamsList.getItems().addAll(examsList);
	}

	public void updateExecutedExamList() {
		ExecutedExamsList.getItems().clear();
		executedExamsList = ExamController.getActiveExams(MainClient.client.user.getID());
		ExecutedExamsList.getItems().addAll(executedExamsList.keySet());
		ExecutedExamPreviewPane.setVisible(false);
		LockExecutedExamButton.setDisable(true);
		ViewExecutedExamButton.setDisable(true);
	}

	public void updateFinishedExamsList() {
		FinishedExamsList.getItems().clear();
		StudentExamsList.getItems().clear();
		CheatingGroupList.getItems().clear();
		finishedExamsList = ExamController.getFinishedExamsById(teacher.getID());
		if(finishedExamsList == null)
			return;		
		FinishedExamsList.getItems().setAll(finishedExamsList.keySet());	
		FinishedExamsList.getItems().sort(null);
		checkCheating();
	}

	public void updateSubmittedExamsList(ExecutedExam exam) {
		StudentExamsList.getItems().clear();
		StudentExamsList.getItems().setAll(finishedExamsList.get(exam));
		StudentExamsList.getItems().sort(null);

	}

	public void finishedExamTabListener() {
		updateFinishedExamsList();
	}

	public void createExamListener() {
		Stage stage = new Stage();
		stage.setTitle("Create Exam");
		try {
			Parent root = FXMLLoader.load(getClass().getResource("/ClientGui/SubjectAndCourseSelectionScene.fxml"));
			stage.setScene(new Scene(root));
			stage.initModality(Modality.APPLICATION_MODAL);
			stage.initOwner(CreateExamButton.getScene().getWindow());
			stage.showAndWait();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}


	public void viewExamListener()
	{
		if(ExamsList.getSelectionModel().getSelectedItem()== null)
		{
			alert("View Exam", "You need to select an exam before you can view one");	
			return;
		}

		Stage stage = new Stage();
		stage.setTitle("View Exam");		
		try {
			FXMLLoader loader = new FXMLLoader();
			Parent root = loader.load(getClass().getResource("/ClientGui/ViewExamWindow.fxml").openStream());			
			ViewExamWindowController controller = loader.getController();
			controller.setQuestionsInExam(ExamsList.getSelectionModel().getSelectedItem().getQuestions());
			controller.setExam(ExamsList.getSelectionModel().getSelectedItem());			
			stage.setScene(new Scene(root));
			stage.initModality(Modality.APPLICATION_MODAL);
			stage.initOwner(CreateExamButton.getScene().getWindow());
			stage.showAndWait();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void viewExecutedExamListener()
	{
		if(ExecutedExamsList.getSelectionModel().getSelectedItem()== null)
		{
			alert("View Exam", "You need to select an exam before you can view one");	
			return;
		}

		Stage stage = new Stage();
		stage.setTitle("View Exam");		
		try {
			FXMLLoader loader = new FXMLLoader();
			Parent root = loader.load(getClass().getResource("/ClientGui/ViewExamWindow.fxml").openStream());			
			ViewExamWindowController controller = loader.getController();
			controller.setQuestionsInExam(ExecutedExamsList.getSelectionModel().getSelectedItem().getQuestions());
			controller.setExam(ExecutedExamsList.getSelectionModel().getSelectedItem());			
			stage.setScene(new Scene(root));
			stage.initModality(Modality.APPLICATION_MODAL);
			stage.initOwner(ExecutedExamsList.getScene().getWindow());
			stage.showAndWait();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void updateSubjectBox() {
		SubjectComboBox.getItems().addAll(teacher.getSubjects());
	}

	public void setConverters() {
		SubjectComboBox.setConverter(new StringConverter<Subject>() {
			public String toString(Subject subject) {
				return subject.getName();
			}

			@Override
			public Subject fromString(String arg0) {
				return null;
			}

		});

		CourseComboBox.setConverter(new StringConverter<Course>() {

			public String toString(Course course) {
				return course.getName();
			}

			@Override
			public Course fromString(String arg0) {
				return null;
			}

		});

		ExamsList.setCellFactory(lv -> {
			TextFieldListCell<Exam> cell = new TextFieldListCell<Exam>();
			cell.setConverter(new StringConverter<Exam>() {
				@Override
				public String toString(Exam exam) {
					return exam.getCreationDate() + "      Course: " + exam.getCourse().getName() + "      Author: "
							+ exam.getAuthor().getName();
				}

				@Override
				public Exam fromString(String string) {
					return null;
				}
			});
			return cell;
		});

		ExecutedExamsList.setCellFactory(lv -> {
			TextFieldListCell<Exam> cell = new TextFieldListCell<Exam>();
			cell.setConverter(new StringConverter<Exam>() {
				@Override
				public String toString(Exam exam) {
					return "Code: "+executedExamsList.get(exam) + "      Course: " + exam.getCourse().getName() + "      Author: "
							+ exam.getAuthor().getName();
				}

				@Override
				public Exam fromString(String string) {
					return null;
				}
			});
			return cell;
		});
		
		FinishedExamsList.setCellFactory(lv -> {
			TextFieldListCell<ExecutedExam> cell = new TextFieldListCell<ExecutedExam>();
			cell.setConverter(new StringConverter<ExecutedExam>() {
				@Override
				public String toString(ExecutedExam exam) {
					String dateStr = new SimpleDateFormat("dd/MM/yyyy").format(exam.getExecutionDate());
					return exam.getId()+" "+exam.getSubject().getName()+" "+dateStr;
				}

				@Override
				public ExecutedExam fromString(String string) {
					return null;
				}
			});
			return cell;
		});

	}

	public void setStudentExamsListFactory()
	{
		
		StudentExamsList.setCellFactory(new Callback<ListView<FinishedExam>, ListCell<FinishedExam>>() {
			@Override
			public ListCell<FinishedExam> call(ListView<FinishedExam> param) {					
				return new ListCell<FinishedExam>() {
					@Override
					protected void updateItem(FinishedExam item, boolean empty) {
						super.updateItem(item, empty);
						
						if (item != null) {								
							if(CheatingGroupList.getSelectionModel().getSelectedItem() !=null && item.getCheatingGroupNumber() == CheatingGroupList.getSelectionModel().getSelectedItem() ) {									
								setStyle("-fx-background-color: red");
								
							}
							String str = finishedExamConverter(item);
							if(item.getFinalGrade()==-1)
								setText("New!!  "+str);
							else
								setText(str);
						}
						else
							setText(null);
					}
				};
			}
		});
	}


	public void removeButtonListener()
	{
		removeExam(ExamsList.getSelectionModel().getSelectedItem());
	}

	public void alert(String title, String message)
	{
		Alert alert = new Alert(AlertType.INFORMATION);
		alert.setTitle(title);
		alert.setHeaderText(null);
		alert.setContentText(message);
		alert.showAndWait();

	}

	public boolean confirmationAlert(String title,String message)
	{
		Alert alert = new Alert(AlertType.CONFIRMATION);
		alert.setContentText(message);
		alert.setHeaderText(title);
		alert.setGraphic(null);
		Optional<ButtonType> result = alert.showAndWait();

		if (result.get() == ButtonType.OK){
			alert.close();
			return true;

		}
		else {
			alert.close();
			return false;
		}		
	}

	public void executeButtonListener() {							

		TextInputDialog dialog = new TextInputDialog();		
		dialog.setTitle("Exam Execution");			
		dialog.setContentText("Enter 4 characters execution code: ");
		dialog.setHeaderText(null);
		Optional<String> result = dialog.showAndWait();
		if(result.isPresent())				
			if(result.get().length() == 4)				
				if(ExamController.executeExam(result.get(), ExamsList.getSelectionModel().getSelectedItem(), teacher.getID() )) {
					dialog.close();
					alert("Exam Execution","Exam was successfully executed!");
				}
				else
					alert("Exam Execution","Code already in use.");
			else
				alert("Exam Execution", "You need to enter 4 characters code");
	}

	public void setExamListener()
	{
		ExamsList.getSelectionModel().selectedItemProperty().addListener(e -> {
			Exam exam = ExamsList.getSelectionModel().getSelectedItem();			
			if (exam != null)
			{
				showExamPreview(exam);
				RemoveExamButton.setDisable(false);
				ViewExamButton.setDisable(false);
				ExecuteExamButton.setDisable(false);
			}
		});

	}

	public void showExecutedExamPreview(Exam exam) {
		ExecutedExamPreviewPane.setVisible(true);
		ExecutedCourseNameLabel.setText(exam.getCourse().getName());
		ExecutedDateLabel.setText(exam.getCreationDate());
		ExecutedAuthorLabel.setText("" + exam.getAuthor().getName());
		ExecutedExamTimeLabel.setText("Exam time: " + exam.getExamTime());
		ExecutedFreeTextLabel.setText(exam.getNote());
	}

	public void setExecutedExamListener()
	{
		ExecutedExamsList.getSelectionModel().selectedItemProperty().addListener(e -> {
			Exam exam = ExecutedExamsList.getSelectionModel().getSelectedItem();			
			if (exam != null)
			{
				showExecutedExamPreview(exam);			    
				LockExecutedExamButton.setDisable(false);			    
				ViewExecutedExamButton.setDisable(false);

			}
		});

	}

	public void lockExam(String code) {
		ExamController.lockExam(code);
		updateExecutedExamList();
	}

	public void lockExamButtonListener() {
		lockExam(executedExamsList.get(ExecutedExamsList.getSelectionModel().getSelectedItem()));
	}
	
	public void setFinishedExamsListener()
	{
		FinishedExamsList.getSelectionModel().selectedItemProperty().addListener(e -> {			
			ExecutedExam exam = FinishedExamsList.getSelectionModel().getSelectedItem();
			

			if (exam != null)
			{
				updateSubmittedExamsList(exam);
				ReviewFinishedExamButton.setDisable(true);
				setCheatingGroupList();
				StudentExamsList.getSelectionModel().selectedItemProperty().addListener(e1 -> {
					ReviewFinishedExamButton.setDisable(false);
				});
			}
			setStudentExamsListFactory();

			

		});
	}
	
	public void setCheatingGroupListListener()
	{
		CheatingGroupList.getSelectionModel().selectedItemProperty().addListener(e -> {
			StudentExamsList.getSelectionModel().clearSelection();
			ReviewFinishedExamButton.setDisable(true);
			setStudentExamsListFactory();
		});
	}

	public String finishedExamConverter(FinishedExam exam)
	{
		return "Student: "+exam.getExaminee().getName()+" "+exam.getExaminee().getID();
	}
	
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		updateSubjectBox();
		setConverters();
		setExamListener();
		setExecutedExamListener();
		setFinishedExamsListener();
		setCheatingGroupListListener();

	}
}
