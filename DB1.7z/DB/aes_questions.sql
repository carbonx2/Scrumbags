-- MySQL dump 10.13  Distrib 5.7.12, for Win64 (x86_64)
--
-- Host: localhost    Database: aes
-- ------------------------------------------------------
-- Server version	5.7.17-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `questions`
--

DROP TABLE IF EXISTS `questions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `questions` (
  `ID` varchar(5) NOT NULL,
  `Author` varchar(9) NOT NULL,
  `Question` text,
  `Answer1` text,
  `Answer2` text,
  `Answer3` text,
  `Answer4` text,
  `CorrectAnswer` int(1) DEFAULT NULL,
  `Available` int(11) DEFAULT '1',
  PRIMARY KEY (`ID`),
  KEY `Author` (`Author`),
  CONSTRAINT `questions_ibfk_1` FOREIGN KEY (`Author`) REFERENCES `teachers` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `questions`
--

LOCK TABLES `questions` WRITE;
/*!40000 ALTER TABLE `questions` DISABLE KEYS */;
INSERT INTO `questions` VALUES ('01000','307862557','What gives the blood its red color?',' plasma','copper','hemoglobin','The reason is unknown',3,1),('01001','307862557','Which of the following is incorrect for the blood cells?','Every living creature has blood cells','All blood cells have a nucleus','New blood cells form from existing blood cells','All the sentences are correct',2,1),('01002','307862557','Where do red blood cells form?','In the bones','Kidneys',' In the liver',' In the brain',1,1),('01003','307862557','How many types of blood cells are in the body of an adult?','about 1000','about 500','about 200','about 300',3,1),('01004','307862557','New skin cells form in the lower layer of the skin. How long does it take them to reach the top layer?','a day','week','a month','Two weeks',3,1),('01005','307862557','What are estimated blood cells in an adult?','About 150 million','About 200 million','About 100 million','About 150 million',3,1),('01006','307862557','Connections between neurons require the presence of ________','electrical power','Enzymes','Hormones','Neurotransmitters',4,1),('02000','313740664','10 * 10 + 8','180','108','80','No answer',2,1),('02001','313740664','Root of 16 his? ','1','4','8','3',2,1),('02002','313740664','If 2 = 6 , 3=12 , 4 =20 , 5=30 , 6 =42 , 9= ?','56','63','72','90',4,1),('02003','313740664','3^5 + 7','250','245','247','238',1,1),('03000','307862557','What is calligraphy?','A kind of artistic poetry','A kind of artistic dance','Kind of artistic writing','A kind of musical art',3,1),('03001','307862557','What was the main theme that dominated the ancient paintings?','View','The sons of Edom','flowers','Animals',4,1),('03002','307862557','Who is the architect who founded the Bauhaus Design School?','Walter Gropius','Frank Lloyd Wright','Faye','Frank Gehry',1,1),('03003','307862557','What color is created from a combination of pigments and plastics?','Tempra',' Acryl','Jesso','Gouache',2,1),('03004','307862557','Where is the famous Leonardo da Vinci painting \"The Last Supper\"?','Milan, Italy','At the National Gallery in London, England','At the Metropolitan Museum in New York, USA','At the Louvre Museum in Paris',1,1),('03005','307862557','Which of the following paintings is not a work of art by Leonardo da Vinci?','The admiration for Meggie','The Last Supper','Baptism of Jesus','The last sentence',4,1),('03006','307862557','Which animal usually represents peace in works of art?','sheep',' A peacock','Pigeon','goat',3,1),('03007','307862557','How many pictures Vincent Van Gogh sold in his life?','1','27','15','3',1,1),('04000','204677736','Which of the following elements should not appear as part of the API?','A description of the value it returns','A description of changing the state of the object it causes','A description of the methods she reads',' A description of the PRE-CONDITION requirements it requires',1,1),('04001','204677736','כf(10) ? - > public static int f(int x) {   if (x == 0) return 1;   return f(x-1)+f(x-1);} ','1','10','100','1024',4,1),('04002','204677736','What is \"out\" in the next line?System.out.println (\"Hello World\");','A package in a package','Sub-package in the System package','Static field in System class','A word is reserved for JAVA',3,1),('04003','204677736','None of the following can be done by a Turing machine','The program is written in JAVA','Check whether the JAVA program is compiling','Check whether the JAVA program includes a method called HALT','Check whether the JAVA program includes a method that enters an infinite loop',4,1),('05000','204677736','The main difference between a behavioral psychologist and a humanistic psychologist is that:','The behavioral psychologist is interested in animals and the humanist is interested in humans','The behavioral psychologist is interested in conscious thinking processes and the humanist is interested in unconscious thinking processes','The behavioral psychologist is interested in things that can be quantified and humanistic is interested in human experience','The behavioral psychologist is interested in stimulation and the humanistic response is interested in the relationship between unconditional stimulation and other unconditional stimulation',4,0),('05001','204677736','BlindBabies','Do not smile','Smiling at a late age','Smiling earlier than usual','Smiling normally',4,1),('05002','204677736','Your alpha waves of mind indicate:פתח ב-Google Translate','Very deep sleep','A state of quiet rest','Dreaming','Active alertness',2,1),('05003','204677736','Esther had a terrible experience, until she repressed any memory of her. These memories:','Stuck in working memory','Do not access ads','Lost forever','They are distilled from work memory due to anxiety',2,1),('05004','204677736','About ____________ of adults in the US claim to feel tired during your day','90%','5%','75%','50%',4,1),('05005','204677736','Which of the following is DSM-IV?','drug addiction','autism','anorexia','Everyone counts',4,1),('05006','204677736','The \"social support theory\" served for the researcher the function of:','The explanation','The construction','The prediction','All the answers are correct',1,1),('05007','204677736','What is the most appropriate measuring scale for measuring the \"marital status\" variable?','Order / Ordinali','Profit / Interval','My name / Nominal','Dose / ratio',3,1),('05008','204677736','Which of the following is required to prove a causal relationship?','Correlation between the variables appearing in the research hypothesis.','Refutation of alternative explanations.','Establishing the order of the times so that the cause preceded the result.',' All the answers are correct',4,1),('05009','204677736','Which of the following variables is a variable measured in an Ordinal scale?','Eye color','Years of education','monthly income','Extent of support for assassinations policy',4,1),('05010','204677736','What is the most appropriate measurement scale for examining the variable - \"Star rating by star\"','Dose / ratio','Ordinali / Order','Interval / Space','My name / Nominal',2,1),('05011','204677736','One of the forms of reliability testing is an correlation test between two parallel versions. This method is called:','Reliability of the repeat test','Reliability among judges','Reliability as internal consistency','Reliability as equivalence',4,1),('06000','204677736','How many games should you play in tennis to finish the round?','8','6','10','4',2,1),('06001','204677736','What time should the rider ride on the bull to gain points?','2 min','1 min','40 sec','8 sec',4,1),('06002','204677736','How many feathers are there in a feather ball (in a badminton game)?','25','11','16','23',3,1),('06003','204677736','Which of the following describes the correct order in a triathlon?',' Swimming - Bicycles - Marathon Run','Running a half-marathon - a bicycle - swimming','Bicycle - Swimming - marathon run','Swimming - Running a marathon - a bicycle',2,1),('06004','204677736','The highest level in Karate is a black belt. What is the first rank?','Yellow belt','White belt','Green belt','Blue belt',2,1),('06005','204677736','What is the national sports game in China?','Ice hockey',' tennis','table tennis','  judo',3,1),('06006','204677736','Who is the rider who won the Tour de France seven consecutive times?','Andre Agassi','Bjorn Borg','Lance Armstrong','Chris Joyfrey',3,1),('06007','204677736','In a snooker game, how many balls are on the table at the beginning of the game?','10','2','18','22',4,1),('06008','204677736','In a baseball game (baseball), how many players does each team have?','6','8','9','10',3,1),('06009','204677736','What is the national sport game of Japan?','golf','Sumo wrestling','table tennis','Fencing',2,1);
/*!40000 ALTER TABLE `questions` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-06-26 16:22:47
