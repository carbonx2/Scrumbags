-- MySQL dump 10.13  Distrib 5.7.12, for Win64 (x86_64)
--
-- Host: localhost    Database: aes
-- ------------------------------------------------------
-- Server version	5.7.17-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `finishedexams`
--

DROP TABLE IF EXISTS `finishedexams`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `finishedexams` (
  `ID` int(11) NOT NULL,
  `Exam` varchar(6) DEFAULT NULL,
  `Examinee` varchar(9) NOT NULL,
  `StartTime` varchar(45) DEFAULT NULL,
  `FinishTime` varchar(45) DEFAULT NULL,
  `Completion Time` int(11) DEFAULT NULL,
  `SubmissionType` varchar(45) DEFAULT NULL,
  `Grade` int(11) DEFAULT NULL,
  `FinalGrade` int(11) DEFAULT NULL,
  `GradeNote` text,
  `Type` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`ID`,`Examinee`),
  KEY `FK3_Exam_idx` (`Exam`),
  KEY `FK_Examiniee_idx` (`Examinee`),
  KEY `FK_ID_idx` (`ID`),
  CONSTRAINT `FK3_Exam` FOREIGN KEY (`Exam`) REFERENCES `exams` (`ID`),
  CONSTRAINT `FK_Examiniee` FOREIGN KEY (`Examinee`) REFERENCES `students` (`ID`),
  CONSTRAINT `FK_ID` FOREIGN KEY (`ID`) REFERENCES `executedexams` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `finishedexams`
--

LOCK TABLES `finishedexams` WRITE;
/*!40000 ALTER TABLE `finishedexams` DISABLE KEYS */;
INSERT INTO `finishedexams` VALUES (1,'063200','188888881','Tue Jun 26 15:42:23 IDT 2018','Tue Jun 26 15:42:40 IDT 2018',0,'ByUser',100,-1,'null','Online'),(2,'063400','188888810','Tue Jun 26 15:45:27 IDT 2018','Tue Jun 26 15:45:35 IDT 2018',0,'ByUser',0,0,'goos student','Online'),(2,'063400','188888812','Tue Jun 26 15:45:59 IDT 2018','Tue Jun 26 15:46:12 IDT 2018',0,'ByUser',10,10,'null','Online'),(2,'063400','188888814','Tue Jun 26 15:46:25 IDT 2018','Tue Jun 26 15:46:33 IDT 2018',0,'ByUser',25,25,'null','Online'),(2,'063400','188888881','Tue Jun 26 15:43:05 IDT 2018','Tue Jun 26 15:46:53 IDT 2018',3,'ByUser',10,10,'null','Online'),(2,'063400','188888883','Tue Jun 26 15:43:56 IDT 2018','Tue Jun 26 15:44:08 IDT 2018',0,'ByUser',35,35,'null','Online'),(2,'063400','188888885','Tue Jun 26 15:44:22 IDT 2018','Tue Jun 26 15:44:30 IDT 2018',0,'ByUser',10,25,'Nice','Online'),(2,'063400','188888887','Tue Jun 26 15:44:43 IDT 2018','Tue Jun 26 15:44:51 IDT 2018',0,'ByUser',25,25,'null','Online'),(2,'063400','188888889','Tue Jun 26 15:45:05 IDT 2018','Tue Jun 26 15:45:15 IDT 2018',0,'ByUser',0,0,'null','Online'),(3,'052802','188888814','Tue Jun 26 15:46:44 IDT 2018','Tue Jun 26 15:48:05 IDT 2018',1,'ByUser',70,70,'null','Online'),(3,'052802','188888815','Tue Jun 26 15:47:26 IDT 2018','Tue Jun 26 15:47:41 IDT 2018',0,'ByUser',20,20,'null','Online'),(3,'052802','188888817','Tue Jun 26 15:47:53 IDT 2018','Tue Jun 26 15:49:17 IDT 2018',1,'ByUser',40,40,'null','Online'),(3,'052802','188888818','Tue Jun 26 15:49:04 IDT 2018','Tue Jun 26 15:49:12 IDT 2018',0,'ByUser',50,50,'null','Online'),(3,'052802','188888820','Tue Jun 26 15:48:21 IDT 2018','Tue Jun 26 15:48:29 IDT 2018',0,'ByUser',60,60,'null','Online'),(4,'052601','188888815','Tue Jun 26 15:54:52 IDT 2018','Tue Jun 26 15:55:01 IDT 2018',0,'ByUser',35,35,'null','Online'),(4,'052601','188888818','Tue Jun 26 15:50:13 IDT 2018','Tue Jun 26 15:53:48 IDT 2018',3,'ByUser',55,55,'null','Online'),(4,'052601','188888881','Tue Jun 26 15:51:11 IDT 2018','Tue Jun 26 15:51:21 IDT 2018',0,'ByUser',55,55,'null','Online'),(4,'052601','188888883','Tue Jun 26 15:51:39 IDT 2018','Tue Jun 26 15:51:46 IDT 2018',0,'ByUser',20,20,'null','Online'),(4,'052601','188888887','Tue Jun 26 15:50:45 IDT 2018','Tue Jun 26 15:50:53 IDT 2018',0,'ByUser',35,35,'null','Online'),(4,'052601','188888889','Tue Jun 26 15:53:42 IDT 2018','Tue Jun 26 15:55:06 IDT 2018',1,'ByUser',20,20,'null','Online'),(5,'042200','188888880','Tue Jun 26 15:54:59 IDT 2018','Tue Jun 26 15:56:04 IDT 2018',1,'ByUser',0,-1,'null','Online'),(5,'042200','188888882','Tue Jun 26 15:55:54 IDT 2018','Tue Jun 26 15:57:16 IDT 2018',1,'ByUser',50,-1,'null','Online'),(6,'063300','188888810','Tue Jun 26 15:56:06 IDT 2018','Tue Jun 26 15:56:11 IDT 2018',0,'ByUser',25,25,'null','Online'),(6,'063300','188888811','Tue Jun 26 15:57:55 IDT 2018','Tue Jun 26 15:58:57 IDT 2018',1,'ByUser',75,75,'null','Online'),(6,'063300','188888814','Tue Jun 26 15:57:15 IDT 2018','Tue Jun 26 15:57:21 IDT 2018',0,'ByUser',50,50,'null','Online'),(6,'063300','188888815','Tue Jun 26 15:55:38 IDT 2018','Tue Jun 26 15:58:27 IDT 2018',2,'ByUser',75,75,'null','Online'),(6,'063300','188888817','Tue Jun 26 15:56:51 IDT 2018','Tue Jun 26 15:56:57 IDT 2018',0,'ByUser',50,50,'null','Online'),(6,'063300','188888820','Tue Jun 26 15:56:29 IDT 2018','Tue Jun 26 15:56:37 IDT 2018',0,'ByUser',75,75,'null','Online'),(8,'031300','188888880','Tue Jun 26 15:34:20 IDT 2018','Tue Jun 26 15:36:21 IDT 2018',2,'Timeout',0,0,'null','Online'),(8,'031300','188888882','Tue Jun 26 15:36:11 IDT 2018','Tue Jun 26 15:36:53 IDT 2018',0,'ByUser',0,0,'null','Online'),(9,'052700','188888811','Tue Jun 26 16:08:23 IDT 2018','Tue Jun 26 16:08:28 IDT 2018',0,'ByUser',30,-1,'null','Online'),(9,'052700','188888813','Tue Jun 26 16:09:07 IDT 2018','Tue Jun 26 16:09:11 IDT 2018',0,'ByUser',57,-1,'null','Online'),(9,'052700','188888815','Tue Jun 26 16:09:44 IDT 2018','Tue Jun 26 16:09:50 IDT 2018',0,'ByUser',0,-1,'null','Online'),(9,'052700','188888819','Tue Jun 26 16:10:08 IDT 2018','Tue Jun 26 16:10:31 IDT 2018',0,'ByUser',16,-1,'null','Online'),(9,'052700','188888820','Tue Jun 26 16:10:49 IDT 2018','Tue Jun 26 16:10:57 IDT 2018',0,'ByUser',30,-1,'null','Online'),(9,'052700','188888885','Tue Jun 26 16:07:26 IDT 2018','Tue Jun 26 16:11:01 IDT 2018',3,'ByUser',57,-1,'null','Online'),(9,'052700','188888887','Tue Jun 26 16:07:58 IDT 2018','Tue Jun 26 16:08:03 IDT 2018',0,'ByUser',30,-1,'null','Online'),(11,'020400','188888880','Tue Jun 26 15:59:20 IDT 2018','Tue Jun 26 16:01:37 IDT 2018',2,'ByUser',0,0,'null','Online'),(11,'020400','188888882','Tue Jun 26 15:59:45 IDT 2018','Tue Jun 26 15:59:52 IDT 2018',0,'ByUser',0,45,'nice student','Online'),(12,'063300','188888810','Tue Jun 26 16:08:37 IDT 2018','Tue Jun 26 16:08:45 IDT 2018',0,'ByUser',50,50,'null','Online'),(12,'063300','188888812','Tue Jun 26 16:09:17 IDT 2018','Tue Jun 26 16:09:24 IDT 2018',0,'ByUser',75,75,'null','Online'),(12,'063300','188888814','Tue Jun 26 16:10:12 IDT 2018','Tue Jun 26 16:10:20 IDT 2018',0,'ByUser',25,25,'null','Online'),(12,'063300','188888816','Tue Jun 26 16:10:45 IDT 2018','Tue Jun 26 16:10:53 IDT 2018',0,'ByUser',25,25,'null','Online'),(12,'063300','188888880','Tue Jun 26 16:05:16 IDT 2018','Tue Jun 26 16:11:03 IDT 2018',5,'ByUser',50,50,'null','Online'),(12,'063300','188888882','Tue Jun 26 16:05:40 IDT 2018','Tue Jun 26 16:06:46 IDT 2018',1,'ByUser',50,50,'null','Online'),(12,'063300','188888886','Tue Jun 26 16:07:27 IDT 2018','Tue Jun 26 16:07:35 IDT 2018',0,'ByUser',50,50,'null','Online'),(12,'063300','188888888','Tue Jun 26 16:07:58 IDT 2018','Tue Jun 26 16:08:08 IDT 2018',0,'ByUser',0,0,'null','Online'),(13,'063400','188888810','Tue Jun 26 16:14:47 IDT 2018','Tue Jun 26 16:14:57 IDT 2018',0,'ByUser',0,0,'null','Online'),(13,'063400','188888812','Tue Jun 26 16:14:15 IDT 2018','Tue Jun 26 16:14:23 IDT 2018',0,'ByUser',0,0,'null','Online'),(13,'063400','188888814','Tue Jun 26 16:13:45 IDT 2018','Tue Jun 26 16:13:53 IDT 2018',0,'ByUser',0,0,'null','Online'),(13,'063400','188888816','Tue Jun 26 16:13:13 IDT 2018','Tue Jun 26 16:13:20 IDT 2018',0,'ByUser',0,0,'null','Online'),(13,'063400','188888818','Tue Jun 26 16:12:48 IDT 2018','Tue Jun 26 16:16:24 IDT 2018',3,'ByUser',85,85,'null','Online'),(13,'063400','188888886','Tue Jun 26 16:16:08 IDT 2018','Tue Jun 26 16:16:16 IDT 2018',0,'ByUser',0,0,'null','Online'),(13,'063400','188888888','Tue Jun 26 16:15:35 IDT 2018','Tue Jun 26 16:15:48 IDT 2018',0,'ByUser',25,25,'null','Online');
/*!40000 ALTER TABLE `finishedexams` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-06-26 16:22:47
