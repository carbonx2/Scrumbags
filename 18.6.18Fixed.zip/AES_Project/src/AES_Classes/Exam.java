package AES_Classes;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;

import javafx.collections.ObservableList;

public class Exam implements Serializable {
	private String ID;
	private Course course;
	private Subject subject;
	private Person author;
	private String creationDate;
	private ArrayList<QuestionInExam> questions;
	private int examTime;
	private String note;

	/**
	 * This method Create new Exam
	 * @param course The course  which the exam belongs to
	 * @param subject  The subject which the exam belongs to
	 * @param author  The author which create the exam
	 * @param creationDate when the exam create
	 * @param examTime the duration of the exam , default = 0 min.
	 * Create array list for question in exam
	 */
	public Exam(String ID, Course course, Subject subject, Person author, String creationDate, int examTime) {
		super();
		this.ID = ID;
		this.course = course;
		this.subject = subject;
		this.author = author;
		this.creationDate = creationDate;
		this.examTime = examTime;
		this.questions = new ArrayList<QuestionInExam>();
}
	/**
	 * This method Create new Exam that submit 
	 * @param course The course  which the exam belongs to
	 * @param subject  The subject which the exam belongs to
	 * @param author  The author which create the exam
	 * @param creationDate when the exam create
	 * @param examTime the duration of the exam , default = 0 min.
	 * @param questions ArrayList of question that will be in the exam	
	 */
	public Exam(String ID, Course course, Subject subject, Person author, String creationDate,
			ArrayList<QuestionInExam> questions, int examTime) {
		this(ID, course, subject, author, creationDate, examTime);
		this.questions = questions;
	}
	public Exam(Exam exam) {
		this(exam.getID(),exam.getCourse(),exam.getSubject(),exam.getAuthor(),exam.getCreationDate(), exam.getQuestions(),exam.getExamTime());
	}
	/**
	 * This method add to Exam the duration time
	 */ 
	public void setExamTime(int examTime) {
		this.examTime=examTime;
	}
	/**
	 *@return ID This method Return exam ID
	  */
	public String getID() {
		return ID;
	}
	/**
	 * @return course This method Return the course id to which the exam belongs
	  */
	public Course getCourse() {
		return course;
	}
	/**
	 * @return subject This method Return the subject id to which the exam belongs
	  */
	public Subject getSubject() {
		return subject;
	}
	/**
	 * @return author This method Return the author who create the exam
	  */
	public Person getAuthor() {
		return author;
	}
	/**
	 * @return creationDate This method Return when the exam created 
	  */
	public String getCreationDate() {
		return creationDate;
	}
	/**
	 *@return questions This method Return array list of questions in the exam
	  */
	public ArrayList<QuestionInExam> getQuestions() {
		return questions;
	}
	/**
	 * @return examTime This method Return the duration time of exam
	  */
	public int getExamTime() {
		return examTime;
	}
	/**
	 * This method add to Exam note
	 */ 
	public void setNote(String note) {
		this.note = note;
	}
	/**
	 * @return note This method Return the Exam note
	 */ 
	public String getNote()
	{
		return note;
	}
	/**
	 * This method add question with score to exam 
	 * adding to array list of questions
	 */ 
	public void addQuestion(Question question, int score) {
		questions.add(new QuestionInExam(question, score));
	}
	/**
	 * This method add question that  selected by client to exam 
	 * adding to array list of questions
	 */ 
	public void setQuestions(ObservableList<QuestionInExam> questions)
	{
		for(QuestionInExam question:questions)
			this.questions.add(question);
	}
	/**
	 * This method Return all exam details
	  */
	public String toString() {
		StringBuilder questionSB = new StringBuilder();
		for (QuestionInExam question : questions)
			questionSB.append(question + ", score(" + question.getScore() + ")\n");
		return "ID(" + ID + "), course(" + course + "), subject(" + subject + "), author(" + author + "), creationDate("
				+ creationDate + "), examTime(" + examTime + ") \nNote: "+note+"\nquestions:\n" + questionSB + " \n";

	}
}
