package ClientGUI;

import java.net.URL;
import java.util.ResourceBundle;

import AES_Classes.Exam;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;

public class ViewExamPreviewPageController implements Initializable {   

	
	
    @FXML
    private Label CourseNameLabel;

    @FXML
    private Label AuthorLabel;

    @FXML
    private Label DateLabel;

    @FXML
    private Label ExamTimeLabel;

    @FXML
    private Label ExamNotesLabel;
    
    @FXML
    private ScrollPane NoteScrollPane;
    

    public void setExamPreview(Exam exam) {	
    	    	
		DateLabel.setText(exam.getCreationDate());
		CourseNameLabel.setText(exam.getCourse().getName());
		AuthorLabel.setText(exam.getAuthor().getName());
		ExamNotesLabel.setText(exam.getNote());
		ExamTimeLabel.setText(ExamTimeLabel.getText()+" "+exam.getExamTime());		
	}


	@Override
	public void initialize(URL location, ResourceBundle resources) {
		// TODO Auto-generated method stub
		
	}
}
