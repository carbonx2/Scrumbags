package Classes;

import java.io.Serializable;
import java.util.Date;
public class Examinee extends Student implements Serializable, Comparable {
	
	Exam exam;
	String examExecutionCode;
	Date startTime;
	Date finishTime;
	
	public Examinee(Student student, Exam exam, String examExecutionCode, Date startTime, Date finishTime) {
		super(student);
		this.exam = exam;
		this.examExecutionCode = examExecutionCode;
		this.startTime = startTime;
		this.finishTime = finishTime;		
	}



	public Date getFinishTime() {
		return finishTime;
	}

	

	public Exam getExam() {
		return exam;
	}



	public void setExam(Exam exam) {
		this.exam = exam;
	}



	public String getExamExecutionCode() {
		return examExecutionCode;
	}



	public void setExamExecutionCode(String examExecutionCode) {
		this.examExecutionCode = examExecutionCode;
	}



	public Date getStartTime() {
		return startTime;
	}



	public void setStartTime(Date startTime) {
		this.startTime = startTime;
	}



	public void setFinishTime(Date finishTime) {
		this.finishTime = finishTime;
	}



	@Override
	public int compareTo(Object o) {
		return this.finishTime.compareTo(((Examinee) o).getFinishTime());
	}

}