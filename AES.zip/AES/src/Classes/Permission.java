package Classes;

public enum Permission {
	NONE, STUDNET, TEACHER, MANAGER, ADMIN
};
