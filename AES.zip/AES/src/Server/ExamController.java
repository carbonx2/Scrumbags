package Server;

import java.io.IOException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;

import com.mysql.cj.ServerVersion;

import Classes.Course;
import Classes.Exam;
import Classes.Examinee;
import Classes.FinishedExam;
import Classes.Packet;
import Classes.Person;
import Classes.Question;
import Classes.QuestionInExam;
import Classes.Student;
import Classes.Subject;
import ocsf.server.ConnectionToClient;

public class ExamController {


	public static String addExamToRepository(Exam exam)
	{
		int[] indexArray= new int[100];
		int count=0, newIndexOfExam=0;
		String examID=exam.getID();
		ArrayList<QuestionInExam> questionsList = exam.getQuestions();
		Statement stmt;
		try {
			stmt = Server.conn.createStatement();
			ResultSet rs = stmt.executeQuery("SELECT ID FROM EXAMS WHERE ID LIKE '"+examID+"%';");
			PreparedStatement ps=Server.conn.prepareStatement("INSERT INTO EXAMS VALUES (?,?,?,?,?,?,?);");	
			while(rs.next()) { 			
				indexArray[Integer.parseInt(rs.getString(1))%100]=1;
				count++;
			}

			for(newIndexOfExam = 0 ; newIndexOfExam < count+1 ; newIndexOfExam++)
				if(indexArray[newIndexOfExam]==0)
					break;
			examID+=String.format("%02d", newIndexOfExam);
			ps.setString(1, examID);
			ps.setString(2, exam.getCourse().getID());
			ps.setString(3, exam.getSubject().getID());						
			ps.setString(4, exam.getAuthor().getID());			
			ps.setString(5, exam.getCreationDate());
			ps.setInt(6, exam.getExamTime());
			ps.setString(7, exam.getNote());
			ps.execute();
			rs.close();
			stmt = Server.conn.createStatement();

			for(QuestionInExam question : questionsList) {
				stmt.executeUpdate("INSERT INTO EXAMSQUESTIONS VALUES ('"+examID+"','"+question.getID()+"','"+question.getScore()+"','"+question.getNoteForStudent()+"','"+question.getNoteForTeacher()+"');");
			}



		} catch (SQLException e) {
			e.printStackTrace();
			return "Failure";
		}
		return "Success";	
	}

	public static ArrayList<Exam> getExamsList(){
		return getExamsListBySubject(null);
	}

	public static ArrayList<Exam> getExamsListBySubject(String subject)
	{
		Statement stmt,stmt1;
		ArrayList<Exam> examsList = new ArrayList<Exam>();
		Course examCourse;
		Subject examSubject;
		Person examAuthor;
		Exam exam;
		ArrayList<QuestionInExam> questionsList;	
		try {
			stmt = Server.conn.createStatement();	
			stmt1 = Server.conn.createStatement();
			ResultSet rs;
			if(subject!=null)
				rs = stmt.executeQuery("SELECT E.ID, C.ID, C.NAME, S.ID, S.NAME, T.ID, T.FIRSTNAME, T.LASTNAME, E.CREATIONDATE, E.EXAMTIME, E.NOTE FROM EXAMS E, COURSES C, SUBJECTS S, TEACHERS T WHERE E.SUBJECT = '"+subject+"' AND E.COURSE = C.ID AND E.SUBJECT = S.ID AND E.AUTHOR = T.ID ;");
			else
				rs = stmt.executeQuery("SELECT E.ID, C.ID, C.NAME, S.ID, S.NAME, T.ID, T.FIRSTNAME, T.LASTNAME, E.CREATIONDATE, E.EXAMTIME, E.NOTE FROM EXAMS E, COURSES C, SUBJECTS S, TEACHERS T WHERE E.COURSE = C.ID AND E.SUBJECT = S.ID AND E.AUTHOR = T.ID ;");
			ResultSet rs1;
			while(rs.next())
			{
				examCourse = new Course(rs.getString(2),rs.getString(3),rs.getString(4));
				examSubject = new Subject(rs.getString(4),rs.getString(5));
				examAuthor = new Person(rs.getString(6),rs.getString(7)+" "+rs.getString(8));
				questionsList = new ArrayList<QuestionInExam>();

				rs1 = stmt1.executeQuery("SELECT T.ID, T.FIRSTNAME, T.LASTNAME, Q.ID, Q.QUESTION, Q.ANSWER1, Q.ANSWER2, Q.ANSWER3, Q.ANSWER4, Q.CORRECTANSWER, EQ.SCORE, EQ.NOTEFORSTUDENT, EQ.NOTEFORTEACHER FROM TEACHERS T, QUESTIONS Q, EXAMSQUESTIONS EQ WHERE EQ.EXAM='"+rs.getString(1)+"' AND EQ.QUESTION = Q.ID AND T.ID = Q.AUTHOR ;");

				while (rs1.next())
				{
					Person author = new Person(rs1.getString(1),rs1.getString(2)+" "+rs1.getString(3));
					Question question = new Question(rs1.getString(4), author, rs1.getString(5), rs1.getString(6), rs1.getString(7), rs1.getString(8), rs1.getString(9), rs1.getInt(10));
					QuestionInExam questionInExam = new QuestionInExam(question,rs1.getInt(11));
					questionInExam.setNoteForStudent(rs1.getString(12));
					questionInExam.setNoteForTeacher(rs1.getString(13));
					questionsList.add(questionInExam);

				}
				exam = new Exam (rs.getString(1), examCourse, examSubject, examAuthor, rs.getString(9), questionsList, rs.getInt(10));

				exam.setNote(rs.getString(11));
				examsList.add(exam);						

			}
			return examsList;

		} catch (SQLException e) {			
			e.printStackTrace();
			return null;
		}
	}

	public static Exam getExamByID(String examID)
	{
		Statement stmt,stmt1;		
		Course examCourse;
		Subject examSubject;
		Person examAuthor;
		Exam exam;
		ArrayList<QuestionInExam> questionsList;	
		try {
			stmt = Server.conn.createStatement();	
			stmt1 = Server.conn.createStatement();
			ResultSet rs;		
			
				rs = stmt.executeQuery("SELECT E.ID, C.ID, C.NAME, S.ID, S.NAME, T.ID, T.FIRSTNAME, T.LASTNAME, E.CREATIONDATE, E.EXAMTIME, E.NOTE FROM EXAMS E, COURSES C, SUBJECTS S, TEACHERS T WHERE E.ID = '"+examID+"' AND E.COURSE = C.ID AND E.SUBJECT = S.ID AND E.AUTHOR = T.ID ;");
			ResultSet rs1;
			rs.next();			
				examCourse = new Course(rs.getString(2),rs.getString(3),rs.getString(4));
				examSubject = new Subject(rs.getString(4),rs.getString(5));
				examAuthor = new Person(rs.getString(6),rs.getString(7)+" "+rs.getString(8));
				questionsList = new ArrayList<QuestionInExam>();
				rs1 = stmt1.executeQuery("SELECT T.ID, T.FIRSTNAME, T.LASTNAME, Q.ID, Q.QUESTION, Q.ANSWER1, Q.ANSWER2, Q.ANSWER3, Q.ANSWER4, Q.CORRECTANSWER, EQ.SCORE, EQ.NOTEFORSTUDENT, EQ.NOTEFORTEACHER FROM TEACHERS T, QUESTIONS Q, EXAMSQUESTIONS EQ WHERE EQ.EXAM='"+rs.getString(1)+"' AND EQ.QUESTION = Q.ID AND T.ID = Q.AUTHOR ;");

				while (rs1.next())
				{
					Person author = new Person(rs1.getString(1),rs1.getString(2)+" "+rs1.getString(3));
					Question question = new Question(rs1.getString(4), author, rs1.getString(5), rs1.getString(6), rs1.getString(7), rs1.getString(8), rs1.getString(9), rs1.getInt(10));
					QuestionInExam questionInExam = new QuestionInExam(question,rs1.getInt(11));
					questionInExam.setNoteForStudent(rs1.getString(12));
					questionInExam.setNoteForTeacher(rs1.getString(13));
					questionsList.add(questionInExam);
				}
				exam = new Exam (rs.getString(1), examCourse, examSubject, examAuthor, rs.getString(9), questionsList, rs.getInt(10));
				exam.setNote(rs.getString(11));									

			
			return exam;

		} catch (SQLException e) {			
			e.printStackTrace();
			return null;
		}
	}

	public static String removeExamFromRepository(String ID)
	{
		Statement stmt;
		try {
			stmt = Server.conn.createStatement();
			stmt.executeUpdate("DELETE FROM EXAMS WHERE ID = '"+ID+"'");
			return "Success";
		} catch (SQLException e) {
			e.printStackTrace();
			return "Failure";
		}

	}


	public static boolean executeExam(String executionCode, String examID, String teacherID )
	{
		try {
			int executionID = getNumberOfExams();
			Statement stmt,stmt1, stmt2;
			stmt = Server.conn.createStatement();
			stmt1 = Server.conn.createStatement();		
			stmt2 = Server.conn.createStatement();
			Date date = new Date();  
			SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");  
			String strDate= formatter.format(date); 
			ResultSet rs = stmt.executeQuery("SELECT * FROM ACTIVEEXAMS WHERE CODE= '"+executionCode+"';");
			if(rs.next())		    
				return false;	
			
			stmt1.executeUpdate("INSERT INTO EXECUTEDEXAMS VALUES ('"+executionID+"', '"+executionCode+"','"+examID+"','"+strDate+"', '"+teacherID+"') ;");
			stmt2.executeUpdate("INSERT INTO ACTIVEEXAMS VALUES ('"+executionID+"', '"+executionCode+"','"+examID+"','"+strDate+"', '"+teacherID+"') ;");
			
			return true;
		}

		catch(Exception e)
		{
			e.printStackTrace();
			return false;
		}

	}

	public static String checkExamCode(String examCode, String studentID)
	{
		System.out.println(new Date());
		try
		{
			Statement stmt,stmt1;			
			stmt = Server.conn.createStatement();	
			stmt1 = Server.conn.createStatement();
			ResultSet rs = stmt.executeQuery("SELECT ID FROM ACTIVEEXAMS WHERE CODE= '"+examCode+"';");			
			ResultSet rs1;
			if(rs.next())	
			{			
				rs1 = stmt1.executeQuery("SELECT * FROM FINISHEDEXAMS FE WHERE FE.ID = '"+rs.getString(1)+"' AND FE.EXAMINEE = '"+studentID+"';");
			if(rs1.next())	
				return "TookExamAlready";
			
			return "Success";
			}
			
			return "ExamCodeDoesntExist";
		}
		catch(Exception e)
		{
			e.printStackTrace();
			return "Exception";
		}
	}

	
	public static void removeActiveExam(String examExecutionCode)
	{
		try
		{
			Statement stmt;		
			stmt = Server.conn.createStatement();				
			stmt.executeUpdate("DELETE FROM ACTIVEEXAMS WHERE CODE = '"+examExecutionCode+"';");
		}	
			
		catch(Exception e)
		{
			e.printStackTrace();
		
		}
		
	
	}
	
	public static Exam takeExam(String examCode)
	{
		Statement stmt,stmt1;	
		Exam exam = null;
		Course examCourse;
		Subject examSubject;
		Person examAuthor;			
		ArrayList<QuestionInExam> questionsList;	
		try {
			stmt = Server.conn.createStatement();	
			stmt1 = Server.conn.createStatement();
			ResultSet rs;
			ResultSet rs1;			
			
			rs = stmt.executeQuery("SELECT E.ID, C.ID, C.NAME, S.ID, S.NAME, T.ID, T.FIRSTNAME, T.LASTNAME, E.CREATIONDATE, E.EXAMTIME, E.NOTE FROM ACTIVEEXAMS AE, EXAMS E, COURSES C, SUBJECTS S, TEACHERS T WHERE AE.CODE ='"+examCode+"' AND AE.EXAM = E.ID AND E.COURSE = C.ID AND E.SUBJECT = S.ID AND E.AUTHOR = T.ID ;");
			if(rs.next())
			{			
			examCourse = new Course(rs.getString(2),rs.getString(3),rs.getString(4));
			examSubject = new Subject(rs.getString(4),rs.getString(5));
			examAuthor = new Person(rs.getString(6),rs.getString(7)+" "+rs.getString(8));
			questionsList = new ArrayList<QuestionInExam>();			

			rs1 = stmt1.executeQuery("SELECT T.ID, T.FIRSTNAME, T.LASTNAME, Q.ID, Q.QUESTION, Q.ANSWER1, Q.ANSWER2, Q.ANSWER3, Q.ANSWER4, Q.CORRECTANSWER, EQ.SCORE, EQ.NOTEFORSTUDENT FROM TEACHERS T, QUESTIONS Q, EXAMSQUESTIONS EQ WHERE EQ.EXAM='"+rs.getString(1)+"' AND EQ.QUESTION = Q.ID AND T.ID = Q.AUTHOR ;");

			while (rs1.next())
			{
				Person author = new Person(rs1.getString(1),rs1.getString(2)+" "+rs1.getString(3));
				Question question = new Question(rs1.getString(4), author, rs1.getString(5), rs1.getString(6), rs1.getString(7), rs1.getString(8), rs1.getString(9), rs1.getInt(10));
				QuestionInExam questionInExam = new QuestionInExam(question,rs1.getInt(11));
				questionInExam.setNoteForStudent(rs1.getString(12));						
				questionsList.add(questionInExam);

			}
			exam = new Exam (rs.getString(1), examCourse, examSubject, examAuthor, rs.getString(9), questionsList, rs.getInt(10));					
			exam.setNote(rs.getString(11));										
			}
			
			
			return exam;
			
		} catch (SQLException e) {			
			e.printStackTrace();
			return null;
		}
	}

	

	public static ArrayList<Object> startExam(ConnectionToClient client, Student student, Exam exam, String examExecutionCode)
	{
		
		return ServerWatch.addExaminee(client, student, exam, examExecutionCode);			
	}


	public static void endExam(ConnectionToClient client, String reason) {
		try {
			Packet packet = new Packet(reason,null);
			packet.setID(-1);
			if(client != null)	
				client.sendToClient(packet);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public static int getNumberOfExams() {		
		Statement stmt;
		ResultSet rs;
		try {
			
			stmt = Server.conn.createStatement();	
			rs = stmt.executeQuery("SELECT COUNT(*) AS NUMBEROFEXAMS FROM EXECUTEDEXAMS;");
			rs.next();
			return rs.getInt(1);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return 0;
	}
	
	
	public static HashMap<Exam,String> getActiveExams(String executorID)
	{
		HashMap<Exam,String> activeExams = new HashMap<Exam,String>();
		Statement stmt;
		ResultSet rs;	
		try {	
			stmt = Server.conn.createStatement();	
			if(executorID == null)
				rs = stmt.executeQuery("SELECT CODE, EXAM FROM ACTIVEEXAMS;");
			else
				rs = stmt.executeQuery("SELECT CODE, EXAM FROM ACTIVEEXAMS WHERE TEACHER = '"+executorID+"';");
			while(rs.next()){		
				activeExams.put(getExamByID(rs.getString(2)),rs.getString(1));
			}
			
			return activeExams;
		} catch (SQLException e) {			
			e.printStackTrace();
			return null;
		}
		
	}
	
	public static void submitExam(FinishedExam exam, Examinee examinee, String reason) {
		Statement stmt1,stmt2;
		ResultSet rs1;
		int grade=-1;
		exam.finish();

		try {
			stmt1 = Server.conn.createStatement();
			stmt2 = Server.conn.createStatement();
			rs1 = stmt1.executeQuery("SELECT ID FROM ACTIVEEXAMS WHERE CODE='"+examinee.getExamExecutionCode()+"';");
			rs1.next();
			int id = rs1.getInt(1);
			grade=exam.getGrade();	
			stmt2.executeUpdate("INSERT INTO FINISHEDEXAMS VALUES ('"+id+"','"+exam.getID()+"','"+examinee.getID()+"','"+exam.getStartTime().toString()+"','"+exam.getFinishTime().toString()+"','"+reason+"','"+grade+"','"+"-1');");
			addAnswers(id, exam, examinee.getID());
			ServerWatch.removeExaminee(examinee);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	private static void addAnswers(int id, FinishedExam exam, String studentID) {
		Statement stmt1;
		HashMap<String,Integer> answers = exam.getAnswers();
		int answer;
		try {
			stmt1 = Server.conn.createStatement();
			for(QuestionInExam question : exam.getQuestions())
			{
				answer = answers.get(question.getID());
				stmt1.executeUpdate("INSERT INTO STUDENTSANSWERS VALUES('"+id+"','"+studentID+"','"+question.getID()+"','"+answer+"');");
			}
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}

	public static void lockExam(String examExecutionCode)
	{
		ServerWatch.lockExam(examExecutionCode);
	}

}



