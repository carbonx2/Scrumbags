package Server;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;

import java.util.SortedSet;import java.util.TreeSet;
import java.util.concurrent.locks.ReentrantLock;

import Classes.Exam;
import Classes.Examinee;
import Classes.Student;
import ocsf.server.ConnectionToClient;

public class ServerWatch {

	public static HashMap<String,TreeSet<Examinee>> activeExaminees = null;
	public static HashMap<String,ConnectionToClient> connectionsExaminees;
	public  static ReentrantLock lock = new ReentrantLock();
	public static ArrayList<Examinee> examineesToRemove= new ArrayList<Examinee>();
	
	
	public static ArrayList<Object> addExaminee(ConnectionToClient client, Student student, Exam exam, String examExecutionCode)
	{
		
		if(activeExaminees == null)
		{	
			activeExaminees = new HashMap<String,TreeSet<Examinee>>();
			connectionsExaminees = new HashMap<String, ConnectionToClient>();
			startWatch();
		}
		Calendar cal = Calendar.getInstance();
		Date startTime =  cal.getTime();
		cal.add(Calendar.MINUTE, exam.getExamTime());	
		Date finishTime = cal.getTime();
		lock.lock();	
		if(ExamController.checkExamCode(examExecutionCode, student.getID()).equals("ExamCodeDoesntExist"))
			return null;
		ArrayList<Object> examineeS = new ArrayList<Object>();
		String examineeStatus = "Old";
		
		Examinee examinee = getExaminee(student.getID(),examExecutionCode);	
		if(examinee == null)		
		{
			examineeStatus = "New";
			examinee = new Examinee(student,exam,examExecutionCode, startTime, finishTime);
			TreeSet<Examinee> tempSet = activeExaminees.get(examExecutionCode);			
			if(tempSet==null) {
				tempSet=new TreeSet<Examinee>();
				activeExaminees.put(examExecutionCode,tempSet);
			}			
			tempSet.add(examinee);
			
		}
		examineeS.add(examineeStatus);
		examineeS.add(examinee);
		connectionsExaminees.put(student.getID(),client);
		lock.unlock();
			
			
		return examineeS;
		
	}

	
	private static void startWatch()
	{
		
		new Thread(new Runnable() {
			@Override
			public void run() {
				while(true)
				{		
					
					try {
						Thread.sleep(1000);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
					Date currentTime = new Date();					
					lock.lock();
					for(TreeSet<Examinee> examinees : activeExaminees.values())		
					{
						for(Examinee examinee:examinees) {
							if(examinee.getFinishTime().compareTo(currentTime)==1)
								break;
							
							else
								if(connectionsExaminees.get(examinee.getID())!=null)								
									ExamController.endExam(connectionsExaminees.remove(examinee.getID()),"Timeout");									
								
							
						}
					}
					if(!examineesToRemove.isEmpty()) {
						for(Examinee examinee:examineesToRemove) {
							activeExaminees.get(examinee.getExamExecutionCode()).remove(examinee);	
							if(activeExaminees.get(examinee.getExamExecutionCode()).isEmpty()) 
								ExamController.removeActiveExam(examinee.getExamExecutionCode());
							
						}
						examineesToRemove.clear();
					}
					lock.unlock();
				}
			}
		}).start();
	}
	
	

	public static void lockExam(String examExecutionCode)
	{		
		System.out.println("Execution code  "+examExecutionCode);
		lock.lock();
		for(TreeSet<Examinee> examinees : activeExaminees.values()) {
			for(Examinee examinee : examinees)	
			{System.out.println("Examinee code  "+examinee.getExamExecutionCode());
				if(examinee.getExamExecutionCode().equals(examExecutionCode))
				{	
					examineesToRemove.add(examinee);
					ExamController.endExam(connectionsExaminees.remove(examinee.getID()),"LockExam");
				}
			}
		}
		ExamController.removeActiveExam(examExecutionCode);
		lock.unlock();
	}
	
	public static void removeExaminee(Examinee examinee) {
		lock.lock();
		examineesToRemove.add(getExaminee(examinee.getID(),examinee.getExamExecutionCode()));
		lock.unlock();
	}
	
	
	public static Examinee getExaminee(String examineeID, String examExecutionCode)
	{

		if(activeExaminees.get(examExecutionCode)!=null)
			for(Examinee examinee : activeExaminees.get(examExecutionCode))		
				if(examinee.getID().equals(examineeID))
					return examinee;
		return null;
	}
}
