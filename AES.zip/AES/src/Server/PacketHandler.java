package Server;

import java.util.ArrayList;


import Classes.Exam;
import Classes.Examinee;
import Classes.FinishedExam;
import Classes.Packet;
import Classes.Permission;
import Classes.Question;
import Classes.Student;
import Classes.User;
import ocsf.server.ConnectionToClient;

public class PacketHandler {

	public static void handlePacket(Packet packet, ConnectionToClient client) throws Exception {
		Packet userPacket;
		Object data = null;
		String answer = "Success";
		
		switch (packet.getOperation()) {
		case "AddQuestion":
			answer = QuestionController.addQuestionToRepository((Question) packet.getData());
			break;
		case "GetQuestionsList":
			data = QuestionController.getQuestionsList();
			if (data == null)
				answer = "Failure";
			break;
		case "RemoveQuestion":
			answer = QuestionController.removeQuestion((String) packet.getData());
			break;
		case "UpdateAnswer":
			answer = QuestionController.updateCorrectAnswer((String) ((ArrayList) packet.getData()).get(0),
					(int) ((ArrayList) packet.getData()).get(1));
			break;
		case "GetQuestionListBySubject":
			data = QuestionController.getQuestionsOfSubject((String) packet.getData());
			if (data == null)
				answer = "Failure";
			break;
		case "AddExam":
			answer = ExamController.addExamToRepository((Exam) packet.getData());
			break;
		case "GetExamsList":
			data = ExamController.getExamsList();
			if (data == null)
				answer = "Failure";
			break;
		case "GetExamsListBySubject":
			data = ExamController.getExamsListBySubject((String) packet.getData());
			if (data == null)
				answer = "Failure";
			break;
		case "RemoveExam":
			answer = ExamController.removeExamFromRepository((String) packet.getData());
			break;
			
		case "ExecuteExam": 
			ArrayList<String> data1 = (ArrayList<String>) packet.getData();
			String executionCode = data1.get(0);
			String examID = data1.get(1);
			String teacherID = data1.get(2);		
			boolean answer1 = ExamController.executeExam(executionCode, examID, teacherID);			
			if (!answer1)
				answer="Failure";
			break;			
			
		case "CheckExamCode":
			ArrayList<String> arrayList = (ArrayList<String>) packet.getData();			
			answer=ExamController.checkExamCode(arrayList.get(0),arrayList.get(1));
			break;
			
		case "TakeExam":
			data = ExamController.takeExam((String)packet.getData());
			break;
			
		case "StartExam":
			ArrayList data2 = ((ArrayList)packet.getData());
			Student student = (Student) data2.get(0);
			Exam exam = (Exam) data2.get(1);
			String examExecutionCode = (String) data2.get(2);
			data2 = ExamController.startExam(client, student, exam, examExecutionCode);
			answer = "ExamIsNotActive";
			data = null;
			if (data2!=null)
			{	
			answer = (String) data2.get(0);
			data = data2.get(1);			
			}
						
			break;
			
		case "SubmitExam":
			ArrayList data3 = ((ArrayList)packet.getData());
			ExamController.submitExam((FinishedExam)data3.get(0), (Examinee)data3.get(1), (String)data3.get(2));
			break;
			
		case "GetActiveExams":
			data = ExamController.getActiveExams((String) packet.getData());
			break;
			
		case "LockExam":
			ExamController.lockExam((String) packet.getData());
			break;
			
		case "LogIn":
			Packet userPacket1;			
			ArrayList<Object> arrayList1;
			String id = (String) ((ArrayList) packet.getData()).get(0);
			String password = (String) ((ArrayList) packet.getData()).get(1);			
			arrayList1 = UserController.logIn(id, password, client);
			
			if (arrayList1 != null) {
				answer = (String) arrayList1.get(0);
				data = arrayList1.get(1);
			}
			break;
				
		case "LogOut":
			UserController.logOut((String) packet.getData());
			break;

		}
		
		userPacket = new Packet(answer, data);
		userPacket.setID(packet.getID());
		client.sendToClient(userPacket);

	}
}
