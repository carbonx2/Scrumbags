package ClientGui;

import java.net.URL;
import java.util.ResourceBundle;

import Classes.QuestionInExam;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ToggleGroup;

public class ExamQuestionPaneController implements Initializable {

	
	@FXML
	private Label NoteForStudentLabel;	
    @FXML
    private Label QuestionLabel;

    @FXML
    private RadioButton AnswerRadioButton1;

    @FXML
    private RadioButton AnswerRadioButton2;

    @FXML
    private RadioButton AnswerRadioButton3;

    @FXML
    private RadioButton AnswerRadioButton4;

    private ToggleGroup group ;

    private QuestionInExam question;
    
    
    
    
    
    public void setQuestion(QuestionInExam question, int questionNumber) {	
    	this.question = question;
		StringBuilder questionStr = new StringBuilder("Question "+questionNumber+"("+question.getScore()+" points):\n"+question.getQuestion());
		if(question.getNoteForStudent()!=null&&!question.getNoteForStudent().equals("null")) 
			questionStr.append("   ("+question.getNoteForStudent()+")");		
		QuestionLabel.setText(questionStr.toString());

		AnswerRadioButton1.setText("a. " + question.getAnswer(1));
		AnswerRadioButton2.setText("b. " + question.getAnswer(2));
		AnswerRadioButton3.setText("c. " + question.getAnswer(3));
		AnswerRadioButton4.setText("d. " + question.getAnswer(4));			
	}

    public QuestionInExam getQuestion()
    {
    	return question;
    }
    
    public int getSelectedAnswer()
    {
    	if(group.getSelectedToggle()== null)    
    		return 0;
    	return Integer.parseInt((String) group.getSelectedToggle().getUserData());
    	
    }
    
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		group = new ToggleGroup();	
		
		AnswerRadioButton1.setToggleGroup(group);
		AnswerRadioButton1.setUserData("1");
		AnswerRadioButton2.setToggleGroup(group);
		AnswerRadioButton2.setUserData("2");
		AnswerRadioButton3.setToggleGroup(group);
		AnswerRadioButton3.setUserData("3");
		AnswerRadioButton4.setToggleGroup(group);
		AnswerRadioButton4.setUserData("4");
		
	}
    
}
