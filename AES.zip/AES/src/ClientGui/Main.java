package ClientGui;

import java.io.IOException;
import java.util.Optional;

import Classes.Permission;
import Client.Client;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TextInputDialog;
import javafx.stage.Stage;

public class Main extends Application {
	public static Client client;
	final static int DEFAULT_PORT = 5555;

	@Override
	public void start(Stage primaryStage) {
		try {
			client = new Client("localhost", DEFAULT_PORT);

			Parent root;
			primaryStage.setOnCloseRequest(e -> {
				e.consume();
				Alert alert = new Alert(AlertType.CONFIRMATION);
				alert.setContentText("Are you sure you want to exit?");
				alert.setHeaderText(null);
				alert.setGraphic(null);
				Optional<ButtonType> result = alert.showAndWait();
				
				if (result.get() == ButtonType.OK){
					Platform.exit();
					System.exit(1);
				} else {
				   alert.hide();
				}		
			});

			try {
				FXMLLoader loader =new FXMLLoader();
				if(Main.client.user.getPermission()==Permission.TEACHER.ordinal()) {
					root = loader.load(getClass().getResource("/ClientGui/ManageExamsScene.fxml").openStream());	
					Scene scene = new Scene(root);
					primaryStage.setScene(scene);
					primaryStage.show();
					primaryStage.setUserData(loader.getController());
				}
				else {
					
					root = loader.load(getClass().getResource("/ClientGui/TakeExamMainPage.fxml").openStream());	
					TakeExamMainPageController controller = loader.getController();
					Scene scene = new Scene(root);
					primaryStage.setScene(scene);
					primaryStage.show();
				}
				
				
			} catch (IOException e) {

				e.printStackTrace();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}
	
	

	public static void main(String[] args) {
		launch(args);

	}
}
