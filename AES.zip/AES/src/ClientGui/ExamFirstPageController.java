package ClientGui;

import java.net.URL;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Observable;
import java.util.ResourceBundle;
import java.util.Timer;
import java.util.TimerTask;

import javax.sound.midi.Sequence;

import Classes.Exam;
import Classes.Examinee;
import Classes.Student;
import Client.ExamController;
import javafx.animation.Animation;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.beans.InvalidationListener;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableIntegerValue;
import javafx.beans.value.ObservableValue;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextField;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import javafx.util.Duration;

public class ExamFirstPageController implements Initializable {

	@FXML
	private Label CourseNameLabel;

	@FXML
	private Label AuthorLabel;

	@FXML
	private Label DateLabel;

	@FXML
	private Label ExamTimeLabel;

	@FXML
	private ScrollPane NoteScrollPane;

	@FXML
	private Label ExamNotesLabel;

	@FXML
	private Label IDLabel;

	@FXML
	private TextField IDTextField;

	ExamWindowController controller;

	Long remainingTime;

	ObservableIntegerValue RT;

	Exam exam;

	Date startTime;



	String examCode;
	public static int timeExtension;
	public Examinee examinee;
	public void idListener()
	{		
		if(IDTextField.getText().trim().equals(Client.Client.user.getID()))
		{
			controller.enableSubmitButton();
			disableEffect();
			IDLabel.setVisible(false);
			IDTextField.setVisible(false);
			controller.setPageCount();
			ArrayList answer = ExamController.startExam((Student)Client.Client.user, exam, examCode);
			if (answer.get(0).equals("ExamIsNotActive"))
			{
				controller.closeWindow("Error","The exam is not active anymore");				
				return;
			}				
			
			examinee = (Examinee) answer.get(1);
			System.out.println(examinee);
			controller.setExaminee(examinee);			
			remainingTime = examinee.getFinishTime().getTime()-(new Date().getTime());
			Calendar calendar = Calendar.getInstance();
			calendar.add(calendar.MILLISECOND, remainingTime.intValue());
			Date finishTime = calendar.getTime();
			controller.setExamFinishTime(finishTime);
			setRemainingTime();

			new Thread(new Runnable() {

				@Override
				public void run() {

					while(true)
					{
						ArrayList<String> answer = 	ExamController.waitForCommand();			
						switch(answer.get(0))
						{
						case "LockExam":		
							controller.submitExam(answer.get(0),answer.get(0));						
							return;
						case "TimeExtension":
							timeExtension += Integer.parseInt(answer.get(1));
							break;
						case "Timeout":
							controller.submitExam(answer.get(0),answer.get(0));
							return;
						}
					}
				}
			}).start();
		}
	}


	public void setRemainingTime()
	{
		new Thread(new Runnable() {

			public void run()
			{
				while(remainingTime>0)
				{						
					synchronized(remainingTime)
					{
						remainingTime-=1000;
						controller.setRemainingTime(remainingTime/60000+1);
					}

					try {
						Thread.sleep(1000);
					} catch (InterruptedException e) {						
						e.printStackTrace();
					}
				}
			}
		}).start();;
	}

	public void setExamWindowController(ExamWindowController controller)
	{
		this.controller = controller;
	}

	public void setExamFirstPage(Exam exam) {		
		DateLabel.setText(exam.getCreationDate());
		CourseNameLabel.setText(exam.getCourse().getName());
		AuthorLabel.setText(exam.getAuthor().getName());
		ExamNotesLabel.setText(exam.getNote());
		ExamTimeLabel.setText(ExamTimeLabel.getText()+" "+exam.getExamTime());	
		this.exam = exam;
	}

	public void setExamCode(String examCode)
	{
		this.examCode = examCode;
	}

	public void disableEffect()
	{
		CourseNameLabel.setEffect(null);
		AuthorLabel.setEffect(null);
		DateLabel.setEffect(null);
		ExamTimeLabel.setEffect(null);
		NoteScrollPane.setEffect(null);
		ExamNotesLabel.setEffect(null);
	}

	
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {		
		startTime = new Date();
		timeExtension = 0;	


	}
}
