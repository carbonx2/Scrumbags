package ClientGui;

import java.net.URL;
import java.util.ResourceBundle;

import Classes.QuestionInExam;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;

public class ViewExamQuestionPaneController {

	
	@FXML
	private Label NoteForStudentLabel;
	@FXML
	private Label NoteForTeacherLabel;
	@FXML
    private Label ScoreLabel;
	@FXML
	private Label QuestionLabel;

	@FXML
	private Label Answer1Label;

	@FXML
	private Label Answer2Label;

	@FXML
	private Label Answer3Label;

	@FXML
	private Label Answer4Label;


	
	public void setQuestion(QuestionInExam question, int questionNumber) {		
		StringBuilder questionStr = new StringBuilder("Question "+questionNumber+"("+question.getScore()+" points):\n"+question.getQuestion());
		if(question.getNoteForStudent()!=null&&!question.getNoteForStudent().equals("null")) 
			questionStr.append("   (Student: "+question.getNoteForStudent()+")");
		if(question.getNoteForTeacher()!=null&&!question.getNoteForStudent().equals("null"))
			questionStr.append("   (Teacher: "+question.getNoteForTeacher()+")");
		QuestionLabel.setText(questionStr.toString());

		Answer1Label.setText("a. " + question.getAnswer(1));
		Answer2Label.setText("b. " + question.getAnswer(2));
		Answer3Label.setText("c. " + question.getAnswer(3));
		Answer4Label.setText("d. " + question.getAnswer(4));			
	}

	

}

	
	

