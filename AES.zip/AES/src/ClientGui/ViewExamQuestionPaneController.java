package ClientGui;

import java.net.URL;
import java.util.ResourceBundle;

import Classes.QuestionInExam;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;

public class ViewExamQuestionPaneController {

	
	
	@FXML
    private Label ScoreLabel;
	@FXML
	private Label QuestionLabel;

	@FXML
	private Label Answer1Label;

	@FXML
	private Label Answer2Label;

	@FXML
	private Label Answer3Label;

	@FXML
	private Label Answer4Label;

	private QuestionInExam question;

	

	public void setQuestion(QuestionInExam question, int questionNumber) {
		
		
		QuestionLabel.setText(questionNumber + ". " + question.getQuestion());
		ScoreLabel.setText(ScoreLabel.getText()+" "+question.getScore());
		Answer1Label.setText("a. " + fixString(question.getAnswer(1)));
		Answer2Label.setText("b. " + fixString(question.getAnswer(2)));
		Answer3Label.setText("c. " + fixString(question.getAnswer(3)));
		Answer4Label.setText("d. " + fixString(question.getAnswer(4)));			
		this.question = question;
	}

	

	public String fixString(String str) {
		if (str.length() <= 70)
			return str;
		if (str.length() <= 140)
			return str.substring(0, 70) + "\n       " + str.substring(70, str.length());
		else
			return str.substring(0, str.length() / 2) + "\n       " + str.substring(str.length() / 2, str.length());
	}

	


}

	
	

