package ClientGui;

import java.net.URL;
import java.util.ResourceBundle;

import Classes.Exam;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;

public class ViewExamPreviewPageController implements Initializable {

	
	
    @FXML
    private Label CourseNameLabel;

    @FXML
    private Label AuthorLabel;

    @FXML
    private Label DateLabel;

    @FXML
    private Label ExamTimeLabel;

    @FXML
    private Label ExamNotesLabel;
    
    
    
    
    
    
    public void setExamPreview(Exam exam) {		
		DateLabel.setText(exam.getCreationDate());
		CourseNameLabel.setText(exam.getCourse().getName());
		AuthorLabel.setText(exam.getAuthor().getName());
		ExamNotesLabel.setText(exam.getNote());
		ExamTimeLabel.setText(ExamTimeLabel.getText()+" "+exam.getExamTime());		
	}



    public String fixString(String oldString)
    {
    	int i=0;
    	StringBuilder newString = new StringBuilder();
    	for(i=50; i< oldString.length() ; i+=50)
    	{
    		newString.append(oldString.substring(i-50, i)+"\n");
    	}
    	newString.append(oldString.substring( oldString.length()-50, oldString.length()));
    	return newString.toString();
	
    }


	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		// TODO Auto-generated method stub
		
	}

}
