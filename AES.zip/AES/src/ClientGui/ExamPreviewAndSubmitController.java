package ClientGui;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Optional;
import java.util.ResourceBundle;

import Classes.Exam;
import Classes.QuestionInExam;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Pagination;
import javafx.scene.control.ScrollPane;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;

public class ExamPreviewAndSubmitController implements Initializable {
	public static final int itemsPerPage = 4;
	public ObservableList<QuestionInExam> questionsInExamList;
	private ArrayList<ExamFormPageController> pagesList;
	private ArrayList<Node> layoutList;
	@FXML
    private AnchorPane OurAnchorPane;
	@FXML
	public Pagination pagination;

	@FXML
	public Button CancelButton;
	@FXML
	public Button SubmitButton;
	private ExamPreviewPageController firstPageController;
	private Node firstPageLayout;
	private Exam exam;
	

	public void setQuestionsInExam(ObservableList<QuestionInExam> questionsInExamList) {
		this.questionsInExamList = questionsInExamList;
		setPageCount();

	}

	public void cancelButtonListener(ActionEvent event) {
		Alert alert = new Alert(AlertType.CONFIRMATION);
		alert.setContentText("All information will be lost.\nAre you sure?");
		alert.setHeaderText(null);
		alert.setGraphic(null);
		Optional<ButtonType> result = alert.showAndWait();
		
		if (result.get() == ButtonType.OK){
			CancelButton.getScene().getWindow().hide();
		} else {
		   alert.hide();
		}		
	
	}

	public ScrollPane createPage(int pageIndex) {

		try {
			ScrollPane scrollPane = new ScrollPane();
			scrollPane.getStylesheets().add("FixScrollbar.css");
			if (pageIndex == 0) {
				Node layout;
				if (firstPageController == null) {
					FXMLLoader loader = new FXMLLoader();
					layout = loader.load(getClass().getResource("/ClientGui/ExamPreviewPage.fxml").openStream());
					ExamPreviewPageController controller = loader.getController();
					controller.setExam(exam);
					firstPageController = controller;
					firstPageLayout = layout;
				}
				layout = firstPageLayout;
				scrollPane.setContent(layout);
				return scrollPane;
			}
			int page = (pageIndex - 1) * itemsPerPage;
			Node layout;
			ExamFormPageController controller;
			if (pagesList.size() < pageIndex) {
				FXMLLoader loader = new FXMLLoader();
				layout = loader.load(getClass().getResource("/ClientGui/ExamFormPage.fxml").openStream());
				controller = loader.getController();
				pagesList.add(controller);
				layoutList.add(layout);
				for (int i = page; i < page + itemsPerPage && i < questionsInExamList.size(); i++)
					controller.addQuestion(questionsInExamList.get(i), (pagesList.size()-1)*4+(i-page));
			}
			controller = pagesList.get(pageIndex - 1);
			layout = layoutList.get(pageIndex - 1);
			scrollPane.setContent(layout);			
			return scrollPane;
		} catch (Exception e) {
			return null;
		}
	}

	public void setPageCount() {
		if (questionsInExamList.size() % itemsPerPage == 0)
			pagination.setPageCount(questionsInExamList.size() / itemsPerPage + 1);

		else
			pagination.setPageCount(questionsInExamList.size() / itemsPerPage + 2);

	}

	public void setExam(Exam exam) {
		this.exam = exam;
	}

	public void submitExam() {
		int score = 0;
		for (ExamFormPageController controller : pagesList)
			score += controller.getScores();
		if (score != 100) {
			Alert alert = new Alert(AlertType.INFORMATION);
			alert.setTitle("Invalid scores inserted");
			alert.setHeaderText(null);
			alert.setContentText("The question scores doesn't meet the sum of 100");

			alert.showAndWait();
			return;
		}
		for (ExamFormPageController controller : pagesList) {
			controller.setNotes();
			controller.setScores();
		}
		firstPageController.setNoteAndTime();
		exam.setQuestions(questionsInExamList);
		System.out.println(exam);

	}
	
	public void onCloseOperation(WindowEvent event)
	{
		event.consume();
		cancelButtonListener(null);
	}

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		pagination.setPageFactory((Integer pageIndex) -> createPage(pageIndex));
		firstPageController = null;
		firstPageLayout = null;
		pagesList = new ArrayList<ExamFormPageController>();
		layoutList = new ArrayList<Node>();	
	}



}
