package ClientGui;

import java.net.URL;
import java.util.Calendar;
import java.util.ResourceBundle;

import Classes.Exam;
import Classes.Teacher;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;

public class ExamPreviewPageController implements Initializable {

	@FXML
	private TextField TimeTextField;
	@FXML
	private Label CourseNameLabel;

	@FXML
	private Label DateLabel;
	@FXML
	private Label AuthorLabel;
	@FXML
    private TextArea ExamNoteTextArea;
	private Exam exam;
	
	public void examTimeTextListener() {		
		
		if(TimeTextField.getText().trim().length()>0) {
			
			if(TimeTextField.getText().charAt(0)=='0') 
    			TimeTextField.setText(TimeTextField.getText().substring(1));
    		if (!TimeTextField.getText().matches("\\d*"))
    			TimeTextField.setText(TimeTextField.getText().replaceAll("[^\\d]", ""));	    		
    		
    	}
	}

	public String getExamTime() {
		return TimeTextField.getText();
	}

	public String getExamNote() {
		return ExamNoteTextArea.getText();
	}

	public void setExam(Exam exam) {
		this.exam=exam;
		DateLabel.setText(exam.getCreationDate());
		CourseNameLabel.setText(exam.getCourse().getName());
	}
	
	public void setNoteAndTime() {	
		exam.setNote(ExamNoteTextArea.getText());        
		exam.setExamTime(Integer.parseInt(TimeTextField.getText()));
	}
	
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		Teacher teacher = (Teacher) Client.Client.user;
		AuthorLabel.setText(teacher.getName());		
		TimeTextField.setText("0");
	}

}
