package Classes;

public enum Permission {
	NONE, STUDENT, TEACHER, MANAGER, ADMIN
};
