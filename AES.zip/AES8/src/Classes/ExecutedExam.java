package Classes;

import java.io.Serializable;
import java.util.Date;
import java.util.concurrent.Callable;

public class ExecutedExam extends Exam implements Serializable, Comparable {
	Date executionDate;
	int id;
	String code;
	
	public ExecutedExam(Exam exam, int id, Date date, String code) {
		super(exam);
		this.executionDate=date;
		this.id=id;
		this.code=code;
	}

	public Date getExecutionDate() {
		return executionDate;
	}

	public void setExecutionDate(Date executionDate) {
		this.executionDate = executionDate;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	@Override
	public int compareTo(Object o) {
		if(this.id>((ExecutedExam)o).getId())
			return 1;
		if(this.id==((ExecutedExam)o).getId())
			return -1;
		return 0;
	}
	
	

}
