package Classes;

import java.io.Serializable;
import java.net.URL;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.ResourceBundle;



import javafx.fxml.Initializable;

public class FinishedExam extends Exam implements Serializable, Comparable  {
	
	private Date startTime;
	private Date finishTime;
	private HashMap<String, Integer> answers;
	private String type;
	private int grade;
	private String submissionType;
	private int completionTime;
	private int finalGrade;
	private Person examinee;  
	private int cheatingGroupNumber;
	private String gradeNote;
	private int examExecutionID;
	private HashMap<String,String> checkedQuestionsNote;


	public FinishedExam(Exam exam, String type) {
		super(exam);
		answers = new HashMap<String, Integer>();
		startTime = new Date();
		this.type=type;		
		cheatingGroupNumber = -1;
		
		
	}
	
	public int getCheatingGroupNumber() {
		return cheatingGroupNumber;
	}


	public void setCheatingGroupNumber(int cheatingGroupNumber) {
		this.cheatingGroupNumber = cheatingGroupNumber;
	}
	
	public String getSubmissionType() {
		return submissionType;
	}

	public void setSubmissionType(String submissionType) {
		this.submissionType = submissionType;
	}

	public int getCompletionTime() {
		return completionTime;
	}

	public void setCompletionTime(int completionTime) {
		this.completionTime = completionTime;
	}

	public int getFinalGrade() {
		return finalGrade;
	}

	public void setFinalGrade(int finalGrade) {
		this.finalGrade = finalGrade;
	}

	public Person getExaminee() {
		return examinee;
	}

	public void setExaminee(Person examinee) {
		this.examinee = examinee;
	}

	public void setFinishTime(Date finishTime) {
		this.finishTime = finishTime;
	}

	
	
	public void finish() {
		finishTime = new Date();
		if(type.equals("Online"))
			calculateGrade();

	}

	public HashMap<String, Integer> getAnswers() {
		return answers;
	}

	public void setAnswers(HashMap<String, Integer> answers) {
		this.answers = answers;
	}

	public Date getFinishTime() {
		return finishTime;

	}


	public Date getStartTime() {
		return startTime;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public int getGrade() {
		return grade;
	}

	public void setGrade(int grade) {
		this.grade = grade;
	}
	
	public void calculateGrade() {
		ArrayList<QuestionInExam> questions = this.getQuestions();		
		int score=0;
		for(QuestionInExam question:questions) {
			score+= answers.get(question.getID())==question.getCorrectAnswerIndex() ? question.getScore():0;
		}
		
		this.grade=score;
	}

	public void setStartTime(Date startTime) {
		this.startTime=startTime;
		
	}


	@Override
	public String toString() {
		return "FinishedExam [startTime=" + startTime + ", finishTime=" + finishTime + ", answers=" + answers
				+ ", type=" + type + ", grade=" + grade + ", submissionType=" + submissionType + ", completionTime="
				+ completionTime + ", finalGrade=" + finalGrade + ", examinee=" + examinee + "]";
	}

	public void setGradeNote(String text) {
		this.gradeNote=text;
		
	}
	public String getGradeNote()
	{
		return gradeNote;
	}

	public int getExamExecutionID() {
		return examExecutionID;
	}

	public void setExamExecutionID(int examExecutionID) {
		this.examExecutionID = examExecutionID;
	}

	public HashMap<String,String> getCheckedQuestionsNote() {
		return checkedQuestionsNote;
	}

	public void setCheckedQuestionsNote(HashMap<String,String> checkedQuestionsNote) {
		this.checkedQuestionsNote = checkedQuestionsNote;
	}

	@Override
	public int compareTo(Object arg0) {
		FinishedExam finishedExam = (FinishedExam)arg0;
		if(this.getFinalGrade()==-1)
		{
			if(finishedExam.getFinalGrade()==-1)
				return this.getStartTime().compareTo(finishedExam.getStartTime());	
			return 1;
		}
		if(finishedExam.getFinalGrade()==-1)
			return -1;
		return this.getStartTime().compareTo(finishedExam.getStartTime());
	}




}
