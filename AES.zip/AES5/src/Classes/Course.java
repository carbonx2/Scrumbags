/*
 * New
 * @Authors: Alon and Jonathan
 */

package Classes;

public class Course {

	String name;
	String ID;
	String subjectID;
		
	
	public Course(String name,String ID, String subjectID)
	{
		this.name=name;
		this.ID=ID;
		this.subjectID=subjectID;
	}
	
	
	public String getSubjectID() {
		return subjectID;
	}


	public String getName() {
		return name;
	}	


	public String getID() {
		return ID;
	}

	
	
}

