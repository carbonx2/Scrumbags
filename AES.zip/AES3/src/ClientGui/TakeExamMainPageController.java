package ClientGui;

import java.io.IOException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Optional;
import java.util.ResourceBundle;

import Classes.Exam;
import Client.ExamController;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.TextInputDialog;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonBar.ButtonData;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

public class TakeExamMainPageController implements Initializable {
	@FXML
	private Label ErrorLabel;
	
    @FXML
    private Button SubmitButton;

    @FXML
    private Button OpenButton;

    @FXML
    private Label FinishTimeLabel;

    @FXML
    private Label ExecutionCodeLabel;

    @FXML
    private TextField CodeTextField;
    
	@FXML
	private AnchorPane page;


	public ExamWindowController examWindowController;
	public Scene examWindowScene;
	private static final int ALLOWED_CHARACTERS_NUMBER = 4;

	boolean correct = false;;


	public void enableSubmitButton()
	{
		SubmitButton.setDisable(false);
	}
	
	public void disableSubmit()
	{
		SubmitButton.setDisable(true);
	}

	public void submitExam() {
		examWindowController.submitExam("ByUser","Success");

	}


	public void openButtonListener()
	{
		if(examWindowScene!=null)
		{
			Stage stage = new Stage();
			stage.setTitle("Exam");	
			stage.setScene(examWindowScene);
			stage.initModality(Modality.APPLICATION_MODAL);
			stage.initOwner(page.getScene().getWindow());
			stage.showAndWait();
		}		

	}

	public void codeTextFieldListener() {
		String code = CodeTextField.getText();
		if(code.length()!=4) {
			ErrorLabel.setVisible(true);
			ErrorLabel.setText("Code length should be 4 characters");
			return;
		}
		String result = ExamController.checkExamCode(code,MainClient.client.user.getID());	
		switch(result) {
		case "Success":	
			Alert alert = new Alert(AlertType.CONFIRMATION);			
			
			CodeTextField.setVisible(false);
			ExecutionCodeLabel.setVisible(false);
			ErrorLabel.setVisible(false);
			
			alert.setTitle("Choose exam type");
			alert.setHeaderText(null);
			
			alert.setContentText("Choose online to fill the exam online or manual to download a pdf for submission");
			ButtonType buttonTypeOnline = new ButtonType("Online");
			ButtonType buttonTypeManual = new ButtonType("Manual");
			ButtonType buttonTypeCancel = new ButtonType("Cancel", ButtonData.CANCEL_CLOSE);
			alert.getButtonTypes().setAll(buttonTypeOnline, buttonTypeManual, buttonTypeCancel);
			Optional<ButtonType> result2 = alert.showAndWait();
			if (result2.get() == buttonTypeOnline){
				SubmitButton.setVisible(true);
				SubmitButton.setDisable(true);
				OpenButton.setVisible(true);
				FinishTimeLabel.setVisible(true);
				Exam exam = ExamController.takeExam(code);									
				Stage stage = new Stage();
				stage.setTitle("Exam");		
				try {
					FXMLLoader loader = new FXMLLoader();
					Parent root = loader.load(getClass().getResource("/ClientGui/ExamWindow.fxml").openStream());			
					examWindowController = loader.getController();						 							
					examWindowController.setExamCode(code);
					examWindowController.setExam(exam);	
					examWindowController.setTakeExamPageController(this);
					examWindowScene = new Scene(root);
					stage.setScene(examWindowScene);
					stage.initModality(Modality.APPLICATION_MODAL);
					stage.initOwner(page.getScene().getWindow());
					stage.showAndWait();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}					
			} else if (result2.get() == buttonTypeManual) {

			} else
			{
				alert.hide();
				SubmitButton.getScene().getWindow().hide();
			}
			break;
		case "ExamCodeDoesntExist":
			ErrorLabel.setVisible(true);
			ErrorLabel.setText("Exam code does not exist");
			break;
		case "TookExamAlready":
			ErrorLabel.setVisible(true);
			ErrorLabel.setText("Exam already submitted or time is up");
			break;
		}
	}
	
	
	
	
	public void setExamFinishTime(Date finishTime)
	{
		SimpleDateFormat formatter = new SimpleDateFormat("HH:mm");
		String time = formatter.format(finishTime);			
		FinishTimeLabel.setText(FinishTimeLabel.getText()+" "+time);
	}


	public void alert(String title, String message)
	{
		Alert alert = new Alert(AlertType.INFORMATION);
		alert.setTitle(title);
		alert.setHeaderText(null);
		alert.setContentText(message);		
		alert.showAndWait();
	}
	
	

	public void closeWindow()
	{
		SubmitButton.getScene().getWindow().hide();
	}

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		
			}

}
