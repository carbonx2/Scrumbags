package Server;

import java.awt.List;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.swing.JList;
import javax.swing.JTextArea;

import Classes.Course;
import Classes.Exam;
import Classes.FinishedExam;
import Classes.Packet;
import Classes.Person;
import Classes.Question;
import Classes.Subject;
import ocsf.server.AbstractServer;
import ocsf.server.ConnectionToClient;

public class Server extends AbstractServer {
	final public static int DEFAULT_PORT = 5555;
	public static Connection conn = null;
	ExecutorService pool;
	String[] databaseConnection;
	List messages;

	public Server(int port, String[] databaseConnection, List messages) {
		super(port);
		this.messages = messages;
		pool = Executors.newCachedThreadPool();
		connectToDatabase(databaseConnection);

	}

	public void connectToDatabase(String[] databaseConnection) {

		this.databaseConnection = databaseConnection;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
		} catch (Exception ex) {
			try {
				close();
				messages.add(ex.getMessage());
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		try {

			// conn =
			// DriverManager.getConnection("jdbc:mysql://localhost/aes?serverTimezone=UTC&useSSL=false","root","braude");
			conn = DriverManager.getConnection(databaseConnection[0], databaseConnection[1], databaseConnection[2]);
			System.out.println("SQL connection succeed");
			messages.add("SQL connection succeed");
		} catch (SQLException ex) {
			System.out.println("SQLException: " + ex.getMessage());
			System.out.println("SQLState: " + ex.getSQLState());
			System.out.println("VendorError: " + ex.getErrorCode());
			messages.add(ex.getMessage());
			try {
				close();
				conn.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	@Override
	public void handleMessageFromClient(Object msg, ConnectionToClient client) {
		System.out.println("Packet received from: " + client);
		messages.add("Packet received from: " + client);
		pool.execute(new Runnable() {
			public void run() {
				try {
					PacketHandler.handlePacket((Packet) msg, client);					
				} catch (Exception e) {
					e.printStackTrace();
					messages.add(e.getMessage());
				}
			}
		});
	}

	protected void serverStarted() {
		System.out.println("Server listening for connections on port " + getPort());
		messages.add("Server listening for connections on port " + getPort());
		toDo();
	}

	protected void serverStopped() {
		System.out.println("Server has stopped listening for connections.");
		messages.add("Server has stopped listening for connections.");
	}

	public void toDo() {
		
		//HashMap<String,FinishedExam> finishedExams = ExamController.getFinishedExamsById("201232055");
		
		//FinishedExam finishedExam  = finishedExams.get("8");
		/*ExamController.getFinishedExamsById("201232055");*/
	
	//File file = new File("test.txt");
		
		//OutputStream buffer = new OutputStream();
		
		
		
		
		
		
		/*System.out.println(client + " i got here ");
		while(true)
		{
		try {
			Thread.sleep(2000);
			if(!client.isAlive())
			System.out.println("he is null");
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		}*/
		
		/*Calendar cal = Calendar.getInstance();
		Date startTime =  cal.getTime();
		cal.add(Calendar.MINUTE, 351);
		Date finishTime = cal.getTime();
		System.out.println((finishTime.getTime()-startTime.getTime())/60000);*/
	}

	protected void clientConnected(ConnectionToClient client) {
		System.out.println("This client has been connected: " + client);
		messages.add("This client has been connected: " + client);
	}

	synchronized protected void clientDisconnected(ConnectionToClient client) {
		System.out.println("This client has been disconnected: " + client);
		messages.add("This client has been disconnected: " + client);
	}

	public void shutDown() {

		try {
			close();
			conn.close();
		} catch (Exception e) {
			e.printStackTrace();
			messages.add(e.getMessage());
		}

	}

	/*
	 * public static void main(String[] args) { int port = 0; //Port to listen on
	 * String[] databaseConnection=
	 * {"jdbc:mysql://localhost/aes?serverTimezone=UTC&useSSL=false","root","braude"
	 * }; try { port = Integer.parseInt(args[0]); //Get port from command line }
	 * catch(Throwable t) { port = DEFAULT_PORT; //Set port to 5555 } Server sv =
	 * new Server(port,databaseConnection); try { sv.listen(); //Start listening for
	 * connections } catch (Exception ex) {
	 * System.out.println("ERROR - Could not listen for clients!"); }
	 * 
	 * }
	 */

}
