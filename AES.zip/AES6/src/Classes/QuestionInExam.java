package Classes;

import java.io.Serializable;
import java.util.ArrayList;

public class QuestionInExam extends Question implements Serializable {
	private Integer score;
	private String noteForTeacher;
	private String noteForStudent;
	
	public QuestionInExam(Question question, int score) {
		super(question);
		this.score=score;
	}
	
	public void setNoteForStudent(String note) {
		this.noteForStudent=note;
	}
	public void setNoteForTeacher(String note) {
		this.noteForTeacher=note;
	}
	
	public Integer getScore() {
		return score;
	}
	
	public void setScore(int score) {
		this.score=score;
	}
	
	}
