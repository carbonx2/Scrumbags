package Classes;

import java.io.Serializable;

public class Note implements Serializable {
	private String text;
	private int x;
	private int y;
	public Note(String text, int x, int y) {
		super();
		this.text = text;
		this.x = x;
		this.y = y;
	}
	
	
}

