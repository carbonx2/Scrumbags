package ClientGui;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

import Classes.Course;
import Classes.Question;
import Classes.QuestionInExam;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Pagination;
import javafx.scene.control.ScrollPane;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.VBox;

public class ExamPreviewAndSubmitController implements Initializable {
	public static final int itemsPerPage = 4;
	public ObservableList<QuestionInExam> questionsInExamList;
	private ArrayList<ExamFormPageController>  pagesList;	
	private ArrayList<Node> layoutList;
	
	@FXML
	public Pagination pagination;
	
	@FXML
	public Button CancelButton;
	
	@FXML
	public Button SubmitButton;
	 
	private ExamPreviewPageController firstPageController;
	private Node firstPageLayout;
		
	private Course course;
	
	public ArrayList<AnchorPane> PagesLayouts;
	
	public void setQuestionsInExam(ObservableList<QuestionInExam> questionsInExamList)
	{
		this.questionsInExamList = questionsInExamList;
		setPageCount();

	}
	
	
	
	public void cancelButtonListener(ActionEvent event)
    {
    	((Node) event.getSource()).getScene().getWindow().hide();
    }
		
	 public ScrollPane createPage(int pageIndex) {	
		
		 try {
			 ScrollPane scrollPane = new ScrollPane();
			 if (pageIndex == 0 )
			 {	 
				 Node layout;
				 if(firstPageController == null)		
				 {
					 FXMLLoader loader = new FXMLLoader();
					 layout= loader.load(getClass().getResource("/ClientGui/ExamPreviewPage.fxml").openStream());							
					 ExamPreviewPageController controller = loader.getController();
					 controller.setCourseName(course.getName());
					 firstPageController = controller;
					 firstPageLayout = layout;
				 }
				 layout =  firstPageLayout;
				 scrollPane.setContent(layout);
				 return scrollPane;
			 }	
			 int page = (pageIndex-1) * itemsPerPage;	
			 Node layout;
			 ExamFormPageController controller;
			 if(pagesList.size()<pageIndex)	
			 {
				 FXMLLoader loader = new FXMLLoader();	
				 layout = loader.load(getClass().getResource("/ClientGui/ExamFormPage.fxml").openStream());
				 controller = loader.getController();
				 pagesList.add(controller);
				 layoutList.add(layout);
				 for (int i = page; i < page + itemsPerPage && i<questionsInExamList.size(); i++)
					 controller.addQuestions(questionsInExamList.get(i),pagesList.size()-1+i);
			 }	
			 controller = pagesList.get(pageIndex-1);
			 layout = layoutList.get(pageIndex-1);
			 scrollPane.setContent(layout);		    
			 return scrollPane;
		 	}	
		 	catch (Exception e) {
		 		return null;
		 	}	
	}

	  
	 
	 

	 public String fixQuestion(String str)
	 {		 	 		
		 if(str.length()<=65)
			 return str;
		 if(str.length()<=130)
			 return str.substring(0, 65)+"\n      "+str.substring(65, str.length());
		 else
			 return str.substring(0, str.length()/2)+"\n      "+str.substring(str.length()/2, str.length());
	 }
	 
	 public void setPageCount()
	 {
		 if(questionsInExamList.size()%itemsPerPage == 0)
			 pagination.setPageCount(questionsInExamList.size()/itemsPerPage +1);		 
				
		 else
			 pagination.setPageCount(questionsInExamList.size()/itemsPerPage+2);
				
	 }
	 
			
	public void setCourse(Course course)
	{
		this.course = course;
	}
	 
	
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {		
		pagination.setPageFactory((Integer pageIndex)->createPage(pageIndex));
		firstPageController = null;
		firstPageLayout = null;
		pagesList = new ArrayList<ExamFormPageController>();
		layoutList = new ArrayList<Node>();
		
		
	}
}
