package ClientGui;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

import Classes.Course;
import Classes.Question;
import Classes.QuestionInExam;
import Client.QuestionController;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableColumn.CellEditEvent;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.cell.TextFieldListCell;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.util.StringConverter;

public class CreateExamsController implements Initializable{
	
	public ObservableList<QuestionInExam> questionsInExamList = FXCollections.observableArrayList();
	public ObservableList<Question> questionsList = FXCollections.observableArrayList();
	@FXML
    private TableView<QuestionInExam> QuestionsInExamList;

    @FXML
    private TableColumn<QuestionInExam, String> QuestionsColumn;

    @FXML
    private TableColumn<QuestionInExam, String> ScoresColumn;

    @FXML
    private ListView<Question> QuestionsList;

    @FXML
    private TextArea QuestionPreviewText;

    @FXML
    private Button AddQuestionToExamButton;

    @FXML
    private Button RemoveQuestionFromExamButton;

    @FXML
    private Button SubmitExamButton;
    
    @FXML
    private Button CancelButton;    
  
    private Course course;
    
    public void cancelButtonListener()
    {
    	CancelButton.getScene().getWindow().hide();
    }
    
    public void submitExamListener()
    {
    	Stage examPreviewStage = new Stage();
    	examPreviewStage.setTitle("Exam Preview Page");
    	Parent root;
		try {
			FXMLLoader loader = new FXMLLoader();
			root = loader.load(getClass().getResource("/ClientGui/ExamPreviewAndSubmitWindow.fxml").openStream());
			ExamPreviewAndSubmitController controller = loader.getController();
			controller.setQuestionsInExam(questionsInExamList);	
			controller.setCourse(course);
			Scene scene = new Scene(root);
	    	examPreviewStage.setScene(scene);
	    	examPreviewStage.initModality(Modality.APPLICATION_MODAL);
	    	examPreviewStage.initOwner(SubmitExamButton.getScene().getWindow());
	    	
	    	examPreviewStage.showAndWait();
	    	
	    	

		} catch (IOException e) {
		
			e.printStackTrace();
		}
    	
    	
    	
    }

    public void updateQuestionsList() {
    	ArrayList<Question> questionlist = QuestionController.getQuestionList();
    	questionsList.setAll(questionlist);
    }
    
    public void showQuestionPreview(Question question) {
		QuestionPreviewText.setText("Question: "+question.getQuestion()+"\n\n1)"+question.getAnswer(1)+"\n2)"+question.getAnswer(2)+"\n3)"+question.getAnswer(3)+"\n4)"+question.getAnswer(4)+"\n\nAuthor: "+question.getAuthor().getName());
	}
    
    public void addQuestionToExam(Question question) {
    	questionsInExamList.add(new QuestionInExam(question,0));
    	questionsList.remove(question);
    }
    
    public void removeQuestionFromExam(QuestionInExam question) {
    	questionsList.add(new Question(question));
    	questionsInExamList.remove(question);
    	
    }
    
    
    public void leftArrowButtonClicked()
    {
    	Question question = QuestionsList.getSelectionModel().getSelectedItem();
    	if(question!=null)
    		addQuestionToExam(question);
    }
    
    public void rightArrowButtonClicked() 
    {
    	QuestionInExam question = QuestionsInExamList.getSelectionModel().getSelectedItem();
    	if(question!=null)
    		removeQuestionFromExam(question);
    }
    
    public void pressEnter()
   {
	   java.awt.Robot robot;
	try {
		robot = new Robot();
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
	} catch (AWTException e) {		
		e.printStackTrace();
	}
		
   }
    
    public void setCourse(Course course)
    {
    	this.course = course;
    }
    
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {		
		updateQuestionsList();	
		QuestionsInExamList.setPlaceholder(new Label("No questions added yet"));
		QuestionsList.setItems(questionsList);
		QuestionsInExamList.setItems(questionsInExamList);
		QuestionsColumn.setCellValueFactory(e -> new SimpleStringProperty(e.getValue().getQuestion()));
		ScoresColumn.setCellValueFactory(e -> new SimpleStringProperty(e.getValue().getScore().toString()));
		QuestionsInExamList.setEditable(true);
		ScoresColumn.setEditable(true);
		ScoresColumn.setCellFactory(TextFieldTableCell.forTableColumn());
		ScoresColumn.setOnEditCommit((CellEditEvent<QuestionInExam, String> t) -> {
			QuestionInExam qis = QuestionsInExamList.getSelectionModel().getSelectedItem();
				if(t.getNewValue().matches("[0-9]*"))
					qis.setScore(Integer.parseInt(t.getNewValue()));
			    else
			    	QuestionsInExamList.refresh(); 	
		});
		
    	QuestionsList.setCellFactory(lv -> {
            TextFieldListCell<Question> cell = new TextFieldListCell<Question>(); 
            cell.setConverter(new StringConverter<Question>() {
                @Override
                public String toString(Question question) {
                    return question.getQuestion();
                }
                @Override
                public Question fromString(String string) {
                	return null;
                }
            });
            return cell;
        });
    	

    	QuestionsList.getSelectionModel().selectedItemProperty().addListener(e -> {
    		Question question = QuestionsList.getSelectionModel().getSelectedItem();
    		if(question != null)
    			showQuestionPreview(question);
    	});
		
    	QuestionsInExamList.getSelectionModel().selectedItemProperty().addListener(e -> {
    		QuestionInExam questionInExam = QuestionsInExamList.getSelectionModel().getSelectedItem();
    		if(questionInExam != null) 
    			showQuestionPreview(questionInExam);
    			
    	});
	}

	


}
