package ClientGui;

import java.net.URL;
import java.util.Calendar;
import java.util.ResourceBundle;

import Classes.Teacher;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

public class ExamPreviewPageController implements Initializable {
	
	@FXML
	private TextField textField;
	@FXML
	private Label courseName;
	
	@FXML
	private Label dateLabel;
	@FXML
	private Label authorLabel;
	
	
	
	public void  examTimeTextListener()
	{		
		
		if (!textField.getText().matches("\\d*")) {
            textField.setText(textField.getText().replaceAll("[^\\d]", ""));
        }	
		       
	
	}
	
	public void setCourseName(String courseName)
	{
		this.courseName.setText(courseName);
	}
	
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		Teacher teacher = (Teacher)Client.Client.user;
		authorLabel.setText(teacher.getName());
		Calendar date = Calendar.getInstance();
		
		dateLabel.setText(date.get(date.DAY_OF_MONTH)+"/"+date.get(date.MONTH)+"/"+date.get(date.YEAR));
		
		
	}
	
}
