/*package ClientGui;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

import Classes.QuestionInExam;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.layout.VBox;

public class ExamFormPageController2 implements Initializable {

	
	private int numberOfQuestions;
	private ArrayList<QuestionInExam> questionsList;

    @FXML
    private VBox OurVBox;
	
    @FXML
    private TextArea Question1NoteStudent;

    @FXML
    private TextArea Question1NoteTeacher;

    @FXML
    private Label Question1;
    
    @FXML
    private Label Answer11;

    @FXML
    private Label Answer12;

    @FXML
    private Label Answer13;

    @FXML
    private Label Answer14;

    @FXML
    private TextArea Question2NoteStudent;

    @FXML
    private TextArea Question2NoteTeacher;

    @FXML
    private Label Question2;

    @FXML
    private Label Answer21;

    @FXML
    private Label Answer22;

    @FXML
    private Label Answer23;

    @FXML
    private Label Answer24;

    @FXML
    private TextArea Question3NoteStudent;

    @FXML
    private TextArea Question3NoteTeacher;

    @FXML
    private Label Question3;

    @FXML
    private Label Answer31;

    @FXML
    private Label Answer32;

    @FXML
    private Label Answer33;

    @FXML
    private Label Answer34;

    @FXML
    private TextArea Question4NoteStudent;

    @FXML
    private TextArea Question4NoteTeacher;

    @FXML
    private Label Question4;

    @FXML
    private Label Answer41;

    @FXML
    private Label Answer42;

    @FXML
    private Label Answer43;

    @FXML
    private Label Answer44;

    
    
    public void addQuestions(QuestionInExam question)
    {
    	numberOfQuestions++;
    	
    	switch(numberOfQuestions)
    	{
    	case 1:
    		Question1.setText(question.getQuestion()+"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
    		Answer11.setText(question.getAnswer(1));
    		Answer12.setText(question.getAnswer(2));
    		Answer13.setText(question.getAnswer(3));
    		Answer14.setText(question.getAnswer(4));
    		questionsList.add(question);
    		Question1.setVisible(true);
    		Answer11.setVisible(true);
    		Answer12.setVisible(true);
    		Answer13.setVisible(true);
    		Answer14.setVisible(true);
    		Question1NoteStudent.setVisible(true);
    		Question1NoteTeacher.setVisible(true);
    		break;
    	case 2:
    		Question2.setText(question.getQuestion());
    		Answer21.setText(question.getAnswer(1));
    		Answer22.setText(question.getAnswer(2));
    		Answer23.setText(question.getAnswer(3));
    		Answer24.setText(question.getAnswer(4));
    		questionsList.add(question);
    		Question2.setVisible(true);
    		Answer21.setVisible(true);
    		Answer22.setVisible(true);
    		Answer23.setVisible(true);
    		Answer24.setVisible(true);
    		Question1NoteStudent.setVisible(true);
    		Question1NoteTeacher.setVisible(true);
    		break;
    	case 3:
    		Question3.setText(question.getQuestion());
    		Answer31.setText(question.getAnswer(1));
    		Answer32.setText(question.getAnswer(2));
    		Answer33.setText(question.getAnswer(3));
    		Answer34.setText(question.getAnswer(4));
    		questionsList.add(question);
    		Question3.setVisible(true);
    		Answer31.setVisible(true);
    		Answer32.setVisible(true);
    		Answer33.setVisible(true);
    		Answer34.setVisible(true);
    		Question1NoteStudent.setVisible(true);
    		Question1NoteTeacher.setVisible(true);
    		break;
    	case 4:
    		Question4.setText(question.getQuestion());
    		Answer41.setText(question.getAnswer(1));
    		Answer42.setText(question.getAnswer(2));
    		Answer43.setText(question.getAnswer(3));
    		Answer44.setText(question.getAnswer(4));
    		questionsList.add(question);
    		Question4.setVisible(true);
    		Answer41.setVisible(true);
    		Answer42.setVisible(true);
    		Answer43.setVisible(true);
    		Answer44.setVisible(true);
    		Question1NoteStudent.setVisible(true);
    		Question1NoteTeacher.setVisible(true);
    		break;
    	}
    	
    
    	
 
    }
   
    public ArrayList<QuestionInExam> getQuestions()
    {    	
    	for(int i =0 ; i< numberOfQuestions ; i++)
    	{
    		switch(i)
    		{
    		case 0:    			
    			QuestionInExam question1 = questionsList.get(i);
    			question1.setNoteForTeacher(Question1NoteTeacher.getText());
    			question1.setNoteForStudent(Question1NoteStudent.getText());
    			break;
    			
    		case 1:
    			
    			QuestionInExam question2 = questionsList.get(i);
    			question2.setNoteForTeacher(Question2NoteTeacher.getText());
    			question2.setNoteForStudent(Question2NoteStudent.getText());
    			break;
    		case 2:    			
    			QuestionInExam question3 = questionsList.get(i);
    			question3.setNoteForTeacher(Question3NoteTeacher.getText());
    			question3.setNoteForStudent(Question3NoteTeacher.getText());
    			
    		case 3:    			
    			QuestionInExam question4 = questionsList.get(i);
    			question4.setNoteForTeacher(Question4NoteTeacher.getText());
    			question4.setNoteForStudent(Question4NoteStudent.getText());	
    		}
    	}
    	return questionsList;    	
    		
        
    } 
   
    
    public String fixString(String str)
	 {		 	 		
		 if(str.length()<=70)
			 return str;
		 if(str.length()<=140)
			 return str.substring(0, 70)+"\n          "+str.substring(70, str.length());
		 else
			 return str.substring(0, str.length()/2)+"\n          "+str.substring(str.length()/2, str.length());
	 }
	 
    
    
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		numberOfQuestions = 0;
		questionsList = new ArrayList<QuestionInExam>();
		
	}

}
*/