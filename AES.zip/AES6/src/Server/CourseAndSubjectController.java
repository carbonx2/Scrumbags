/*package Server;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;

import AES_Classes.Author;
import AES_Classes.Course;
import AES_Classes.Question;
import AES_Classes.Subject;

public class CourseAndSubjectController {

	public static HashSet<Subject> getTeacherSubjects(String ID){
		try {
			Statement stmt1 = Server.conn.createStatement();
			Statement stmt2 = Server.conn.createStatement();
			ResultSet rs = stmt1.executeQuery("SELECT S.Name, S.ID FROM TEACHERSUBJECTS TS, SUBJECTS S WHERE TEACHER='"+ID+"' AND TS.SUBJECT=S.ID ;");
			
			HashSet<Subject> ListOfSubjects = new HashSet<Subject>();
			while(rs.next())		
			{	Subject subject =new Subject(rs.getString(1),rs.getString(2));
				ListOfSubjects.add(subject);
			}						
			return ListOfSubjects;
			
		} catch (SQLException e) {			
			e.printStackTrace();
			return null;
		}
	}
	
	public static HashSet<Course> getTeacherCourse(String ID){
		try {
			Statement stmt1 = Server.conn.createStatement();
			Statement stmt2 = Server.conn.createStatement();
		
			ResultSet rs = stmt1.executeQuery("SELECT C.ID, C.Name, C.Subject FROM TEACHERCOURSES TC, COURSES C WHERE TC.TEACHER='"+ID+"' AND TC.COURSE= C.ID ;");
			
			HashSet<Course> ListOfCourses = new HashSet<Course>();
			while(rs.next())
			{				
				Course course =new Course(rs.getString(1),rs.getString(2),rs.getString(3));
				ListOfCourses.add(course);
			}			
			
			return ListOfCourses;
			
		} catch (SQLException e) {	
			System.out.println(e);
			e.printStackTrace();
			return null;
		}
	}
}
*/