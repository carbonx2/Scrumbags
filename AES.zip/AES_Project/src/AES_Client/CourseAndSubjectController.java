package AES_Client;

import java.util.ArrayList;

import AES_Classes.Course;
import AES_Classes.Packet;
import AES_Classes.Subject;
import ClientGUI.MainClient;

public class CourseAndSubjectController 
{
	public static ArrayList<Course> getCourseList()//get all courses in system list
	{
		int ID=MainClient.client.sendToServerAJ(new Packet("GetCourseList",null));
		return (ArrayList<Course>) MainClient.client.getResponse(ID).getData();
	}
	public static ArrayList<Subject>  getSubjectList()//get all subjects in system list
	{
		int ID=MainClient.client.sendToServerAJ(new Packet("GetAllSubjectsList",null));
		return (ArrayList<Subject>) MainClient.client.getResponse(ID).getData();
	}
	public static String  getSubjectIDByName(String name)//get subject id by name
	{
		int ID=MainClient.client.sendToServerAJ(new Packet("GetIDSubjectByName",name));
		return (String) MainClient.client.getResponse(ID).getData();
	}
}
