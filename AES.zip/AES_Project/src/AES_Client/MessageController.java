package AES_Client;

import java.util.ArrayList;

import AES_Classes.ExtendTimeMessage;
import AES_Classes.Packet;
import ClientGUI.MainClient;

public class MessageController {

	
	
	
	public static String requestTimeExtension(ExtendTimeMessage message)        
	{		
		Packet packet = new Packet("RequestTimeExtension", message);
		int requestID = MainClient.client.sendToServerAJ(packet);
		packet = MainClient.client.getResponse(requestID);
		return (packet.getOperation());
	}
	
	public static ArrayList<ExtendTimeMessage> receiveRequests()
	{
		Packet packet = new Packet("ReceiveRequest", null);
		int requestID = MainClient.client.sendToServerAJ(packet);
		packet = MainClient.client.getResponse(requestID);
		return (ArrayList<ExtendTimeMessage>) (packet.getData());
	}
	
	public static void removeRequest(ExtendTimeMessage message)
	{		
		Packet packet = new Packet("DeclineRequest", message);
		int requestID = MainClient.client.sendToServerAJ(packet);
		packet = MainClient.client.getResponse(requestID);
		
	}
}
