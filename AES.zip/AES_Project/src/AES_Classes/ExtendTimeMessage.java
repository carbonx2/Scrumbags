package AES_Classes;

import java.io.Serializable;
import java.util.Date;



public class ExtendTimeMessage extends Message implements Serializable{	
	
	Integer examID;
	Integer timeExtension;
	
	
	public ExtendTimeMessage(String message, Person sender,Integer examID, Integer timeExtension) {
		
		super(sender, message);
		this.examID = examID;
		this.timeExtension = timeExtension;				
		
	}


	public ExtendTimeMessage(Message message, Integer examID, Integer timeExtension) {
		
		super(message.getSender(),message.getMessage());
		this.examID = examID;
		this.timeExtension = timeExtension;				
		
	}



	public Integer getExamID() {
		return examID;
	}


	public void setExamID(Integer examID) {
		this.examID = examID;
	}


	public Integer getTimeExtension() {
		return timeExtension;
	}

	public String getTimeExtensionMinutes() {
		return timeExtension+" Minutes";
	}
	public void setTimeExtension(Integer timeExtension) {
		this.timeExtension = timeExtension;
	}
	
	

}
