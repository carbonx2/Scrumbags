package AES_Classes;

import java.io.Serializable;

public class Subject implements Serializable {

	String ID;
	String name;	
		
	
	public Subject(String ID, String name) {
		this.name = name;
		this.ID = ID;
	}
	
	
	public String getName() {
		return name;
	}	


	public String getID() {
		return ID;
	}

	public String toString() {
		return "ID(" + ID + "), name(" + name + ")";
	}
	
}
