package AES_Classes;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Message implements Serializable {

	String message;
	Person sender;
	Date date;
	
	public Message(Person sender, String message)
	{
		this.message = message;
		this.sender = sender;	
		date = new Date();
	}
	
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public Person getSender() {
		return sender;
	}
	public void setSender(Person sender) {
		this.sender = sender;
	}
	public Date getDate() {
		
		/*SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy");
		return format.format(date);*/
		return date;
		
	}
	public String getFormattedDate() {

		SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
		return format.format(date);


	}
	public void setDate(Date date) {
		this.date = date;
	}
}
