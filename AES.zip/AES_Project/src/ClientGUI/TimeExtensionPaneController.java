package ClientGUI;

import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;

import AES_Classes.ExecutedExam;
import AES_Classes.ExtendTimeMessage;
import AES_Classes.Person;
import AES_Classes.Teacher;
import AES_Client.MessageController;
import AES_Client.UserController;
import AES_Client.client;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;

public class TimeExtensionPaneController implements Initializable {

    @FXML
    private TextArea ReasonTextArea;

    @FXML
    private TextField TimeTextField;

    @FXML
    private Label TimeLabel;

    @FXML
    private Button ConfirmButton;

    @FXML
    private Button CancelButton;
    
    private String examID;
    
    
    
    
    public void ReasonTextAreaListener() {
    	if(ReasonTextArea.getText().trim().length()==0)
    		ConfirmButton.setDisable(true);
    	else
    		ConfirmButton.setDisable(false);
    }
            
       
    public void TimeTextFieldListener()    {    	
    	    	
    	    	if(TimeTextField.getText().trim().length()>0) {
    	    		
    	    		if(TimeTextField.getText().charAt(0)=='0') 
    	    			TimeTextField.setText(TimeTextField.getText().substring(1));
    	    		if (!TimeTextField.getText().matches("\\d*"))
    	    			TimeTextField.setText(TimeTextField.getText().replaceAll("[^\\d]", ""));  
    	    		
    	    		ReasonTextArea.clear();
    	    		ReasonTextArea.setVisible(true);
    	    		
    	    	}    
    	    	else
    	    		ReasonTextArea.setVisible(false);
    	    	
    	    }
    
    
    public void confirmButtonListener()
    {    	
    	Teacher teacher = (Teacher)GUI_LoginController.user;   	
    	Person sender = new Person(teacher.getID(), teacher.getFirstName()+" "+teacher.getLastName());
    	ExtendTimeMessage message = new ExtendTimeMessage(ReasonTextArea.getText(), sender, Integer.parseInt(examID),Integer.parseInt(TimeTextField.getText()));
    	String answer = MessageController.requestTimeExtension(message);
    			if(answer.equals("Success"))
    				alert("Confirm","Request Sent");
    			else
    				alert("Confirm","Request didn't Send");
    	ConfirmButton.getScene().getWindow().hide();
    }
    
    	public void alert(String title, String message)
    	{
    		Alert alert = new Alert(AlertType.INFORMATION);
    		alert.setTitle(title);
    		alert.setHeaderText(null);
    		alert.setContentText(message);
    		alert.showAndWait();

    	}
    
    public void cancelButtonListener()
    {
    	CancelButton.getScene().getWindow().hide();	
    }

    public void setExamID(String examID)
    {
    	this.examID = examID;
    }


	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		
		
	}
    
}
