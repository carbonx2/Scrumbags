package ClientGUI;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URL;
import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Optional;
import java.util.ResourceBundle;
import AES_Classes.*;
import AES_Client.*;
import AES_Client.ExamController;

import ClientGUI.*;
import javafx.application.Platform;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.value.ChangeListener;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Rectangle2D;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.chart.XYChart.Data;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ButtonBar.ButtonData;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.ListCell;
import javafx.scene.control.ListView;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.TextInputDialog;
import javafx.scene.control.TreeItem;
import javafx.scene.control.TreeView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TextFieldListCell;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;
import javafx.stage.FileChooser;
import javafx.stage.Modality;
import javafx.stage.Screen;
import javafx.stage.Stage;
import javafx.util.Callback;
import javafx.util.StringConverter;

public class HomePageController implements Initializable{
	
	/**==================================
	 *=General parameters========== 
	 *==================================
	 */
	public static User OnlineUser;
	int HomePagePermission;
	
	/**==================================
	 *=GUI Home page General parameters========== 
	 *==================================
	 */
	@FXML private Label hellomsg;
	@FXML private Label welcome;
	@FXML private Label txt_title;
	@FXML private TreeView<String> Options;
	@FXML private Button btn_logOut;
	/**==================================
	 *=Question options parameters========== 
	 *==================================
	 */
		/**==================================
		 *=Create Question Pane parameters========== 
		 *==================================
		 */
		@FXML private ComboBox<Subject> SubjectCQComboBox;
		@FXML private Label lbl_CQ;
		@FXML private Label MessageCQ;
		@FXML private AnchorPane CreateQuestionPane;
		public static Stage QuestionCreateWindow;
		/**==================================
		 *=Question View Pane parameters========== 
		 *==================================
		 */
		@FXML private ComboBox<Subject> SubjectComboBox;
		@FXML private ListView<Question> QuestionList= null;
		private ArrayList<Question> questionList;
		@FXML private TextArea QuestionPreview;
		@FXML private Button btn_editquestion;
		@FXML private Label lbl_Q;
		@FXML private Button btn_delete;
		@FXML private Label messageQuestionView;
		@FXML private AnchorPane QuestionViewPane;
		public static Stage QuestionViewWindow;
		
		
		/**==================================
		 *=Exam options parameters========== 
		 *==================================
		 */
			/**==================================
			 *=Exam View Pane parameters========== 
			 *==================================
			 */
		@FXML private Label MessageE;
		@FXML private Label lbl_E;
		@FXML private ListView<Exam> ExamsList = null;
		private ArrayList<Exam> examsList;
		@FXML private ComboBox<Subject> SubjectEComboBox;
		@FXML private ComboBox<Course> CourseComboBox;
		@FXML private Button ReloadExamsButton;
		@FXML private Button btn_remove;
		@FXML private Button ViewExamButton;
		@FXML private Button ExecuteExamButton;
		@FXML private Label CourseNameLabel;
		@FXML private Label AuthorLabel;
		@FXML private Label DateLabel;
		@FXML private Label FreeTextLabel;
		@FXML private Label ExamTimeLabel;
		@FXML private Label messageExamView;
		@FXML private AnchorPane ExamPreviewPane;
		@FXML private AnchorPane ExamViewPane;
		public static Stage ViewExamWindow;
		/**==================================
		 *=Create Exam Pane parameters========== 
		 *==================================
		 */		
		@FXML private Button ConfirmButton;
		@FXML private ComboBox<Course> CourseECComboBox;
		@FXML private ComboBox<Subject> SubjectECComboBox;
		@FXML private Label lbl_CE;
		@FXML private Label MessageCE;
		@FXML private Label messageExamCreate;
		@FXML private AnchorPane CreateExamPane;
		public static Stage ExamCreateWindow;
		/**==================================
		 *=Active Exam Pane parameters========== 
		 *==================================
		 */	
		@FXML private AnchorPane ActiveExamPane;
		@FXML private AnchorPane ExecutedExamPreviewPane;
		@FXML private ListView<Exam> ExecutedExamsList;
		@FXML private Button ReloadExecutedExamsButton;
		@FXML private Button ViewExecutedExamButton;
		@FXML private Button LockExecutedExamButton;
		HashMap<Exam,String> executedExamsList;
		@FXML private Label ExecutedCourseNameLabel;
		@FXML private Label ExecutedDateLabel;
		@FXML private Label ExecutedAuthorLabel;
		@FXML private Label ExecutedExamTimeLabel;
		@FXML private Label ExecutedFreeTextLabel;
		@FXML private Button ExtendTimeButton;
		/**==================================
		 *=Finished Exam Pane parameters========== 
		 *==================================
		 */	
		@FXML private AnchorPane FinishedExamPane;
		@FXML private ListView<ExecutedExam> FinishedExamsList;
		@FXML private ListView<FinishedExam> StudentExamsList;
		@FXML private Button ReviewFinishedExamButton;
		@FXML private Button ReloadFinishedExamsButton;
		@FXML private ListView<Integer> CheatingGroupList;
		HashMap<ExecutedExam,HashSet<FinishedExam>> finishedExamsList;
		
		
	/**==================================
	 *=Take Exam Pane parameters========== 
	 *==================================
	 */	
		@FXML private AnchorPane TakeExamPane;	
		@FXML public Button SubmitButton;
		@FXML public Button OpenButton;
		@FXML public Label FinishTimeLabel;
		@FXML public Label ExecutionCodeLabel;
		@FXML public TextField CodeTextField;
		@FXML private Label ErrorLabel;
		@FXML private Button SubmitManualButton;
		@FXML private Button DownloadButton;
		@FXML public Label MessageActive;
		private String examExecutionCode;
		private Date manualExamFinishTime;
		ManualExamFile manualExam;
		private Examinee examinee;
		public ExamGUIController examGuiController;
		public Scene examWindowScene;
		private static final int ALLOWED_CHARACTERS_NUMBER = 4;
		boolean correct = false;;
		
		
		/**==================================
		 *=Student view Exam Pane parameters========== 
		 *==================================
		 */	
			@FXML private AnchorPane StudentViewExamPane;
			@FXML private ListView<FinishedExam> StudentExamViewList;
			@FXML private TextArea StudentExamDetails;
			@FXML private Button StudentViewExamButton;
			private ArrayList<FinishedExam> studentiewlist;
			
		/**==================================
		 *=Manger question page parameters========= 
		 *==================================
		 */
		@FXML private  AnchorPane  ManagerquestionPane;//this is the pane of the question view screen option in mangerGui_FXML
		@FXML private ComboBox<String> SubjectComboBoxManger;//this combo box lets user choose a subject to show its questions
		@FXML private Button viewQuestionBtn;//this btn lets user see an unable version of the question he choose from table
		@FXML private TableView<Question> questionTable;//this is the table to show question details 
		@FXML private TableColumn<Question,String> question;//this is the question column 
		@FXML private TableColumn<Question,String> author;//this is the author column 
		@FXML private TableColumn<Question,String> qId;//this is the question id column
		private ArrayList<Subject> ManagersubjectList ;
		@FXML private TextArea QuestionPreview1;
		private ObservableList<String> ManagersubjectsDetails=FXCollections.observableArrayList();//to show subjects details
		private ObservableList<Question> ManagerquestionDetails=FXCollections.observableArrayList();//to show subjects details
		/**==================================
		 *=Manger course page parameters========= 
		 *==================================
		 */
		private ArrayList<Course> courseList ;
		private ObservableList<Course> coursesDetails=FXCollections.observableArrayList();//to show courses details
		@FXML private  AnchorPane  ManagercoursesPane;//this is the pane of the courses view screen option in mangerGui_FXML
		@FXML private TableView<Course> ShowDataTable;//this is the table to show courses details
		@FXML private TableColumn<Course,String> colName;//this is the name column 
		@FXML private TableColumn<Course,String> colSubject;//this is the subject column 
		@FXML private TableColumn<Course,String> colId;//this is the id column
		/**==================================
		 *=Manager Users page parameters========= 
		 *==================================
		 */		
			/**==================================
			 *=Manager Teacher page parameters========= 
			 *==================================
			 */
		@FXML private  AnchorPane ManagerteacherPane;//this is the pane of the teacher view screen option in mangerGui_FXML
		@FXML private TableView<Teacher> ManagerteacherTable;//this is the table to show teacher details
		@FXML private TableColumn<Teacher,String> teacherid;
		@FXML private TableColumn<Teacher,String> techerFirstName;//this is the firstName column 
		@FXML private TableColumn<Teacher,String> teacherLastName;//this is the lastName column 
		@FXML private Button teacherViewCourses;//with this btn we move to teacherCoursesPage to its courses by subject
			/**==================================
			 *=teacher courses page parameters==
			 *==================================
			 */
		@FXML private  AnchorPane ManagerteacherCoursesPane; //this is the pane of the teacher courses view screen option in mangerGui_FXML
		@FXML private ComboBox<String> ManagertecherChooseSubject;//this combo box lets user choose a subject to show its teacher courses
		@FXML private Button Back_btn;//this btn rolls back to the teacher screen
		@FXML private TableView<Course> teacherShowCoursesTable;//this is the table to show subject courses of teacher details
		@FXML private TableColumn<Course,String> teacherCourseName;//this is the course name column 
		@FXML private TableColumn<Course,String> teacherCourseId;//this is the course id column 
		@FXML private  Label showNoCoursesLable;
		/**==================================
		 *=Manager page parameters============
		 *==================================
		 */
		@FXML private  AnchorPane managersPane;
		@FXML private TableView<SchoolManager> managerTable ;
		@FXML private TableColumn<SchoolManager,String> managerid;
		@FXML private TableColumn<SchoolManager,String> managerFirstName;
		@FXML private TableColumn<SchoolManager,String> managerLastName;
		private ArrayList<SchoolManager> managersList;
		private ObservableList<SchoolManager> managersDetails=FXCollections.observableArrayList();//to show courses details
		/**==================================
		 *=Manger Students Pane parameters============
		 *==================================
		 */
		@FXML private  AnchorPane managerStudentsPane;
		@FXML private TableView<Student> ManagerstudentTable ;
		@FXML private TableColumn<Student,String> studentid;
		@FXML private TableColumn<Student,String> studentFirstName;
		@FXML private TableColumn<Student,String> studentLastName;
		private ObservableList<Student> ManagerstudentsDetails=FXCollections.observableArrayList();
		private ArrayList<Student> ManagerstudentsList;
		@FXML private Button viewExamsButton;
		@FXML private ListView<FinishedExam> ManagerStudentExamsList;
		@FXML private Button viewExamsPreviewButton;
		private ArrayList<FinishedExam> ManagerStudentfinishedExamsList;
		
		/**==================================
		 *=Manager user Page parameters============
		 *==================================
		 */
		@FXML private  AnchorPane ManageruserPane;
		@FXML private TableView<User> usersTable;
		@FXML private TableColumn<User,String> userId;
		@FXML private TableColumn<User,String> userPassword;
		@FXML private TableColumn<User,String> userPermission;
		private ArrayList<User> userList ;
		private ObservableList<User> userDetails=FXCollections.observableArrayList();	

		/**==================================
		 *=Manager Messages Page parameters============
		 *==================================
		 */
		@FXML private AnchorPane ManagerMessagesPane;		
		@FXML private TableView<ExtendTimeMessage> MessagesTable;
		@FXML private Button ReloadMessagesButton;
		@FXML private Button ApproveButton;
		@FXML private Button DeclineButton;	
		@FXML private TextArea MessageViewTextArea;	
		@FXML private TableColumn<ExtendTimeMessage, String> Received;
	    @FXML private TableColumn<ExtendTimeMessage, String> Sender;
	    @FXML private TableColumn<ExtendTimeMessage, String> TimeExtension;
	    private ObservableList<ExtendTimeMessage> messagesList=FXCollections.observableArrayList();
		
		/**==================================
		 *=Statistical information parameters============
		 *==================================
		 */
			/**==================================
			 *=Statistical information by courses parameters============
			 *==================================
			 */
			@FXML private  AnchorPane CourseStatisticalInfoPane;
			@FXML private ComboBox<Course> StaticCourseComboBox;
			@FXML private ComboBox<Exam> StaticCourseExamComboBox;
			@FXML private ListView<ExecutedExam> StatisticCourseExcutedExamList;
			@FXML private Label messageNoExams;
			@FXML private BarChart<String, Integer> CourseBarChart;
			@FXML private CategoryAxis decline;
			@FXML private NumberAxis StudentsCount;
			
			/**==================================
			 *=Statistical information by teachers parameters============
			 *==================================
			 */
			@FXML private  AnchorPane TeacherStatisticalInfoPane;
			@FXML private ComboBox<Teacher> StaticTeacherComboBox;
			@FXML private ComboBox<Exam> StaticTeacherExamComboBox;
			@FXML private ListView<ExecutedExam> StatisticTeacherExcutedExamList;
			@FXML private Label messageNoExams1;
			/**==================================
			 *=Statistical information by students parameters============
			 *==================================
			 */
			
			@FXML private ComboBox<Student> StaticStudentComboBox;
		/**
 *=General Home page method
 *=Click Log Out                                 
 *=this method performed when client click button log out
 *=will log out the client from the system
*=ask him before if he wants to logout
 */
@FXML
public void ClickLogOut(ActionEvent event) {
		
		Platform.runLater(new Runnable(){
            
            public void run()
            {           
			Alert alert = new Alert(AlertType.CONFIRMATION);
			alert.setContentText("Are you sure you want to exit?");
			alert.setHeaderText(null);
			alert.setGraphic(null);
			Optional<ButtonType> result = alert.showAndWait();
			if(result.get() == ButtonType.OK){
				UserController.logoutUser(GUI_LoginController.user.getID());
				MainClient.swittchscene("AES Login",MainClient.login);
			}else
			{
				alert.close();
			}                                    
         }                
        });          
        
    }
/**
 *=General Home page method when need to alert a message                             
 *=this method performed when we call to alert a message
 *@param title the title of alert window
 *@param message he message will present in the window
 */
public void alert(String title, String message)
{
	Alert alert = new Alert(AlertType.INFORMATION);
	alert.setTitle(title);
	alert.setHeaderText(null);
	alert.setContentText(message);
	alert.showAndWait();

}
/**
 *=General Home page function when need to alert a message                              
 *=this method performed when we call to confirm somthin in system
 *@param title the title of alert window
 *@param message he message will present in the window
 *= Click OK to confirm Or cancel 
*/

public boolean confirmationAlert(String title,String message)
{
	Alert alert = new Alert(AlertType.CONFIRMATION);
	alert.setContentText(message);
	alert.setHeaderText(title);
	alert.setGraphic(null);
	Optional<ButtonType> result = alert.showAndWait();

	if (result.get() == ButtonType.OK){
		alert.close();
		return true;

	}
	else {
		alert.close();
		return false;
	}		
}
/**
 *=General Home page method that present tree view for users
 *=This method create tree option By permissions of user                           
 */
public void CreateTreeView() {	
	
	TreeItem<String> teacher = new TreeItem<>("T-Options");
	TreeItem<String> student = new TreeItem<>("S-Options");
	TreeItem<String> manager = new TreeItem<>("M-Options");
	TreeItem<String> teacherQ = new TreeItem<>("Questions");
	TreeItem<String> managerQ = new TreeItem<>("Questions");
	TreeItem<String> teacherE = new TreeItem<>("Exams");
	TreeItem<String> studentE = new TreeItem<>("Exams");
	TreeItem<String> managerC = new TreeItem<>("Courses");
	TreeItem<String> managerU = new TreeItem<>("Users");
	TreeItem<String> StatisticalInfo = new TreeItem<>("Statistical information");
	TreeItem<String> QList = new TreeItem<>("Questions List");
	TreeItem<String> EList = new TreeItem<>("Exam List");
	TreeItem<String> NewQ = new TreeItem<>("Create Question");
	TreeItem<String> NewE = new TreeItem<>("Create Exam");
	TreeItem<String> TakeExam = new TreeItem<>("Take Exam");
	TreeItem<String> VExam = new TreeItem<>("View Exam");
	TreeItem<String> ActiveExam = new TreeItem<>("Active Exams");
	TreeItem<String> FinishedExam = new TreeItem<>("Finished Exams");
	TreeItem<String> QListM = new TreeItem<>("Question");
	TreeItem<String> CListM = new TreeItem<>("Course");
	TreeItem<String> TListM = new TreeItem<>("Teacher");
	TreeItem<String> MListM = new TreeItem<>("Manager");
	TreeItem<String> SListM = new TreeItem<>("Student");
	TreeItem<String> UListM = new TreeItem<>("All Users");
	TreeItem<String> CourseStatistic = new TreeItem<>("By Courses");
	TreeItem<String> TeacherStatistic = new TreeItem<>("By Teachers");
	TreeItem<String> ManagerMessages = new TreeItem<>("Messages");
	TreeItem<String> TimeExtensionMessages = new TreeItem<>("Time Extension Requests");
	
	//Teacher options in home page
		teacher.getChildren().add(teacherQ);
		teacherQ.setExpanded(true);
		teacher.getChildren().add(teacherE);
		teacherE.setExpanded(true);
		teacherQ.getChildren().add(QList);
		teacherQ.getChildren().add(NewQ);
		teacherE.getChildren().add(EList);
		teacherE.getChildren().add(NewE);
		teacherE.getChildren().add(ActiveExam);
		teacherE.getChildren().add(FinishedExam);
		
		//Student options in home page
		student.getChildren().add(studentE);
		studentE.setExpanded(true);
		studentE.getChildren().add(TakeExam);
		studentE.getChildren().add(VExam);
		//manger options in home page
		manager.getChildren().add(managerQ);
		
		managerQ.setExpanded(true);
		managerQ.getChildren().add(QListM);
		manager.getChildren().add(managerC);
		managerC.setExpanded(true);
		managerC.getChildren().add(CListM);
		manager.getChildren().add(managerU);
		managerU.setExpanded(true);
		manager.getChildren().add(StatisticalInfo);
		StatisticalInfo.setExpanded(true);
		managerU.getChildren().add(TListM);
		managerU.getChildren().add(MListM);
		managerU.getChildren().add(SListM);
		managerU.getChildren().add(UListM);
		StatisticalInfo.getChildren().add(CourseStatistic);
		StatisticalInfo.getChildren().add(TeacherStatistic);
		manager.getChildren().add(ManagerMessages);
		ManagerMessages.setExpanded(true);
		ManagerMessages.getChildren().add(TimeExtensionMessages);
	
	//Set visible option to specific user
	switch(HomePagePermission) {
	
	case 1:
		OnlineUser =(Student) GUI_LoginController.user;
		Studentfunctions();
		Options.setRoot(student);
		Options.setShowRoot(false);
		hellomsg.setText("Hi "+((Student)GUI_LoginController.user).getFirstName()+",");
		break;
	case 2:
		OnlineUser =(Teacher) GUI_LoginController.user;
		questionList  = QuestionController.getQuestionList();
		TecherFunctions();
		Options.setRoot(teacher);
		Options.setShowRoot(false);
		hellomsg.setText("Hi "+((Teacher)GUI_LoginController.user).getFirstName()+",");
		break;
	case 3:
		OnlineUser =(SchoolManager) GUI_LoginController.user;
		Mangagerfunctions();
		Options.setRoot(manager);
		Options.setShowRoot(false);
		hellomsg.setText("Hi "+((SchoolManager)GUI_LoginController.user).getFirstName()+",");
		break;
	}	
}
/**
 *=This method take all containers and controllers in home page to Starting point
 *=before every action in home page all be invisible                           
 */
public void setAllinStartpoint() {
	
	welcome.setVisible(false);
	hellomsg.setVisible(false);
	//teacher controllers
	QuestionViewPane.setVisible(false);
	ExamPreviewPane.setVisible(false);
	messageQuestionView.setVisible(false);
	messageExamView.setVisible(false);
	messageExamCreate.setVisible(false);
	CreateQuestionPane.setVisible(false);
	ActiveExamPane.setVisible(false);
	ExamViewPane.setVisible(false);
	ExecutedExamPreviewPane.setVisible(false);
	CreateExamPane.setVisible(false);
	CourseComboBox.getItems().clear();
	CourseECComboBox.getItems().clear();
	QuestionPreview.setVisible(false);
	btn_editquestion.setVisible(false);
	btn_delete.setVisible(false);
	ReloadExamsButton.setVisible(false);
	ViewExamButton.setVisible(false);
	btn_remove.setVisible(false);
	ExecuteExamButton.setVisible(false);
	QuestionList.setVisible(false);
	ExamsList.setVisible(false);
	ViewExecutedExamButton.setDisable(true);
	LockExecutedExamButton.setDisable(true);
	//ExtendTimeButton.setDisable(true);
	FinishedExamPane.setVisible(false);
	// student
	TakeExamPane.setVisible(false);
	SubmitButton.setVisible(false);
	OpenButton.setVisible(false);
	FinishTimeLabel.setVisible(false);
	SubmitManualButton.setVisible(false);
	DownloadButton.setVisible(false);
	StudentViewExamPane.setVisible(false);
	StudentExamDetails.setVisible(false);
	StudentViewExamButton.setVisible(false);
	//manger
	ManagerquestionPane.setVisible(false);
	viewQuestionBtn.setDisable(true);
	ManagercoursesPane.setVisible(false);
	ManagerteacherPane.setVisible(false);
	teacherViewCourses.setVisible(false);
	ManagerteacherTable.setVisible(false);
	ManagerteacherCoursesPane.setVisible(false);
	showNoCoursesLable.setVisible(false);
	managersPane.setVisible(false);
	managerTable.setVisible(false);
	managerStudentsPane.setVisible(false);
	usersTable.setVisible(false);
	ManageruserPane.setVisible(false);
	QuestionPreview1.setVisible(false);
	viewExamsButton.setVisible(false);
	ManagerStudentExamsList.setVisible(false);
	viewExamsPreviewButton.setVisible(false);
	CourseStatisticalInfoPane.setVisible(false);
	messageNoExams.setVisible(false);
	TeacherStatisticalInfoPane.setVisible(false);
	messageNoExams1.setVisible(false);
	CourseBarChart.setVisible(false);
	decline.setVisible(false);
	StudentsCount.setVisible(false);
	ManagerMessagesPane.setVisible(false);	
	
}
/**
 *=General method in Home page when user click some option in the tree view 
 *=when user selected some option will present in his home page                           
 */
@FXML 
public void ClickOptions() {	

	setAllinStartpoint();
	
	String Click = Options.getSelectionModel().getSelectedItem().getValue();
		
	switch(Click)
	{	
	case "Questions List":
		QuestionViewPane.setVisible(true); 
		updateSubjectBox(SubjectComboBox);
		 break; 
	case "Create Question":
		CreateQuestionPane.setVisible(true);
		updateSubjectBox(SubjectCQComboBox); 			  
	     break;
	case "Exam List":
		ExamViewPane.setVisible(true);
	  updateSubjectBox(SubjectEComboBox);
	  break;
	case "Create Exam":
		CreateExamPane.setVisible(true);
		updateSubjectBox(SubjectECComboBox);		
		  break;
	case "Active Exams":		
		ActiveExamPane.setVisible(true);
		updateExecutedExamList();
		  break;
	case "Finished Exams":		
		FinishedExamPane.setVisible(true);
		updateFinishedExamsList();
		setFinishedExamsListener();
		break;
  	case "Take Exam":		
		TakeExamPane.setVisible(true);
		CodeTextField.setVisible(true);
		CodeTextField.clear();
		MessageActive.setVisible(true);
		ExecutionCodeLabel.setVisible(true);
		break;
  	case "View Exam":
  		StudentViewExamPane.setVisible(true);
  		UpdateStudentFinishedExamList();
  		break;
	case "Question":
		ManagerquestionPane.setVisible(true);
		displayInfoOfSubjectQuestions(null);
	    createComboBoxSubjectOBList();
		break;
	case "Course":
		ManagercoursesPane.setVisible(true);
		showCourseTable();
	   break;
	case "Teacher":
		ManagerteacherPane.setVisible(true);
		showTeachersTable();
		teacherViewCourses.setVisible(true);
	   break;
	case "Manager":
		managersPane.setVisible(true);
		showmanagersTable();
	   break;
	case "Student":
		managerStudentsPane.setVisible(true);
		showStudentsTable();
	   break;
	case "All Users":
		ManageruserPane.setVisible(true);
	    showUsersTable();
		break;
	case "By Courses":
		CourseStatisticalInfoPane.setVisible(true);
		updateStatisticCourseComboBox();
		break;	
	case "By Teachers":
		TeacherStatisticalInfoPane.setVisible(true);
		updateStatisticTeacherComboBox();
		break;	
	case "Time Extension Requests":		
		ManagerMessagesPane.setVisible(true);
		updateMessagesTable();
		  break;
		
		  default:
			  break;
}

	}
/**==================================
 *=Teacher Home page methods========== 
 *==================================
 */
/**
	 *=This method update from DB the subject that will perform in comboBox 
	 *@param Subject the comboBox that we update
	 *before update clear all item in comboBox                         
	 */
	public void updateSubjectBox(ComboBox<Subject> Subject) {
		
		if(Subject.getItems() == null)
			return;
		Subject.getItems().clear();
		Subject.getItems().addAll(((Teacher)OnlineUser).getSubjects());
		Subject.setPromptText("Subject");
	}
	//Questions functions
	/**
	 *=This method delete question from DB when user click delete button
	 *@param event catch all events of button
	 *before delete question ask for confirmation                         
	 */
	@FXML
	public void ClickDeleteQuestion(ActionEvent event) {
		
		Question question = QuestionList.getSelectionModel().getSelectedItem();
		boolean answer =confirmationAlert("Remove Question","Are you sure you want to remove this question?");
		if(answer)
		{
			if(!(question.getAuthor().getID().equals(GUI_LoginController.user.getID())))
			{
				alert("Remove Question", "You do not have permission to remove questions' which were not composed by you");	
				return;
			}
			QuestionController.DeleteQuestion(question.getID());
			updateQuestionListBySubject(SubjectComboBox.getSelectionModel().getSelectedItem().getID());
			QuestionPreview.setVisible(false);
			btn_delete.setVisible(false);
			btn_editquestion.setVisible(false);
			alert("Remove Exam","Exam has been removed from the database");
		}
	}
	/**
	 *=This method show selected question from list details in home page
	 *@param Questionselected To preview the selected question, get is details               
	 */
	public void QuestionPreview(TextArea preview ,Question Questionselected) {
		
		Platform.runLater(new Runnable() {
			@Override
			public void run() {
				preview.setText("Question details:\n\n ID: "+Questionselected.getID()+"\n Author: "+Questionselected.getAuthor().getName()+"\n\nQuestion: " + Questionselected.getQuestion()+"\n\nAnswer: "+Questionselected.getCorrectAnswer());
				preview.setVisible(true);
			}
		});
	}
	 	//when user select items from combobox in View question
	/**
	 *=This method update question list of subject by selected comboBox value                   
	 */
	public void SubjectComboBoxAction() {
		
		QuestionPreview.setVisible(false);
		
		if(SubjectComboBox.getValue()==null)
			return;
		updateQuestionListBySubject(SubjectComboBox.getValue().getID());
		
		
	}
		//when user select items from combobox in create question
	/**
	 *=This method Opens a window to create a test according to a chosen subject                 
	 */
	public void SubjectCQComboBoxAction() {
				
				CreateQuestionController.subject = SubjectCQComboBox.getValue();
				QuestionCreateWindow = new Stage();
				QuestionCreateWindow.setTitle("Create question");
				QuestionCreateWindow.initModality(Modality.APPLICATION_MODAL);
		    	Parent root;
				try {
					FXMLLoader loader = new FXMLLoader();
					root = loader.load(getClass().getResource("QuestionCreateGUI.fxml").openStream());
					Scene scene = new Scene(root);
					QuestionCreateWindow.setScene(scene);
					QuestionCreateWindow.showAndWait();
					
					
				} catch (IOException e) {			
					e.printStackTrace();
				}
			
		}
		//when user wants to see question details
	/**
	 *This method Opens a Question Editing window according to the selected question                 
	 */
	@FXML 
	public void ClickQuestionEdit(ActionEvent event) {	
		
			QuestionViewWindow = new Stage();
			QuestionViewWindow.setTitle("Question View");
			QuestionViewWindow.initModality(Modality.APPLICATION_MODAL);
	    	Parent root;
			try {	
				QuestionViewGUIController.question = QuestionList.getSelectionModel().getSelectedItem();
				if(QuestionViewGUIController.question!=null) {
				root = FXMLLoader.load(getClass().getResource("QuesionViewDetails.fxml"));
				Scene scene = new Scene(root);
				QuestionViewWindow.setScene(scene);
				QuestionViewWindow.initOwner(SubjectComboBox.getScene().getWindow());
				QuestionViewWindow.showAndWait();
				updateQuestionListBySubject(SubjectComboBox.getValue().getID());
				}
				else
				{
					alert("Question view","You need to select question");
				}
			} catch (IOException e) {			
				e.printStackTrace();
			}
	    }
		//when user select items from combobox in view question the list of questions will be update
	/**
	 *=This method update question list of subject by selected subject id
	 *@param  Sid The selected subject id  
	 **before update clear all question from list                
	 */
	public void updateQuestionListBySubject(String Sid) {
		
		
		QuestionPreview.setVisible(false);
		QuestionList.getItems().clear();
		questionList = QuestionController.getQuestionListBySubject(Sid);
		
		if(!questionList.isEmpty()) {
			QuestionList.getItems().addAll(questionList);
			messageQuestionView.setVisible(false);
			QuestionList.setVisible(true);
			}else {
				QuestionList.setVisible(false);
				messageQuestionView.setVisible(true);
			}
				
		
	}
	/**
	 *=This method update exam list of exams by selected subject id
	 *@param  subjectID The selected subject id 
	 *before update clear all exam from list                
	 */
	//Exam
		//when user select items from combobox view exam the list of exams will be update
	public void updateExamListBySubject(String subjectID) {
				ExamPreviewPane.setVisible(false);
				
				ExamsList.getItems().clear();
				examsList = ExamController.getExamsListBySubject(subjectID);
				if(!examsList.isEmpty()) {
				ExamsList.getItems().addAll(examsList);
				ExamsList.setVisible(true);
				ReloadExamsButton.setVisible(true);
				}else {
					messageExamView.setText("No exams to view in this subject");
					messageExamView.setVisible(true);
					ExamsList.setVisible(false);
					ReloadExamsButton.setVisible(false);
				}
			}
		//when user select exam will showing him privew of exam
	/**
	 *=This method show selected exam present details in home page
	 *@param exam To preview the selected exam, get is details               
	 */
	public void showExamPreview(Exam exam) {
			ExamPreviewPane.setVisible(true);
			CourseNameLabel.setText(exam.getCourse().getName());
			DateLabel.setText(exam.getCreationDate());
			AuthorLabel.setText("" + exam.getAuthor().getName());
			FreeTextLabel.setText(exam.getNote());
			ExamTimeLabel.setText("Exam time: " + exam.getExamTime());
		}
		//when user select items from combobox in create exam 
	/**
	 *In View Exam pane
	 *=This method Show list of exam by selected subject id
	 * The method update course comboBox by the courses in this subject            
	 */
	public void subjectSelectionListner() {
				ExamPreviewPane.setVisible(false);
				messageExamView.setVisible(false);
			if(SubjectEComboBox.getValue()==null) 
			return;
				updateCoursesBox(SubjectEComboBox.getValue().getID());
				updateExamListBySubject(SubjectEComboBox.getValue().getID());
				
				
			
		}
	/**
	 *=This method update exam list of exams by selected course id
	 *@param  courseID The selected course id 
	 *before update clear all exam from list                
	 */
	public void updateExamListByCourse(String courseID) {
			ExamPreviewPane.setVisible(false);
			messageExamView.setVisible(false);
			ExamsList.getItems().clear();
			for (Exam exam : examsList) {
				if (exam.getCourse().getID().equals(courseID))
					ExamsList.getItems().add(exam);
	
			}
			if(!ExamsList.getItems().isEmpty()) {
				ExamsList.setVisible(true);
				ReloadExamsButton.setVisible(true);
			}else {
				ExamsList.setVisible(false);
				ReloadExamsButton.setVisible(false);
				messageExamView.setText("No exams to view in this course");
				messageExamView.setVisible(true);
			}
			
		}
	/**
	 * *in View exam pane
	 *=This method Show list of exam by selected course id            
	 */
	public void courseSelectionListner() {
			ExamPreviewPane.setVisible(false);
			
			if(CourseComboBox.getValue() == null)
				return;
			if(examsList.isEmpty()) return;
			else {
				updateExamListByCourse(CourseComboBox.getValue().getID());
				
			}
			
		}
	/**
	 *=This method update from DB the courses that will perform in comboBox by subject id
	 *@param subjectID the subject id of this courses
	 *before update clear all item in comboBox                         
	 */
	public void updateCoursesBox(String subjectID) {
		ExamPreviewPane.setVisible(false);
		if(CourseComboBox.getItems() == null)
			return;
		else {
		CourseComboBox.getItems().clear();
		CourseComboBox.getItems().addAll(((Teacher)GUI_LoginController.user).getCoursesOfSubject(subjectID));
		CourseComboBox.setPromptText("Course");	}
	}
	/**
	 *This method update exam list               
	 */
	@FXML
	public void reloadExecutedClickedListener(ActionEvent event) {
		
		updateExecutedExamList();	

	}
	@FXML
	public void reloadFinishedExamsButtonListener() {
		updateFinishedExamsList();
	}
	@FXML 
	public void reloadClickedListener(ActionEvent event) {
			ExamPreviewPane.setVisible(false);
			if (SubjectEComboBox.getValue() != null) {
				updateExamListBySubject(SubjectEComboBox.getValue().getID());
				if (CourseComboBox.getValue() != null)
					updateExamListByCourse(CourseComboBox.getValue().getID());
			} else
				ExamsList.getItems().clear();
	
	}
	/**
	 *=This method in View exam pane performed when user click to view exam
	 *=This method Opens a Question View window according to the selected exam                             
	 */
	@FXML 
	public void ClickViewExam(ActionEvent event) {
		
		if(ExamsList.getSelectionModel().getSelectedItem()== null)
		{
			alert("View Exam","You need to select an exam before you can view one");	
			return;		}
					
		ViewExamWindow = new Stage();
		ViewExamWindow.setTitle("View Exam");
		
		try {
			
			FXMLLoader loader = new FXMLLoader();
			Parent root1 = loader.load(getClass().getResource("ViewExamGUI.fxml").openStream());			
			ViewExamGUIController controller = loader.getController();
			controller.setQuestionsInExam(ExamsList.getSelectionModel().getSelectedItem().getQuestions());
			controller.setExam(ExamsList.getSelectionModel().getSelectedItem());			
			ViewExamWindow.setScene(new Scene(root1));
			ViewExamWindow.initModality(Modality.APPLICATION_MODAL);
			ViewExamWindow.initOwner(SubjectEComboBox.getScene().getWindow());
			ViewExamWindow.showAndWait();		
			
			
		} catch (IOException e) {			
			e.printStackTrace();
		}	
	}
	/**
	 *=This method in View exam pane performed when user click to remove exam
	 *=This method remove from repository the exam 
	 *before remove open confirmation window
	 *If the current teacher did not write the question he could not delete it                          
	 */
	@FXML
	public void ClickRemoveExam(ActionEvent event) {
		Exam exam = ExamsList.getSelectionModel().getSelectedItem();
		boolean answer =confirmationAlert("Remove Exam","Are you sure you want to remove the selected exam from the database?");
		if(answer)
		{
			if(!(exam.getAuthor().getID().equals(GUI_LoginController.user.getID())))
			{
				alert("Remove Exam", "You do not have permission to remove exams' which were not composed by you");	
				return;
			}
			ExamController.removeExam(exam.getID());
			reloadClickedListener(event);
			ExamPreviewPane.setVisible(false);
			//btn_remove.setDisable(true);
			//ViewExamButton.setDisable(true);
			alert("Remove Exam","Exam has been removed from the database");
		}
	}
	/**
	 * In Create Exam pane
	 *=This method Show list of exam by selected subject id
	 * The method update course comboBox by the courses in this subject            
	 */
	public void subjectSelectionListener() {
		if(SubjectECComboBox.getValue()==null) {
			return;			
		}else {
		ConfirmButton.setDisable(true);
		Subject subject = SubjectECComboBox.getSelectionModel().getSelectedItem();
		ArrayList<Question> tempQuetionList = QuestionController.getQuestionListBySubject(subject.getID());
		if(tempQuetionList.isEmpty()) {
			CourseECComboBox.setDisable(true);
			ConfirmButton.setDisable(true);
			messageExamCreate.setText("No questions in this subject \n You can not create new exam in " + subject.getName());
			messageExamCreate.setVisible(true);
		}
		else {
			messageExamCreate.setVisible(false);
			CourseECComboBox.setDisable(false);
		updateCreateCoursesBox(SubjectECComboBox.getValue().getID());
		}
		}
	}
	/**
	 *in create exam pane
	 *=This method disable confirmation button             
	 */
	public void courseSelectionListener() {
		
		messageExamCreate.setVisible(false);
		ConfirmButton.setDisable(false);
	}
	/**
	 *=This method Opens a Exam Creating window according to the selected subject an course id by click submit after choose subject an course
	 *create new exam by the subject,course and author that want to create new exam                
	 */
	@FXML
	public void confirmButtonListener(ActionEvent event) {
		ExamCreateWindow = (Stage) ConfirmButton.getScene().getWindow();
		ExamCreateWindow.setTitle("Create exam");
		
		try {
			ExamCreateWindow = new Stage();
			ExamCreateWindow.setTitle("Create and submit exam");
			Course course = CourseECComboBox.getSelectionModel().getSelectedItem();
			Subject subject = SubjectECComboBox.getSelectionModel().getSelectedItem();
			Date date = new Date();  
		    SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");  
		    String strDate= formatter.format(date);  
		    FXMLLoader loader = new FXMLLoader(); 
		    Parent root = loader.load(getClass().getResource("CreateExam.fxml").openStream());			
			CreateExamsController  controller = loader.getController();
			Exam exam = new Exam(subject.getID()+course.getID(),course,subject,new Person(((Teacher)OnlineUser).getID(),((Teacher)OnlineUser).getName()),strDate,0);
			controller.setExam(exam);
			controller.updateQuestionsList();
			Scene scene = new Scene(root);
			ExamCreateWindow.setScene(scene);
			ExamCreateWindow.initModality(Modality.APPLICATION_MODAL);
			ExamCreateWindow.initOwner(SubjectECComboBox.getScene().getWindow());
			ExamCreateWindow.showAndWait();
			
			
			Rectangle2D primScreenBounds = Screen.getPrimary().getVisualBounds();
			ExamCreateWindow.setX((primScreenBounds.getWidth() - ExamCreateWindow.getWidth()) / 2);
			ExamCreateWindow.setY((primScreenBounds.getHeight() - ExamCreateWindow.getHeight()) / 2);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	  
	
	}
	/**
	 *=This method update course comboBox  of courses by selected subject id
	 *@param subjectID The selected subject id
	 */
	public void updateCreateCoursesBox(String subjectID) {
		if(CourseComboBox.getItems() == null) {
			return;
		}else {
		CourseECComboBox.getItems().clear();	
		CourseECComboBox.getItems().addAll(((Teacher)OnlineUser).getCoursesOfSubject(subjectID));
		CourseECComboBox.setPromptText("Course");}
	}
	/**
	 *=This method present window to insert code execution an activate selected exam
	 *Ask for 4 charters of code activate 
	 * add exam to active exam list                
	 */
	public void executeButtonListener() {							
	
		TextInputDialog dialog = new TextInputDialog();		
		dialog.setTitle("Exam Execution");			
		dialog.setContentText("Enter 4 characters execution code: ");
		dialog.setHeaderText(null);
		Optional<String> result = dialog.showAndWait();
		if(result.isPresent())				
			if(result.get().length() == 4)				
				if(ExamController.executeExam(result.get(), ExamsList.getSelectionModel().getSelectedItem(), ((Teacher)GUI_LoginController.user).getID() )) {
					dialog.close();
					alert("Exam Execution","Exam was successfully executed!");
				}
				else
					alert("Exam Execution","Code already in use.");
			else
				alert("Exam Execution", "You need to enter 4 characters code");
	}
	/**
	 *=This method open active exam  by selected exam from Executed Exams List           
	 */
	public void viewExecutedExamListener()
	{
		if(ExecutedExamsList.getSelectionModel().getSelectedItem()== null)
		{
			alert("View Exam", "You need to select an exam before you can view one");	
			return;
		}
	
		Stage stage = new Stage();
		stage.setTitle("View Exam");		
		try {
			FXMLLoader loader = new FXMLLoader();
			Parent root = loader.load(getClass().getResource("ViewExamGUI.fxml").openStream());			
			ViewExamGUIController controller = loader.getController();
			controller.setQuestionsInExam(ExecutedExamsList.getSelectionModel().getSelectedItem().getQuestions());
			controller.setExam(ExecutedExamsList.getSelectionModel().getSelectedItem());	
			stage.setScene(new Scene(root));
			stage.initModality(Modality.APPLICATION_MODAL);
			stage.initOwner(ExecutedExamsList.getScene().getWindow());
			stage.showAndWait();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	/**
	 *=This method lock active exam by his code
	 *@param code The active exam code
	 *update list of active exam           
	 */
	public void lockExam(String code) {
		ExamController.lockExam(code);
		ExecutedExamPreviewPane.setVisible(false);
		updateExecutedExamList();
	}
	/**
	 *=This method Send the selected activate exam code to lockExam method when client press lock exam          
	 */
	public void lockExamButtonListener() {
		lockExam(executedExamsList.get(ExecutedExamsList.getSelectionModel().getSelectedItem()));
	}
	
	public void extendTimeButtonLisenter()
	{
		FXMLLoader loader = new FXMLLoader();
		try {
			Stage extendTimeStage = new Stage();
			extendTimeStage.setTitle("Extend Time");
			Pane pane = loader.load(getClass().getResource("TimeExtensionPane.fxml").openStream());
			TimeExtensionPaneController controller = loader.getController();
			Exam exam = ExecutedExamsList.getSelectionModel().getSelectedItem();
			controller.setExamID(executedExamsList.get(exam));
			Scene scene = new Scene(pane);
			extendTimeStage.setScene(scene);
			extendTimeStage.initModality(Modality.APPLICATION_MODAL);
			extendTimeStage.showAndWait();			
			
		} catch (IOException e) {
			
			e.printStackTrace();
		}
		
	}
	/**
	 *=This method update exam active list of exams that this specific teacher executed 
	 *before update clear all exam from list                
	 */
	public void updateExecutedExamList() {
		
		ExecutedExamsList.getItems().clear();
		executedExamsList = ExamController.getActiveExams(GUI_LoginController.user.getID());
		ExecutedExamsList.getItems().addAll(executedExamsList.keySet());
		ExecutedExamPreviewPane.setVisible(false);
		LockExecutedExamButton.setDisable(true);
		ViewExecutedExamButton.setDisable(true);
		ExtendTimeButton.setDisable(true);
	}
	/**
	 *=This method show selected active exam present details in home page
	 *@param exam To preview the selected exam, get is details               
	 */
	public void showExecutedExamPreview(Exam exam) {
		ExecutedExamPreviewPane.setVisible(true);
		ExecutedCourseNameLabel.setText(exam.getCourse().getName());
		ExecutedDateLabel.setText(exam.getCreationDate());
		ExecutedAuthorLabel.setText("" + exam.getAuthor().getName());
		ExecutedExamTimeLabel.setText("Exam time: " + exam.getExamTime());
		ExecutedFreeTextLabel.setText(exam.getNote());
	}
	public void updateFinishedExamsList() {
		FinishedExamsList.getItems().clear();
		StudentExamsList.getItems().clear();
		CheatingGroupList.getItems().clear();
		finishedExamsList = ExamController.getFinishedExamsById(GUI_LoginController.user.getID());
		System.out.println(finishedExamsList);
		if(finishedExamsList == null)
			return;		
		FinishedExamsList.getItems().setAll(finishedExamsList.keySet());	
		FinishedExamsList.getItems().sort(null);
		checkCheating();
	}
	public void updateSubmittedExamsList(ExecutedExam exam) {
		StudentExamsList.getItems().clear();
		StudentExamsList.getItems().setAll(finishedExamsList.get(exam));
		StudentExamsList.getItems().sort(null);

	}
	public void setFinishedExamsListener()
	{
		FinishedExamsList.getSelectionModel().selectedItemProperty().addListener(e -> {			
			ExecutedExam exam = FinishedExamsList.getSelectionModel().getSelectedItem();
			

			if (exam != null)
			{
				updateSubmittedExamsList(exam);
				ReviewFinishedExamButton.setDisable(true);
				setCheatingGroupList();
				StudentExamsList.getSelectionModel().selectedItemProperty().addListener(e1 -> {
					ReviewFinishedExamButton.setDisable(false);
				});
			}
			setStudentExamsListFactory();

			

		});
	}
	public void checkCheating()
	{
		for(ExecutedExam exam : finishedExamsList.keySet()) {
			int groupNumber =1;
			FinishedExam[] list = new FinishedExam[finishedExamsList.get(exam).size()];
			finishedExamsList.get(exam).toArray(list);
			for(int i = 0 ; i < list.length-1 ; i++) {
				for(int j = i+1 ; j < list.length; j++){
					if(list[i].getAnswers().equals(list[j].getAnswers())&&list[i].getGrade()<100) {
						if(list[i].getCheatingGroupNumber()==-1)
							list[i].setCheatingGroupNumber(groupNumber++);
					list[j].setCheatingGroupNumber(list[i].getCheatingGroupNumber());}
				}	
			}
		}

	}

	public void setCheatingGroupList()
	{		
		CheatingGroupList.getItems().clear();
		int maxNumber = findMaxGroupNumber(StudentExamsList.getItems());		
		if(maxNumber == -1)
			return ;

		for(int i=1 ; i<=maxNumber; i++) 		
			(CheatingGroupList).getItems().add(i);

	}

	public int findMaxGroupNumber(ObservableList<FinishedExam> examsList)
	{
		int maxNumber = -1;
		for(FinishedExam exam : examsList)
			maxNumber = exam.getCheatingGroupNumber()>maxNumber?exam.getCheatingGroupNumber():maxNumber;

			return maxNumber;	
	}
	public void reviewButtonListener()
	{
		Stage examReviewStage = new Stage();
		examReviewStage.setTitle("Exam Review Page");
		Parent root;
		try {
			FXMLLoader loader = new FXMLLoader();
			root = loader.load(getClass().getResource("FinishedExamGUI.fxml").openStream());
			FinishedExamGUIController controller = loader.getController();			
			controller.setExam(StudentExamsList.getSelectionModel().getSelectedItem());
			controller.setManageExamsController(this);
			examReviewStage.setOnCloseRequest(e -> {
				e.consume();
				if(confirmationAlert("", "Are you sure you want to exit? all unsaved information will be lost."))
					examReviewStage.close();
				
			});
			Scene scene = new Scene(root);
			examReviewStage.setScene(scene);			
			examReviewStage.initModality(Modality.APPLICATION_MODAL);
			examReviewStage.initOwner(ReviewFinishedExamButton.getScene().getWindow());

			examReviewStage.showAndWait();

		} catch (IOException e) {

			e.printStackTrace();
		}

	}
	public void setStudentExamsListFactory()
	{
		
		StudentExamsList.setCellFactory(new Callback<ListView<FinishedExam>, ListCell<FinishedExam>>() {
			@Override
			public ListCell<FinishedExam> call(ListView<FinishedExam> param) {					
				return new ListCell<FinishedExam>() {
					@Override
					
					protected void updateItem(FinishedExam item, boolean empty) {
						super.updateItem(item, empty);
						
						if (item != null) {								
							if(CheatingGroupList.getSelectionModel().getSelectedItem() !=null && item.getCheatingGroupNumber() == CheatingGroupList.getSelectionModel().getSelectedItem() ) {									
								setStyle("-fx-background-color: red");
								
							}
							String str = finishedExamConverter(item);
							if(item.getFinalGrade()==-1)
								setText("New!!  "+str);
							else
								setText(str);
						}
						else
							setText(null);
					}
				};
			}
		});
	}
	public String finishedExamConverter(FinishedExam exam)
	{
		return "Student: "+exam.getExaminee().getName()+" "+exam.getExaminee().getID();
	}
	/**
	 *=When teacher is login all this set converters an action of controller that uses by teacher will be update.               
	 */
	public void TecherFunctions() {
	//ComboBox of view question
	SubjectComboBox.setConverter(new StringConverter<Subject>() {
		public String toString(Subject subject) {
			return subject.getName();
		}

		@Override
		public Subject fromString(String arg0) {
			return null;
		}

	});
	//ComboBox of view exam
	SubjectEComboBox.setConverter(new StringConverter<Subject>() {
		public String toString(Subject subject) {
			return subject.getName();
		}

		@Override
		public Subject fromString(String arg0) {
			return null;
		}

	});
	//ComboBox of create question
	SubjectCQComboBox.setConverter(new StringConverter<Subject>() {			

		@Override
		public String toString(Subject subject) {
			
			return subject.getName();
		}

		@Override
		public Subject fromString(String string) {
			// TODO Auto-generated method stub
			return null;
		}
	});
	//ComboBox of create exam
	SubjectECComboBox.setConverter(new StringConverter<Subject>() {
		public String toString(Subject subject) {
			return subject.getName();
		}

		@Override
		public Subject fromString(String arg0) {
			return null;
		}

	});

	//ComboBox of create question
	CourseComboBox.setConverter(new StringConverter<Course>() {

		public String toString(Course course) {
			return course.getName();
		}

		@Override
		public Course fromString(String arg0) {
			return null;
		}

	});
	//ComboBox of create exam
	CourseECComboBox.setConverter(new StringConverter<Course>() {

		public String toString(Course course) {
			return course.getName();
		}

		@Override
		public Course fromString(String arg0) {
			return null;
		}

	});
	// Converter exam list
	ExamsList.setCellFactory(lv -> {
		TextFieldListCell<Exam> cell = new TextFieldListCell<Exam>();
		cell.setConverter(new StringConverter<Exam>() {
			@Override
			public String toString(Exam exam) {
				return exam.getCreationDate() + "      Course: " + exam.getCourse().getName() + "      Author: "
						+ exam.getAuthor().getName();
			}

			@Override
			public Exam fromString(String string) {
				return null;
			}
		});
		return cell;
	});
	// add listener to  question list
	QuestionList.getSelectionModel().selectedItemProperty().addListener(e -> {
		btn_editquestion.setVisible(true);
		btn_delete.setVisible(true);
		Question selectedQuestion = QuestionList.getSelectionModel().getSelectedItem();
		if(selectedQuestion!=null) {
			QuestionPreview(QuestionPreview,selectedQuestion);
			}
		else {
			btn_delete.setVisible(false);
			btn_editquestion.setVisible(false);
		}
		});
	// Converter question list
	QuestionList.setCellFactory(lv -> {
		TextFieldListCell<Question> cell = new TextFieldListCell<Question>();
		cell.setConverter(new StringConverter<Question>() {
			@Override
			public String toString(Question question) {
				return question.getQuestion();
			}

			@Override
			public Question fromString(String string) {
				return null;
			}
		});
		return cell;
	});
	// add listener to  exam list
	ExamsList.getSelectionModel().selectedItemProperty().addListener(e -> {
			Exam exam = ExamsList.getSelectionModel().getSelectedItem();
			if (exam != null)
				showExamPreview(exam);
			ViewExamButton.setVisible(true);
			ExecuteExamButton.setVisible(true);
			btn_remove.setVisible(true);
		
	});
	// Converter exam list
	ExamsList.setCellFactory(lv -> {
		TextFieldListCell<Exam> cell = new TextFieldListCell<Exam>();
		cell.setConverter(new StringConverter<Exam>() {
			@Override
			public String toString(Exam exam) {
				return "ID:"+exam.getID()+", subject:"+exam.getSubject().getName()+", course:"+exam.getCourse().getName();
			}

			@Override
			public Exam fromString(String string) {
				return null;
			}
		});
		return cell;
	});
	// Converter active exam list
	ExecutedExamsList.setCellFactory(lv -> {
		TextFieldListCell<Exam> cell = new TextFieldListCell<Exam>();
		cell.setConverter(new StringConverter<Exam>() {
			@Override
			public String toString(Exam exam) {
				return "Code: "+executedExamsList.get(exam) + "      Course: " + exam.getCourse().getName() + "      Author: "
						+ exam.getAuthor().getName();
			}

			@Override
			public Exam fromString(String string) {
				return null;
			}
		});
		return cell;
	});
	// add listener to active exam list
	ExecutedExamsList.getSelectionModel().selectedItemProperty().addListener(e -> {
		Exam exam = ExecutedExamsList.getSelectionModel().getSelectedItem();			
		if (exam != null)
		{
			showExecutedExamPreview(exam);			    
			LockExecutedExamButton.setDisable(false);			    
			ViewExecutedExamButton.setDisable(false);
			ExtendTimeButton.setDisable(false);
			
		}
		else {
			LockExecutedExamButton.setDisable(true);			    
			ViewExecutedExamButton.setDisable(true);
			ExtendTimeButton.setDefaultButton(true);
		}
	});
	FinishedExamsList.setCellFactory(lv -> {
		TextFieldListCell<ExecutedExam> cell = new TextFieldListCell<ExecutedExam>();
		cell.setConverter(new StringConverter<ExecutedExam>() {
			@Override
			public String toString(ExecutedExam exam) {
				String dateStr = new SimpleDateFormat("dd/MM/yyyy").format(exam.getExecutionDate());
				return exam.getId()+" "+exam.getSubject().getName()+" "+dateStr;
			}

			@Override
			public ExecutedExam fromString(String string) {
				return null;
			}
		});
		return cell;
	});
	CheatingGroupList.getSelectionModel().selectedItemProperty().addListener(e -> {
		StudentExamsList.getSelectionModel().clearSelection();
		ReviewFinishedExamButton.setDisable(true);
		setStudentExamsListFactory();
	});
	
}
/**==================================
 *=Student Home page methods========== 
 *==================================
 */	
	/**
	*this method enable submit button after take exam
	*/	
	public void enableSubmitButton()
	{
		SubmitButton.setDisable(false);
	}
	/**
	*this method disable submit button before take exam
	*/	
	public void disableSubmit()
	{
		SubmitButton.setDisable(true);
	}
	/**
	*This method call exam controller to submit exam 
	*/	
	public void submitExam() {
		examGuiController.submitExam("ByUser","Success");

	}
	/**
	*This method Open exam GUI when user press open button
	*Will only be possible once they have entered the exam once
	*/	
	public void openButtonListener()
	{
		if(examWindowScene!=null)
		{
			Stage stage = new Stage();
			stage.setTitle("Exam");	
			stage.setScene(examWindowScene);
			stage.initModality(Modality.APPLICATION_MODAL);
			stage.initOwner(TakeExamPane.getScene().getWindow());
			stage.showAndWait();
		}
	}
	/**
	*This method After entering a test 4 characters code, identifies the appropriate test and activates accordingly
	*Open options window to choose exam type : Online , manual or cancel
	* Online : open exam window for student 
	* manual : create word file to save in computer
	* Cancel: exit this window
	*/
	public void codeTextFieldListener() {
		examExecutionCode = CodeTextField.getText();
		if(examExecutionCode.length()!=4) {
			ErrorLabel.setVisible(true);
			ErrorLabel.setText("Code length should be 4 characters");
			return;
		}
		String result = ExamController.checkExamCode(examExecutionCode,GUI_LoginController.user.getID());	
		switch(result) {
		case "Success":	
			Alert alert = new Alert(AlertType.CONFIRMATION);			
			
			CodeTextField.setVisible(false);
			ExecutionCodeLabel.setVisible(false);
			MessageActive.setVisible(false);
			ErrorLabel.setVisible(false);
			
			alert.setTitle("Choose exam type");
			alert.setHeaderText(null);
			
			alert.setContentText("Choose online to fill the exam online or manual to download a pdf for submission");
			ButtonType buttonTypeOnline = new ButtonType("Online");
			ButtonType buttonTypeManual = new ButtonType("Manual");
			ButtonType buttonTypeCancel = new ButtonType("Cancel");
			alert.getButtonTypes().setAll(buttonTypeOnline, buttonTypeManual, buttonTypeCancel);
			Optional<ButtonType> result2 = alert.showAndWait();
			if (result2.get() == buttonTypeOnline){
				setOnlineScene();
				
				Exam exam = ExamController.takeExam(examExecutionCode);									
				Stage stage = new Stage();
				stage.setTitle("Exam");		
				try {
					FXMLLoader loader = new FXMLLoader();
					Parent root = loader.load(getClass().getResource("ExamGUI.fxml").openStream());			
					examGuiController = loader.getController();						 							
					examGuiController.setExamCode(examExecutionCode);
					examGuiController.setExam(exam);	
					examGuiController.setTakeExamPageController(this);
					examWindowScene = new Scene(root);
					stage.setScene(examWindowScene);
					stage.initModality(Modality.APPLICATION_MODAL);
					stage.initOwner(SubmitManualButton.getScene().getWindow());
					stage.showAndWait();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}					
			} else if (result2.get() == buttonTypeManual) {
				setManualScene();				
				
			} else
			{
				alert.hide();
				TakeExamPane.setVisible(true);
				CodeTextField.setVisible(true);
				CodeTextField.clear();
				MessageActive.setVisible(true);
				ExecutionCodeLabel.setVisible(true);
			}
			break;
		case "ExamCodeDoesntExist":
			ErrorLabel.setVisible(true);
			ErrorLabel.setText("Exam code does not exist");
			break;
		case "TookExamAlready":
			ErrorLabel.setVisible(true);
			ErrorLabel.setText("Exam already submitted or time is up");
			break;
		}
	}
	public void setOnlineScene()
	{
		SubmitButton.setVisible(true);
		SubmitButton.setDisable(true);
		OpenButton.setVisible(true);
		FinishTimeLabel.setVisible(true);
	}
	public void setManualScene()
	{
		DownloadButton.setVisible(true);
		SubmitManualButton.setVisible(true);
		downloadButtonListener();
		
	}
	/**
	*This method Set in finish exam the time student need to end time and show him the time
	*@param finishTime The time to finish exam
	* Online : open exam window for student 
	*/
	public void setExamFinishTime(Date finishTime)
	{
		Platform.runLater(new Runnable() {

			@Override
			public void run() {
				SimpleDateFormat formatter = new SimpleDateFormat("HH:mm");
				manualExamFinishTime = finishTime;
				String time = formatter.format(finishTime);			
				FinishTimeLabel.setText("Finish Time: "+time);
				
			}
			
		});
		
	}
	public void closeWindow()
	{
		SubmitButton.getScene().getWindow().hide();		
	}
	public void downloadButtonListener() {
		FileChooser fileChooser = new FileChooser();
		fileChooser.setTitle("Save Exam");
		fileChooser.setInitialFileName(GUI_LoginController.user.getID()+".docx");
		File file = fileChooser.showSaveDialog(SubmitButton.getScene().getWindow());
		if(file == null)
			return;
		ArrayList<Object> data = ExamController.takeManualExam((Student)GUI_LoginController.user, examExecutionCode);
		
		String answer = (String) data.get(0);
		if(answer.equals("ExamIsNotActive"))
		{	alert("Error","The exam is not active anymore");
			closeWindow();
			return;
		}		
		try {			
			ArrayList dataAnswer = (ArrayList) data.get(1);
			examinee = (Examinee) dataAnswer.get(1);
			manualExam = (ManualExamFile)dataAnswer.get(2);			
			setExamFinishTime(examinee.getFinishTime());
			FileOutputStream fos = new FileOutputStream(file);
			BufferedOutputStream bos = new BufferedOutputStream(fos);
			bos.write(manualExam.getMybytearray());
			bos.close();
			new Thread(new Runnable() {
				
				public void run() {

					while(true){
						ArrayList<Object> data = ExamController.waitForCommand();
						String command = (String) data.get(0);						
						switch(command)
						{
						case "LockExam":		
							ExamController.submitExam(null, examinee, command);	
							alert("Exam Lock","The exam has been locked");
							SubmitButton.getScene().getWindow().hide();
							return;			
						case "Timeout":
							ExamController.submitExam(null, examinee, command);	
							Platform.runLater(new Runnable()
							{

								@Override
								public void run() {
									alert("Time Out","The exam time has ran out");
									SubmitButton.getScene().getWindow().hide();								
								}
							});
							return;
						case "TimeExtension":
							setExamFinishTime(new Date(manualExamFinishTime.getTime() + (Integer)data.get(1)*60000));
							break;
						case "Submitted":
							return;
						}					
					}
				}			
			}).start();			
		} catch (Exception e) {			
			e.printStackTrace();
		}

	}
	public void submitManualExam() {
		FileChooser fileChooser = new FileChooser();
		fileChooser.setTitle("Send Exam");	
		File file = fileChooser.showOpenDialog(SubmitButton.getScene().getWindow());	
		if(file!=null)
		{
			byte [] mybytearray  = new byte [(int) file.length()];
			FileInputStream fis;
			try {
				fis = new FileInputStream(file);
				BufferedInputStream bis = new BufferedInputStream(fis);	  		
				manualExam.initArray(mybytearray.length);			  
				bis.read(manualExam.getMybytearray(), 0, mybytearray.length);
				ExamController.submitManualExam(manualExam, examinee, "ByUser");
				alert("ByUser","Success");
				closeWindow();

			} catch (Exception e) {		
				e.printStackTrace();
			}	
		}
	}
	//view exam student
	public void UpdateStudentFinishedExamList() {
		StudentExamViewList.getItems().clear();
		studentiewlist = ExamController.getFinishedStudentExams(GUI_LoginController.user.getID());
		if(studentiewlist!=null) {
			for(FinishedExam exam : studentiewlist) {
				if(exam.getFinalGrade() != -1) {
					StudentExamViewList.getItems().add(exam);
				}
			}
		}
	}
	public void Studentfunctions() {		
	
		StudentExamViewList.setCellFactory(lv -> {
			TextFieldListCell<FinishedExam> cell = new TextFieldListCell<FinishedExam>();
			cell.setConverter(new StringConverter<FinishedExam>() {
				@Override
				public String toString(FinishedExam exam) {
						return "ID: "+exam.getID()+" Subject: "+exam.getSubject().getName()+" Course: "+exam.getCourse().getName();			
					
				}

				@Override
				public FinishedExam fromString(String string) {
					return null;
				}
			});
			return cell;
		});
		
		StudentExamViewList.getSelectionModel().selectedItemProperty().addListener(e->{
			FinishedExam exam = StudentExamViewList.getSelectionModel().getSelectedItem();
			StudentExamDetails.setText("Exam details:\n\n ID: "+exam.getID()+"\n Time: "+exam.getExamTime()+"\n Type: "+exam.getSubmissionType()+"\n Grade: "+exam.getFinalGrade());
			StudentExamDetails.setVisible(true);
			StudentViewExamButton.setVisible(true);
		});
	}
@FXML
	public void StudentViewExamButtonListner() {
	Stage examReviewStage = new Stage();
	examReviewStage.setTitle("Exam Review Page");
	Parent root;
	try {
		FXMLLoader loader = new FXMLLoader();
		root = loader.load(getClass().getResource("FinishedExamGUI.fxml").openStream());
		FinishedExamGUIController controller = loader.getController();			
		controller.setExam(StudentExamViewList.getSelectionModel().getSelectedItem());
		controller.setManageExamsController(this);
		controller.disable=true;
		Scene scene = new Scene(root);
		examReviewStage.setScene(scene);			
		examReviewStage.initModality(Modality.APPLICATION_MODAL);
		examReviewStage.initOwner(StudentViewExamButton.getScene().getWindow());
		examReviewStage.showAndWait();

	} catch (IOException e) {

		e.printStackTrace();
	}
}
	//manager
	public void updateMessagesTable()
	{				
		
			MessagesTable.getItems().clear();
			messagesList.clear();
			messagesList.addAll(MessageController.receiveRequests());
			MessagesTable.setItems(messagesList);		
			MessageViewTextArea.setVisible(false);
			ApproveButton.setDisable(true);
			DeclineButton.setDisable(true);		
		
	}
	public void approveButtonListener()
	{
		String answer;
		ExtendTimeMessage message = MessagesTable.getSelectionModel().getSelectedItem();
		if(message != null)
		{
			answer = ExamController.extendExamTime(message);
			alert("Request",answer);				
			updateMessagesTable();
		}
	}
	public void declineButtonListener()
	{
		
		ExtendTimeMessage message = MessagesTable.getSelectionModel().getSelectedItem();
		if(message != null)
		{
			MessageController.removeRequest(message);
			alert("Request","Request has been declined");				
			updateMessagesTable();
		}
	}
	private void createComboBoxSubjectOBList()
	{
		ManagersubjectList=CourseAndSubjectController.getSubjectList();//get full subject list
		ManagersubjectsDetails=FXCollections.observableArrayList();//Initialize an observable list 
		for(int i=0;i<ManagersubjectList.size();i++)//add all subject names to the observable list  
		{
			ManagersubjectsDetails.add(ManagersubjectList.get(i).getName());
		}
		SubjectComboBoxManger.getItems().clear();
		SubjectComboBoxManger.setItems(ManagersubjectsDetails);//set the combo box
	}
	/*====================================================================
	 *=viewQuestionBtnAction 
	 *=this method show questions view window 
	 *=this is the action of view question button in questions page
	 *====================================================================
	 */
	@FXML
	public void viewQuestionBtnAction (ActionEvent event) 
	{
		
		if(questionTable.getSelectionModel().getSelectedItem()==null) // if no question was chosen from the table 
		{
			alert("Questuin error", "first choose a question");
		}
		else //else if a question was chosen
		{
			QuestionViewWindow = new Stage();
			QuestionViewWindow.setTitle("Question View");
			QuestionViewWindow.initModality(Modality.APPLICATION_MODAL);
			Parent root;
			try {	
				QuestionViewGUIController.question = questionTable.getSelectionModel().getSelectedItem();
				root = FXMLLoader.load(getClass().getResource("QuesionViewDetails.fxml"));
				Scene scene = new Scene(root);
				QuestionViewWindow.setScene(scene);
				QuestionViewWindow.showAndWait();			
			} catch (IOException e) {			
				e.printStackTrace();
			}
		}
	}
	/*====================================================================
	 *=chooseSubjectComboBoxChanged
	 *==this method puts the question by subject info into the question table
	 *=this is an action of chooseSubjectComboBox from questionPage
	 *====================================================================
	 */
	@FXML
	public void chooseSubjectComboBoxChanged(ActionEvent event) {
		
		String name = SubjectComboBoxManger.getValue();//get the name of subject from combo box
		displayInfoOfSubjectQuestions(name);//show questions of the chosen subject
		
	}
	private void displayInfoOfSubjectQuestions(String subjectName) 
	{
		String id;
		if(subjectName!=null) {id=CourseAndSubjectController.getSubjectIDByName(subjectName);}//get subject id
		else {id=null;}
		questionList=QuestionController.getQuestionListBySubject(id);//get all questions of subject
		ManagerquestionDetails=FXCollections.observableArrayList();//Initialize an observable list 
		for (int i=0;i<questionList.size();i++) //add all questions to the observable list 
		{
			ManagerquestionDetails.add(questionList.get(i));
		}
		/*Handle column tables*/
		question.setCellValueFactory(new PropertyValueFactory<Question,String>("question"));
		author.setCellValueFactory(new PropertyValueFactory<Question,String>("author"));
		qId.setCellValueFactory(new PropertyValueFactory<Question,String>("ID"));
		questionTable.getItems().clear();
		questionTable.setItems(ManagerquestionDetails);//set data into the table
		questionTable.setVisible(true);
	}
	/*====================================================================
	 *=showCourseTable                                 
	 *=this method puts the course info into the courses table
	 *=from courses page  
	 *====================================================================
	 */
	private void showCourseTable()
	{
		courseList = CourseAndSubjectController.getCourseList();
		coursesDetails=FXCollections.observableArrayList();//Initialize an observable list 
		for(int i=0;i<courseList.size();i++) //add all courses to the observable list 
		{
			coursesDetails.add(courseList.get(i));
		}
		/*Handle column tables*/
		colName.setCellValueFactory(new PropertyValueFactory<Course,String>("name"));
		colSubject.setCellValueFactory(new PropertyValueFactory<Course,String>("subjectID"));
		colId.setCellValueFactory(new PropertyValueFactory<Course,String>("ID"));
		ShowDataTable.setItems(coursesDetails);//set data into the table
		ShowDataTable.setVisible(true);
	}
	private void showTeachersTable() 
	{
		ArrayList<Teacher> teacherList=UserController.getTeachersList();//get full Teachers list
		ObservableList<Teacher> teacherDetails=FXCollections.observableArrayList();//Initialize an observable list 
		for(int i=0;i<teacherList.size();i++)  //add all teachers to the observable list 
		{
			teacherDetails.add(teacherList.get(i));
		}
		/*Handle column tables*/
		teacherid.setCellValueFactory(new PropertyValueFactory<Teacher,String>("ID"));
		techerFirstName.setCellValueFactory(new PropertyValueFactory<Teacher,String>("firstName"));
		teacherLastName.setCellValueFactory(new PropertyValueFactory<Teacher,String>("lastName"));
		System.out.println(teacherDetails);
		ManagerteacherTable.setItems(teacherDetails);
		ManagerteacherTable.setVisible(true);//set data into the table
	}
	@FXML
	public void viewTeacherCoursesBySubject (ActionEvent event)  
	{
		if(ManagerteacherTable.getSelectionModel().getSelectedItem()!=null) {
			if(!ManagerteacherTable.getSelectionModel().getSelectedItem().getSubjects().isEmpty())
		{
			ManagerteacherPane.setVisible(false);
			ManagerteacherCoursesPane.setVisible(true);
			createComboBoxSubjecForTecherOBList();
			showNoCoursesLable.setVisible(false);
			
		}else {
			alert("Error", "No courses to show");}
		}else {
			alert("Error", "first choose a teacher");
	}
	}
	private void createComboBoxSubjecForTecherOBList()
	{
		HashSet<Subject> subjectOfTecherList=ManagerteacherTable.getSelectionModel().getSelectedItem().getSubjects();
		ManagersubjectsDetails=FXCollections.observableArrayList();
		for (Subject s : subjectOfTecherList) {
			ManagersubjectsDetails.add(s.getName());
		}
		ManagertecherChooseSubject.getItems().clear();
		ManagertecherChooseSubject.setItems(ManagersubjectsDetails);
	}
	@FXML
	private void showTeacherSubjectCoursesTable(ActionEvent event)
	{		
		String subjectName=ManagertecherChooseSubject.getValue();
		String subjectId=CourseAndSubjectController.getSubjectIDByName(subjectName);
		
		showNoCoursesLable.setVisible(false);
		HashSet<Course> techerSubjectCourses=ManagerteacherTable.getSelectionModel().getSelectedItem().getCoursesOfSubject(subjectId);
		
		if(techerSubjectCourses==null) 
		{
			showNoCoursesLable.setVisible(true);
		}
		else	
		{		
			coursesDetails=FXCollections.observableArrayList();
			Iterator<Course> iter = techerSubjectCourses.iterator();
			while(iter.hasNext()) 
			{
				
				Course course =(Course) iter.next();
				coursesDetails.add(course);
			}
			teacherCourseName.setCellValueFactory(new PropertyValueFactory<Course,String>("name"));
			teacherCourseId.setCellValueFactory(new PropertyValueFactory<Course,String>("ID"));
			teacherShowCoursesTable.setItems(coursesDetails);
		}	
	}
	@FXML
	public void backToTeachersTable (ActionEvent event) 
	{
		ManagerteacherCoursesPane.setVisible(false);
		ManagerteacherPane.setVisible(true);
		teacherShowCoursesTable.getItems().clear();
		showNoCoursesLable.setVisible(false);
	}	
	private void showmanagersTable()
	{
		managersList=UserController.getManagerList();
		if(!managersList.isEmpty())
		managersDetails=FXCollections.observableArrayList();
		for(int i=0;i<managersList.size();i++)//add all subjects to the observable list 
		{
			managersDetails.add(managersList.get(i));
		}		
		managerFirstName.setCellValueFactory(new PropertyValueFactory<SchoolManager,String>("FirstName"));
		managerLastName.setCellValueFactory(new PropertyValueFactory<SchoolManager,String>("lastName"));
		managerid.setCellValueFactory(new PropertyValueFactory<SchoolManager,String>("ID"));
		managerTable.setItems(managersDetails);
		managerTable.setVisible(true);
	}
	private void showStudentsTable()
	{
		ManagerstudentsList=UserController.getstudentList();
		if(!ManagerstudentsList.isEmpty())
			ManagerstudentsDetails=FXCollections.observableArrayList();
		for(int i=0;i<ManagerstudentsList.size();i++)//add all subjects to the observable list 
		{
			ManagerstudentsDetails.add(ManagerstudentsList.get(i));
		}
		
		studentFirstName.setCellValueFactory(new PropertyValueFactory<Student,String>("FirstName"));
		studentLastName.setCellValueFactory(new PropertyValueFactory<Student,String>("lastName"));
		studentid.setCellValueFactory(new PropertyValueFactory<Student,String>("ID"));
		System.out.println(ManagerstudentsDetails);
		ManagerstudentTable.setItems(ManagerstudentsDetails);
		ManagerstudentTable.setVisible(true);
	}
	@FXML
	public void viewStudentsExams(ActionEvent event) {
		
		ManagerStudentfinishedExamsList = ExamController.getFinishedStudentExams(ManagerstudentTable.getSelectionModel().getSelectedItem().getID());
		
		if(ManagerStudentfinishedExamsList!=null) {
			ManagerStudentExamsList.getItems().clear();
			ManagerStudentExamsList.getItems().addAll(ManagerStudentfinishedExamsList);
			ManagerStudentExamsList.setVisible(true);
		}
	}
	private void showUsersTable()
	{
		userList=UserController.getUsersList();
		userDetails=FXCollections.observableArrayList();
		for(int i=0;i<userList.size();i++)//add all subjects to the observable list 
		{
			userDetails.add(userList.get(i));
		}
		userId.setCellValueFactory(new PropertyValueFactory<User,String>("ID"));
		userPassword.setCellValueFactory(new PropertyValueFactory<User,String>("password"));
		userPermission.setCellValueFactory(new PropertyValueFactory<User,String>("permission"));
		usersTable.setItems(userDetails);
		usersTable.setVisible(true);
	}
	@FXML
	public void viewStudentsExamsPreview() {
		
		Stage examReviewStage = new Stage();
		examReviewStage.setTitle("Exam Review Page");
		Parent root;
		try {
			FXMLLoader loader = new FXMLLoader();
			root = loader.load(getClass().getResource("FinishedExamGUI.fxml").openStream());
			FinishedExamGUIController controller = loader.getController();			
			controller.setExam(ManagerStudentExamsList.getSelectionModel().getSelectedItem());
			controller.setManageExamsController(this);
			controller.disable=true;
			Scene scene = new Scene(root);
			examReviewStage.setScene(scene);			
			examReviewStage.initModality(Modality.APPLICATION_MODAL);
			examReviewStage.initOwner(ReviewFinishedExamButton.getScene().getWindow());
			examReviewStage.showAndWait();

		} catch (IOException e) {

			e.printStackTrace();
		}
		
	}
	public void Mangagerfunctions() {
		questionTable.getSelectionModel().selectedItemProperty().addListener(e -> {
			Question question = questionTable.getSelectionModel().getSelectedItem();
			if (question != null)
				QuestionPreview(QuestionPreview1,question);
			viewQuestionBtn.setDisable(false);
		
	});	
		ManagerstudentTable.getSelectionModel().selectedItemProperty().addListener(e -> {
			viewExamsButton.setVisible(true);});	
		
		MessagesTable.getSelectionModel().selectedItemProperty().addListener(e ->{
			ExtendTimeMessage message = MessagesTable.getSelectionModel().getSelectedItem();
			if(message!=null)
			{
				MessageViewTextArea.clear();
				MessageViewTextArea.setText(message.getMessage());
				MessageViewTextArea.setVisible(true);
				ApproveButton.setDisable(false);
				DeclineButton.setDisable(false);
			}
			else
			{
				MessageViewTextArea.setVisible(false);
				ApproveButton.setDisable(true);
				DeclineButton.setDisable(true);
			}
				
		});
		ManagerStudentExamsList.getSelectionModel().selectedItemProperty().addListener(e->{
			viewExamsPreviewButton.setVisible(true);
		});
		
		ManagerStudentExamsList.setCellFactory(lv -> {
			TextFieldListCell<FinishedExam> cell = new TextFieldListCell<FinishedExam>();
			cell.setConverter(new StringConverter<FinishedExam>() {
				@Override
				public String toString(FinishedExam exam) {
					if(exam.getFinalGrade()==-1) {
						Person executer = ExamController.getexecutorExamByExamID(exam.getID());
						return "ID: "+exam.getID()+" Subject:"+exam.getSubject().getName()+" Course"+exam.getCourse().getName()+" Grade:" +executer.getName()+"need to confirm exam" ;
					}
					else {
						return "ID: "+exam.getID()+" Subject:"+exam.getSubject().getName()+" Course"+exam.getCourse().getName()+" Grade:"+exam.getFinalGrade();
					}
					
				}
				

				@Override
				public FinishedExam fromString(String string) {
					return null;
				}
			});
			return cell;
		});	
		
				
		//statistic course
		StaticCourseComboBox.setConverter(new StringConverter<Course>() {
			public String toString(Course course) {
				return course.getName();
			}

			@Override
			public Course fromString(String arg0) {
				return null;
			}

		});
		StaticCourseComboBox.getSelectionModel().selectedItemProperty().addListener(e->{
			Course course = StaticCourseComboBox.getSelectionModel().getSelectedItem();
			if(course != null) {
				updateStatisticExamComboBox(course);
			}
		});
		StaticCourseExamComboBox.setConverter(new StringConverter<Exam>() {
			public String toString(Exam exam) {
				return exam.getID();
			}

			@Override
			public Exam fromString(String arg0) {
				return null;
			}

		});
		StatisticCourseExcutedExamList.setCellFactory(lv -> {
			TextFieldListCell<ExecutedExam> cell = new TextFieldListCell<ExecutedExam>();
			cell.setConverter(new StringConverter<ExecutedExam>() {
				@Override
				public String toString(ExecutedExam exam) {
					
						return "executedID: "+exam.getId()+" Time:"+ exam.getExamTime();			
					
				}
				@Override
				public ExecutedExam fromString(String string) {
					return null;
				}
			});
			return cell;
		});		
		StaticCourseExamComboBox.getSelectionModel().selectedItemProperty().addListener(e->{
			updateExcutedExams(StatisticCourseExcutedExamList,StaticCourseExamComboBox.getSelectionModel().getSelectedItem().getID());
		});
		StatisticCourseExcutedExamList.getSelectionModel().selectedItemProperty().addListener(e->{
			
			CourseBarChart.getData().clear();
			int selected = StatisticCourseExcutedExamList.getSelectionModel().getSelectedItem().getId();
			System.out.println(selected);
			setCourseHistogram(selected);
			CourseBarChart.setVisible(true);
			decline.setVisible(true);
			StudentsCount.setVisible(true);
		});
		//statistic teacher
		StaticTeacherComboBox.setConverter(new StringConverter<Teacher>() {
			public String toString(Teacher teacher) {
				return teacher.getName();
			}

			@Override
			public Teacher fromString(String arg0) {
				return null;
			}

		});
		
		
		
		
		StaticTeacherComboBox.getSelectionModel().selectedItemProperty().addListener(e->{
			Teacher teacher = StaticTeacherComboBox.getSelectionModel().getSelectedItem();
			if(teacher != null) {
				updateStatisticExamComboBox(teacher);
			}
		});
		StaticTeacherExamComboBox.setConverter(new StringConverter<Exam>() {
			public String toString(Exam exam) {
				return exam.getID();
			}

			@Override
			public Exam fromString(String arg0) {
				return null;
			}

		});
		StaticTeacherExamComboBox.getSelectionModel().selectedItemProperty().addListener(e->{
			String selected = StaticTeacherExamComboBox.getSelectionModel().getSelectedItem().getID();
			if(selected != null) {
			updateExcutedExams(StatisticCourseExcutedExamList,selected);
			}
		});
				

	}
	private void updateExcutedExams(ListView<ExecutedExam> list,String selected) {
		if(list.getItems() == null)
			System.out.println("no list");
			
		else {
		list.getItems().clear();
		list.getItems().addAll(ExamController.getExcutedExamsByExamId(selected));
		list.setVisible(true);
			}
	}
	
	//all first combobox
	public void updateStatisticTeacherComboBox() {
		if(StaticTeacherComboBox.getItems() == null)
			return;
		StaticTeacherComboBox.getItems().clear();
		StaticTeacherComboBox.getItems().addAll(UserController.getTeachersList());

	}
	public void updateStatisticCourseComboBox() {
		if(StaticCourseComboBox.getItems() == null)
			return;
		StaticCourseComboBox.getItems().clear();
		StaticCourseComboBox.getItems().addAll(CourseAndSubjectController.getCourseList());

	}
	public void updateStatisticStudentComboBox() {
		if(StaticStudentComboBox.getItems() == null)
			return;
		StaticStudentComboBox.getItems().clear();
		StaticStudentComboBox.getItems().addAll(UserController.getstudentList());

	}
	//all seconds combobox
	public void updateStatisticExamComboBox(Object Byfilter) {
		
		if(Byfilter instanceof Course) {
			if(StaticCourseExamComboBox.getItems() == null)
				return;
			StaticCourseExamComboBox.getItems().clear();
			ArrayList<Exam> exams = ExamController.getExamByCourse(((Course)Byfilter).getID());
			
			if (exams.isEmpty()) {
				messageNoExams.setText("No statistical exams infornamtion in this course");
				messageNoExams.setVisible(true);
			}else {
			StaticCourseExamComboBox.getItems().clear();
			StaticCourseExamComboBox.getItems().addAll(exams);
			messageNoExams.setVisible(false);
			}
		}
		if(Byfilter instanceof Teacher) {
			if(StaticTeacherExamComboBox.getItems() == null)
				return;
			StaticTeacherExamComboBox.getItems().clear();
			ArrayList<Exam> exams = ExamController.getExamByAuthor(((Teacher)Byfilter).getID());
			
			if (exams.isEmpty()) {
				messageNoExams1.setText("No statistical exams infornamtion in this teacher");
				messageNoExams1.setVisible(true);
			}else {
			StaticTeacherExamComboBox.getItems().addAll(exams);
			messageNoExams1.setVisible(false);
			}
		}
	}
	
	private void setCourseHistogram(int exam) {
		
		ArrayList decliens = ExamController.getExamDecline(exam);
		XYChart.Series<String,Integer> set=new XYChart.Series<String,Integer>();
		for(int i=0;i<8;i++) {
			int number1 = i*10;
			int number2 = (i+1)*10;
			set.getData().add(new Data<String, Integer>(Integer.toString(number1)+"-"+Integer.toString(number2),(Integer)decliens.get(i)));
		
		}
		set.getData().add(new Data<String, Integer>("90-100",(Integer)decliens.get(9)));
		CourseBarChart.getData().addAll(set);
	}
	
	public void setManagerFactories()
	{
		Received.setCellValueFactory(c-> new SimpleStringProperty(c.getValue().getFormattedDate()));
		Sender.setCellValueFactory(new PropertyValueFactory<ExtendTimeMessage,String>("sender"));		
		TimeExtension.setCellValueFactory(c-> new SimpleStringProperty(c.getValue().getTimeExtensionMinutes()));
	}
	
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		// TODO Auto-generated method stub
		
		this.HomePagePermission = GUI_LoginController.user.getPermission();
		CreateTreeView();
		
		Options.getSelectionModel().selectedItemProperty().addListener((v, oldValue, newValue) -> { 
				ClickOptions();

			});

		setManagerFactories();
		
	}	
	
}
