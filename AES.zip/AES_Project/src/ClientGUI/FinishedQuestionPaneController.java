package ClientGUI;

import java.net.URL;
import java.util.ResourceBundle;

import AES_Classes.QuestionInExam;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;

public class FinishedQuestionPaneController implements Initializable {


    @FXML private Label QuestionLabel;
    @FXML private Label Answer1Label;
    @FXML private Label Answer2Label;
    @FXML private Label Answer3Label;
    @FXML private Label Answer4Label;
    @FXML private Label CorrectAnswerLabel;
    @FXML private TextArea NoteForStudentTextArea;
    
    private Label[] answersLabels;
    private QuestionInExam question;
    private FinishedExamGUIController finishedExamWindowController;
	
	public void setQuestion(QuestionInExam question, int questionNumber, int answer, String note) {
		answersLabels = new Label[4];
		answersLabels[0]=Answer1Label;
		answersLabels[1]=Answer2Label;
		answersLabels[2]=Answer3Label;
		answersLabels[3]=Answer4Label;
		QuestionLabel.setText("Question "+questionNumber + ":\n" + question.getQuestion());
		Answer1Label.setText("a. " + question.getAnswer(1));
		Answer2Label.setText("b. " + question.getAnswer(2));
		Answer3Label.setText("c. " + question.getAnswer(3));
		Answer4Label.setText("d. " + question.getAnswer(4));
		if(answer!=0) {			
			if(question.getCorrectAnswerIndex()==answer)		
				answersLabels[answer-1].setTextFill(Color.GREEN);

			else 		
				answersLabels[answer-1].setTextFill(Color.RED);
			answersLabels[answer-1].setFont(Font.font (null,FontWeight.BOLD, 20));
			
		}
		CorrectAnswerLabel.setText("Correct answer: "+(char)('a'-1+question.getCorrectAnswerIndex()));
		if(note != null &&  !note.equals("null"))
			NoteForStudentTextArea.setText(note);
		this.question = question;
		if(finishedExamWindowController.getExam().getFinalGrade() != -1)			
			NoteForStudentTextArea.setDisable(true);
		
	}
     
	public void setFinishedExamWindowController(FinishedExamGUIController finishedExamWindowController)
	{
		this.finishedExamWindowController = finishedExamWindowController;
	}
	public String getNote(){
		if(NoteForStudentTextArea.getText()!=null)
			return NoteForStudentTextArea.getText().trim();
		return null;
	}
	
	public QuestionInExam getQuestion() {
		return question;
	}

	public void disableManager() {
		NoteForStudentTextArea.setDisable(true);
	}
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		// TODO Auto-generated method stub
		
	}


}
