package ClientGUI;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.ResourceBundle;

import AES_Classes.Exam;
import AES_Classes.Examinee;
import AES_Classes.FinishedExam;
import AES_Classes.QuestionInExam;
import AES_Client.ExamController;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Insets;
import javafx.scene.Node;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Pagination;
import javafx.scene.control.ScrollPane;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.VBox;

public class ExamGUIController implements Initializable {
	/**==================================
	 *=ExamGUIController GUI parameters========== 
	 *==================================
	 */
	FinishedExam finishedExam;
    @FXML private Pagination pagination;
    @FXML private Label RemainingTimeLabel;
    @FXML private Button SubmitButton;
    public static final int itemsPerPage = 4;
    public ArrayList<QuestionInExam> questionsInExam;
	private ArrayList<ExamFormPageController> pagesList;
	private ArrayList<VBox> layoutList;
	private AnchorPane OurAnchorPane;	
	private Examinee examinee;
	private Node firstPageLayout;
	private ExamfirstPageController firstPageController;
	private ArrayList<ExamQuestionPaneController> questionsControllers;
	private Exam exam;
	String examCode;
    private HomePageController HomePage;
	
    @FXML
    public void submitExamListener(ActionEvent action)
    {
    	HomePage.submitExam();
    }
    /**
	*this method call to enable submit button after take exam in home page
	*/	
    public void enableSubmitButton()
    {
    	SubmitButton.setDisable(false);
    	HomePage.enableSubmitButton();
    }
    /**
	*This method Submit exam  \ add exam taking to finished exam
	*@param reason who the exam finished
	*@param message The submit status : success or failed
	*Get all questions answer and add them to finished exam
	*/   
    public void submitExam(String reason, String message) {
    	HashMap<String,Integer> answers = new HashMap<String,Integer>();
		for(int i = 0 ; i<questionsControllers.size(); i++) {
    		answers.put(questionsControllers.get(i).getQuestion().getID(),	questionsControllers.get(i).getSelectedAnswer());  	    		
    	}
		finishedExam.setAnswers(answers);
    	ExamController.submitExam(finishedExam, examinee, reason);
    	closeWindow(message,"The exam has been submitted");  	
    	
    
    }
    /**
  	*This method Set Remaining time in Minutes of exam
  	*@param remainingTime Who much time student have to submit exam
  	*/
    public void setRemainingTime(Long remainingTime)
    {	    	
    	Platform.runLater(new Runnable(){

			@Override
			public void run() {
				if((remainingTime*1.0)/exam.getExamTime()<=0.5)
					RemainingTimeLabel.setStyle("-fx-background-color: orange;");
				if((remainingTime*1.0)/exam.getExamTime()<0.2)
					RemainingTimeLabel.setStyle("-fx-background-color: red;");
				
				RemainingTimeLabel.setText("Remaining Time: "+remainingTime +" Minutes");					
			}	    		
    	});
    	
    }
    /**
     *=The method performed when need to alert a message                             
     *=this method performed when we call to alert a message
     *@param title the title of alert window
     *@param message he message will present in the window
     */
    public void alert(String title, String message)
	{    	
		Alert alert = new Alert(AlertType.INFORMATION);
		alert.setTitle(title);
		alert.setHeaderText(null);
		alert.setContentText(message);
		alert.showAndWait();
		}
    /**
  	*This method set Exam Finish Time in Minutes of exam
  	*@param finishTime what is the time for finish the exam
  	*/
    public void setExamFinishTime(Date finishTime)
    {
    	HomePage.setExamFinishTime(finishTime);
    }    
      /**
  	*This method  set home page controller
  	*@param takeExamMainPageController the home page of take exam window
  	*/
    public void setTakeExamPageController(HomePageController takeExamMainPageController)
    {
    	this.HomePage = takeExamMainPageController;
    }
    /**
  	*This method add question to page view
  	*@param questionsInExam all question in exam
  	*/    
	public void setQuestionsInExam(ArrayList<QuestionInExam> questionsInExam) {
		this.questionsInExam = questionsInExam;
		pagination.setPageCount(1);	
		initPages();
	}
	/**
  	*This method close exam window
  	*@param reason alert title
  	*@message message alert message
  	*Before close ,Display alert window 
  	*/  
	public void closeWindow(String reason , String message)
	{
		Platform.runLater(new Runnable(){

			@Override
			public void run() {
				
				alert(reason,message);
				pagination.getScene().getWindow().hide();
				HomePage.CodeTextField.setVisible(true);
				HomePage.CodeTextField.clear();
				HomePage.MessageActive.setVisible(true);
				HomePage.ExecutionCodeLabel.setVisible(true);
				HomePage.SubmitButton.setVisible(false);
				HomePage.OpenButton.setVisible(false);
				HomePage.FinishTimeLabel.setVisible(false);
				
			}
			
		});		
	}
	  /**
  	*This method  get question pane controller
  	*/
	public ArrayList<ExamQuestionPaneController> getExamQuestionsControllers()
	{
		return questionsControllers;
	}
	  /**
  	*This method  set exam in exam GUI controller parameters
  	*@param exam the exam to add
  	*Add exam and question in exam from lost in exam
  	*Create pages view to this exam
  	*/
	public void setExam(Exam exam) {			
		this.exam = exam;
		this.questionsInExam = exam.getQuestions();
		initFirstPage();
	}
	  /**
  	*This method  set code to controller exam code
  	*@param examCode The code of the exam
  	*/
	public void setExamCode(String examCode)
	{
		this.examCode = examCode;
	}
	  /**
  	*This method get the exam page
  	*/
	public ArrayList<ExamFormPageController> getPagesList()
	{
		return pagesList;
	}
	  /**
  	*This method  get list of question in the exam
  	*/
	public ArrayList<QuestionInExam> getExamQuestions()
	{
		return questionsInExam;
	}
	  /**
  	*This method  will present the first Page of exam in scroll pane
  	 	*/
    public ScrollPane createPage(int pageIndex) {
    		
		try {
			ScrollPane scrollPane = new ScrollPane();
			scrollPane.getStylesheets().add("FixScrollbar.css");
			scrollPane.setStyle("-fx-background-color:white");
			if (pageIndex == 0) {			
									
				scrollPane.setContent(firstPageLayout);
				return scrollPane;
			}
	
			scrollPane.setContent(layoutList.get(pageIndex-1));				
			return scrollPane;
		} catch (Exception e) {
			e.printStackTrace();			
			return null;
		}
	}
	  /**
	*This method will set only 4 question in page
	*For all 4 question will init page 
	 	*/
	public void setPageCount() {			
		if (questionsInExam.size() % itemsPerPage == 0)
			pagination.setPageCount(questionsInExam.size() / itemsPerPage + 1);

		else
			pagination.setPageCount(questionsInExam.size() / itemsPerPage + 2);
		initPages();
		

	}
	  /**
  	*This method set Examine to controller exam 
  	*@param examinee The examine exam to set
  	*/
	public void setExaminee(Examinee examinee) {
		this.examinee=examinee;
		finishedExam = new FinishedExam(exam,"Online");
		finishedExam.setStartTime(examinee.getStartTime());
	}
	  /**
		*This method initialize the first page of exam
		*/
	public void initFirstPage()
	{
		FXMLLoader loader = new FXMLLoader();
		try {
			firstPageLayout = loader.load(getClass().getResource("ExamFirstPage.fxml").openStream());						
			firstPageController = loader.getController();	
			firstPageController.setExamWindowController(this);
			firstPageController.setExamFirstPage(exam);
			firstPageController.setExamCode(examCode);				 					
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
    
	  /**
			*This method initialize the questions pages of exam
			*/
	public void initPages() {
		FXMLLoader loader = new FXMLLoader();			
		for(int pageIndex=0;pageIndex<pagination.getPageCount()-1;pageIndex++) {
			VBox box = new VBox();
			for(int i = 0; i < itemsPerPage && (pageIndex)*4+i<questionsInExam.size() ; i++) {
				try {
					loader = new FXMLLoader();
					Node questionLayout = loader.load(getClass().getResource("ExamQuestionPane.fxml").openStream());	
					ExamQuestionPaneController controller = loader.getController();	
					controller.setQuestion(questionsInExam.get((pageIndex)*4+i), (pageIndex)*4+i+1);
					questionsControllers.add(controller);
					box.getChildren().add(questionLayout);
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			box.setStyle("-fx-background-color:white;");
			box.setPadding(new Insets(0,0,0,20));
			layoutList.add(box);
			
		}
	}

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		// TODO Auto-generated method stub
		pagination.setPageFactory((Integer pageIndex) -> createPage(pageIndex));
		firstPageController = null;
		firstPageLayout = null;		;
		layoutList = new ArrayList<VBox>();	
		questionsControllers = new ArrayList<ExamQuestionPaneController>();
		SubmitButton.setDisable(true);
		
	}




}
