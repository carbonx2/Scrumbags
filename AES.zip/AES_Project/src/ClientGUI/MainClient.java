package ClientGUI;

import java.io.IOException;
import java.util.Optional;

import AES_Client.client;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Rectangle2D;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ButtonType;
import javafx.stage.Screen;
import javafx.stage.Stage;

public class MainClient extends Application {

	final static int DEFAULT_PORT = 5555;
	public static client client;
	public static boolean connected =false;
	public static Stage stage;
	public static Scene login;
	public static String exception;
	
	@Override
	public void start(Stage primaryStage) throws Exception {
		// TODO Auto-generated method stub
			primaryStage.setResizable(false);
		try {
			connect("localhost",DEFAULT_PORT);
			Parent root = FXMLLoader.load(getClass().getResource("/ClientGUI/LoginGUI.fxml")); 
			Scene scene = new Scene(root, 592, 400);
			stage = primaryStage;
			login = scene;
			primaryStage.setOnCloseRequest(e -> {
				e.consume();
				Alert alert = new Alert(AlertType.CONFIRMATION);
				alert.setContentText("Are you sure you want to exit?");
				alert.setHeaderText(null);
				alert.setGraphic(null);
				Optional<ButtonType> result = alert.showAndWait();
				
				if (result.get() == ButtonType.OK){
					Platform.exit();
					System.exit(1);
				} else {
				   alert.hide();
				}		
				
			});
			stage.setTitle("AES LogIn");
			stage.setScene(scene);
			stage.show();
			
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	public static boolean connect(String address,int port)
	{
		try {
			client = new client(address, port);	
		    connected=true;
		    return true;
			}
			
	    
	    catch(Exception e)
	    {	   	
	    	exception =e.getMessage();
	    	System.out.println(exception);
	        connected=false;
	    	return false;
	    }
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		launch(args);
	}
	
	public static void swittchscene(String title,Scene scene) {
		{
			Platform.runLater(new Runnable() {
				
			    @Override
			public void run() {
			stage.setScene(scene);
			stage.setResizable(false);
			Rectangle2D primScreenBounds = Screen.getPrimary().getVisualBounds();
			stage.setX((primScreenBounds.getWidth() - stage.getWidth()) / 2);
			stage.setY((primScreenBounds.getHeight() - stage.getHeight()) / 2);
			stage.setTitle(title);
			    }
			});
		}
	}

}
