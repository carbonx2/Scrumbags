package AES_Server;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Locale;

import org.apache.poi.xwpf.usermodel.ParagraphAlignment;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;
import org.apache.poi.xwpf.usermodel.XWPFRun;

import com.mysql.cj.ServerVersion;

import AES_Classes.Course;
import AES_Classes.Exam;
import AES_Classes.Packet;
import AES_Classes.Person;
import AES_Classes.Question;
import AES_Classes.QuestionInExam;
import AES_Classes.Student;
import AES_Classes.Subject;
import OCSF.Server.ConnectionToClient;
import AES_Server.ServerWatch;
import AES_Classes.ManualExamFile;
import AES_Server.Server;
import AES_Classes.Examinee;
import AES_Classes.ExecutedExam;
import AES_Classes.ExtendTimeMessage;
import AES_Classes.FinishedExam;

public class ExamController {
	
	/**
	    * This method add new exam to database
	    * Create Statement to EXANS table in data base 
	    * Save all Id exam in array list
	    * Gives a new ID to the exam by going over the array list and searching for free id
	    * Insert new values to examS table
	    * Return answer if adding was success or Failure
	     * @param exam  giving by client , this exam will be add to database
	    */
	public static String addExamToRepository(Exam exam)
	{
		int[] indexArray= new int[100]; 
		int count=0, newIndexOfExam=0;
		String examID=exam.getID();
		ArrayList<QuestionInExam> questionsList = exam.getQuestions();
		Statement stmt;
		try {
			stmt = Server.conn.createStatement();
			ResultSet rs = stmt.executeQuery("SELECT ID FROM EXAMS WHERE ID LIKE '"+examID+"%';");
			PreparedStatement ps=Server.conn.prepareStatement("INSERT INTO EXAMS VALUES (?,?,?,?,?,?,?,?);");	
			while(rs.next()) { 			
				indexArray[Integer.parseInt(rs.getString(1))%100]=1;
				count++;
			}
			
			for(newIndexOfExam = 0 ; newIndexOfExam < count+1 ; newIndexOfExam++)
				if(indexArray[newIndexOfExam]==0)
					break;
			examID+=String.format("%02d", newIndexOfExam);
			ps.setString(1, examID);
			ps.setString(2, exam.getCourse().getID());
			ps.setString(3, exam.getSubject().getID());						
			ps.setString(4, exam.getAuthor().getID());			
			ps.setString(5, exam.getCreationDate());
			ps.setInt(6, exam.getExamTime());
			ps.setString(7, exam.getNote());
			ps.setInt(8, 1);
			ps.execute();
			rs.close();
			stmt = Server.conn.createStatement();
			
			for(QuestionInExam question : questionsList) {
				stmt.executeUpdate("INSERT INTO EXAMSQUESTIONS VALUES ('"+examID+"','"+question.getID()+"','"+question.getScore()+"','"+question.getNoteForStudent()+"','"+question.getNoteForTeacher()+"');");
			}
			
			
			
		} catch (SQLException e) {
			e.printStackTrace();
			return "Failure";
		}
		return "Success";	
	}
	/**
	    * This method Return all exam in the database 
	    * Create Statements to examS and TEACHERS table in data base 
	    * Save all  exam in array list by subject
		    ** Search exam by is subject or maybe client will send null - will search all exams
		    ** Create exam by is values in examS table
		    ** id values in examS table giving the details of the teacher that create exam and teacher values have been added to exam
		    ** After all values insert to exam , Adding exam to array list
	    * Return array list with all exams
	     
	    */
	public static ArrayList<Exam> getExamsList(){
		return getExamsListBySubject(null);
	}
	/**
	    * This method Return all exam in the database that there subject is specific
	    * Create Statements to EXAMS and TEACHERS table in data base 
	    * Save all  exam in array list by subject
		    ** Search exam by is subject or maybe client will send null - will search all exams
		    ** Create exam by is values in examS table
		    ** id values in examS table giving the details of the teacher that create exam and teacher values have been added to exam
		    ** After all values insert to exam , Adding exam to array list
	    * Return array list with all exams
	     
	    */
	 public static ArrayList<Exam> getExamsListBySubject(String subject)
	 {
		 Statement stmt,stmt1;
		 ArrayList<Exam> examsList = new ArrayList<Exam>();
		 Course examCourse;
		 Subject examSubject;
		 Person examAuthor;
		 Exam exam;
		 ArrayList<QuestionInExam> questionsList;	
		try {
			stmt = Server.conn.createStatement();	
			stmt1 = Server.conn.createStatement();
			ResultSet rs;
			if(subject!=null)
				rs = stmt.executeQuery("SELECT E.ID, C.ID, C.NAME, S.ID, S.NAME, T.ID, T.FIRSTNAME, T.LASTNAME, E.CREATIONDATE, E.EXAMTIME, E.NOTE FROM EXAMS E, COURSES C, SUBJECTS S, TEACHERS T WHERE E.SUBJECT = '"+subject+"' AND E.COURSE = C.ID AND E.SUBJECT = S.ID AND E.AUTHOR = T.ID AND E.AVAILABLE=1;");
			else
				rs = stmt.executeQuery("SELECT E.ID, C.ID, C.NAME, S.ID, S.NAME, T.ID, T.FIRSTNAME, T.LASTNAME, E.CREATIONDATE, E.EXAMTIME, E.NOTE FROM EXAMS E, COURSES C, SUBJECTS S, TEACHERS T WHERE E.COURSE = C.ID AND E.SUBJECT = S.ID AND E.AUTHOR = T.ID AND E.AVAILABLE=1;");
			ResultSet rs1;
			while(rs.next())
			{
				examCourse = new Course(rs.getString(2),rs.getString(3),rs.getString(4));
				examSubject = new Subject(rs.getString(4),rs.getString(5));
				examAuthor = new Person(rs.getString(6),rs.getString(7)+" "+rs.getString(8));
				questionsList = new ArrayList<QuestionInExam>();
				
				rs1 = stmt1.executeQuery("SELECT T.ID, T.FIRSTNAME, T.LASTNAME, Q.ID, Q.QUESTION, Q.ANSWER1, Q.ANSWER2, Q.ANSWER3, Q.ANSWER4, Q.CORRECTANSWER, EQ.SCORE, EQ.NOTEFORSTUDENT, EQ.NOTEFORTEACHER FROM TEACHERS T, QUESTIONS Q, EXAMSQUESTIONS EQ WHERE EQ.EXAM='"+rs.getString(1)+"' AND EQ.QUESTION = Q.ID AND T.ID = Q.AUTHOR;");
				
				while (rs1.next())
				{
					Person author = new Person(rs1.getString(1),rs1.getString(2)+" "+rs1.getString(3));
					Question question = new Question(rs1.getString(4), author, rs1.getString(5), rs1.getString(6), rs1.getString(7), rs1.getString(8), rs1.getString(9), rs1.getInt(10));
					QuestionInExam questionInExam = new QuestionInExam(question,rs1.getInt(11));
					questionInExam.setNoteForStudent(rs1.getString(12));
					questionInExam.setNoteForTeacher(rs1.getString(13));
					questionsList.add(questionInExam);
					
				}
				exam = new Exam (rs.getString(1), examCourse, examSubject, examAuthor, rs.getString(9), questionsList, rs.getInt(10));
				
				exam.setNote(rs.getString(11));
				examsList.add(exam);						
				
			}
			return examsList;
	
		} catch (SQLException e) {			
			e.printStackTrace();
			return null;
		}
	}
	 public static Exam getExamByID(String examID)
		{
			Statement stmt,stmt1;		
			Course examCourse;
			Subject examSubject;
			Person examAuthor;
			Exam exam;
			ArrayList<QuestionInExam> questionsList;	
			try {
				stmt = Server.conn.createStatement();	
				stmt1 = Server.conn.createStatement();
				ResultSet rs;		
				
					rs = stmt.executeQuery("SELECT E.ID, C.ID, C.NAME, S.ID, S.NAME, T.ID, T.FIRSTNAME, T.LASTNAME, E.CREATIONDATE, E.EXAMTIME, E.NOTE FROM EXAMS E, COURSES C, SUBJECTS S, TEACHERS T WHERE E.ID = '"+examID+"' AND E.COURSE = C.ID AND E.SUBJECT = S.ID AND E.AUTHOR = T.ID AND E.AVAILABLE=1;");
				ResultSet rs1;
				rs.next();			
					examCourse = new Course(rs.getString(2),rs.getString(3),rs.getString(4));
					examSubject = new Subject(rs.getString(4),rs.getString(5));
					examAuthor = new Person(rs.getString(6),rs.getString(7)+" "+rs.getString(8));
					questionsList = new ArrayList<QuestionInExam>();
					rs1 = stmt1.executeQuery("SELECT T.ID, T.FIRSTNAME, T.LASTNAME, Q.ID, Q.QUESTION, Q.ANSWER1, Q.ANSWER2, Q.ANSWER3, Q.ANSWER4, Q.CORRECTANSWER, EQ.SCORE, EQ.NOTEFORSTUDENT, EQ.NOTEFORTEACHER FROM TEACHERS T, QUESTIONS Q, EXAMSQUESTIONS EQ WHERE EQ.EXAM='"+rs.getString(1)+"' AND EQ.QUESTION = Q.ID AND T.ID = Q.AUTHOR ;");

					while (rs1.next())
					{
						Person author = new Person(rs1.getString(1),rs1.getString(2)+" "+rs1.getString(3));
						Question question = new Question(rs1.getString(4), author, rs1.getString(5), rs1.getString(6), rs1.getString(7), rs1.getString(8), rs1.getString(9), rs1.getInt(10));
						QuestionInExam questionInExam = new QuestionInExam(question,rs1.getInt(11));
						questionInExam.setNoteForStudent(rs1.getString(12));
						questionInExam.setNoteForTeacher(rs1.getString(13));
						questionsList.add(questionInExam);
					}
					exam = new Exam (rs.getString(1), examCourse, examSubject, examAuthor, rs.getString(9), questionsList, rs.getInt(10));
					exam.setNote(rs.getString(11));									

				
				return exam;

			} catch (SQLException e) {			
				e.printStackTrace();
				return null;
			}
		}

	 /**
	    * This method remove exam from database
	    * Create Statement to examS table in data base 
	    * Search exam by is id 
	    * remove the exam from EXAMS table
	    * Return answer if adding was success or Failure
	     * @param ID  giving by client , this exam id give the exam that remove from database
	    */
		public static String removeExamFromRepository(String ID)
		{
			Statement stmt;
			try {
				stmt = Server.conn.createStatement();
				stmt.executeUpdate("UPDATE EXAMS SET AVAIABLE=0 WHERE ID = '"+ID+"'");
				return "Success";
			} catch (SQLException e) {
				e.printStackTrace();
				return "Failure";
			}

		}

		
		public static boolean executeExam(String executionCode, Exam exam, String teacherID )
		{
			try {
				int executionID = getNumberOfExams();
				Statement stmt,stmt1, stmt2;
				stmt = Server.conn.createStatement();
				stmt1 = Server.conn.createStatement();		
				stmt2 = Server.conn.createStatement();
				
				Date date = new Date();  
				ResultSet rs = stmt.executeQuery("SELECT * FROM ACTIVEEXAMS WHERE CODE= '"+executionCode+"';");
				if(rs.next())		    
					return false;				
				
				stmt1.executeUpdate("INSERT INTO EXECUTEDEXAMS VALUES ('"+executionID+"', '"+executionCode+"','"+exam.getID()+"','"+date+"', '"+teacherID+"',"+exam.getExamTime()+",0,0,0) ;");
				stmt2.executeUpdate("INSERT INTO ACTIVEEXAMS VALUES ('"+executionID+"', '"+executionCode+"','"+exam.getID()+"','"+date+"', '"+teacherID+"') ;");
				createManualExam(executionID, executionCode);
				
				return true;
			
			}	catch(Exception e)
			{
				e.printStackTrace();
				return false;
			}

		}
		
	 public static String checkExamCode(String examCode, String studentID)
		{
			try
			{
				Statement stmt,stmt1;			
				stmt = Server.conn.createStatement();	
				stmt1 = Server.conn.createStatement();
				ResultSet rs = stmt.executeQuery("SELECT ID FROM ACTIVEEXAMS WHERE CODE= '"+examCode+"';");			
				ResultSet rs1;
				if(rs.next())	
				{			
					rs1 = stmt1.executeQuery("SELECT * FROM FINISHEDEXAMS FE WHERE FE.ID = '"+rs.getString(1)+"' AND FE.EXAMINEE = '"+studentID+"';");
				if(rs1.next())	
					return "TookExamAlready";
				
				return "Success";
				}
				
				return "ExamCodeDoesntExist";
			}
			catch(Exception e)
			{
				e.printStackTrace();
				return "Exception";
			}
		}

		
		public static void removeActiveExam(String examExecutionCode)
		{
			try
			{
				Statement stmt,stmt1,stmt2,stmt3;	
				ResultSet rs1,rs2;
				int ID;
				int numberOfExaminees=0, FNumber=0, DNFNumber=0;
				stmt = Server.conn.createStatement();	
				stmt1 = Server.conn.createStatement();
				stmt2 = Server.conn.createStatement();
				stmt3 = Server.conn.createStatement();
				rs1 = stmt.executeQuery("SELECT ID FROM ACTIVEEXAMS WHERE CODE = '"+examExecutionCode+"'");			
				if(rs1.next())
					ID=rs1.getInt(1);
				else
					return;
				stmt2.executeUpdate("DELETE FROM ACTIVEEXAMS WHERE CODE = '"+examExecutionCode+"';");
				rs2 = stmt1.executeQuery("SELECT * FROM FINISHEDEXAMS WHERE ID = '"+ID+"'");			
				while(rs2.next()) {
					if(rs2.getString(7).equals("ByUser"))
						FNumber++;
					else
						DNFNumber++;
					numberOfExaminees++;
				}
				stmt3 = Server.conn.createStatement();	
				stmt.executeUpdate("UPDATE EXECUTEDEXAMS SET numberofexaminees = '"+numberOfExaminees+"', F = '"+FNumber+"', DNF = '"+DNFNumber+"' WHERE ID = '"+ID+"';");	
			
				
			
			}	
				
			catch(Exception e)
			{
				e.printStackTrace();
			
			}
			
		
		}
		
		public static Exam takeExam(String examExecutionCode)
		{
			Statement stmt,stmt1;	
			Exam exam = null;
			Course examCourse;
			Subject examSubject;
			Person examAuthor;			
			ArrayList<QuestionInExam> questionsList;	
			try {
				stmt = Server.conn.createStatement();	
				stmt1 = Server.conn.createStatement();
				ResultSet rs;
				ResultSet rs1;			
				
				rs = stmt.executeQuery("SELECT E.ID, C.ID, C.NAME, S.ID, S.NAME, T.ID, T.FIRSTNAME, T.LASTNAME, E.CREATIONDATE, E.EXAMTIME, E.NOTE FROM ACTIVEEXAMS AE, EXAMS E, COURSES C, SUBJECTS S, TEACHERS T WHERE AE.CODE ='"+examExecutionCode+"' AND AE.EXAM = E.ID AND E.COURSE = C.ID AND E.SUBJECT = S.ID AND E.AUTHOR = T.ID ;");
				if(rs.next())
				{			
				examCourse = new Course(rs.getString(2),rs.getString(3),rs.getString(4));
				examSubject = new Subject(rs.getString(4),rs.getString(5));
				examAuthor = new Person(rs.getString(6),rs.getString(7)+" "+rs.getString(8));
				questionsList = new ArrayList<QuestionInExam>();			

				rs1 = stmt1.executeQuery("SELECT T.ID, T.FIRSTNAME, T.LASTNAME, Q.ID, Q.QUESTION, Q.ANSWER1, Q.ANSWER2, Q.ANSWER3, Q.ANSWER4, Q.CORRECTANSWER, EQ.SCORE, EQ.NOTEFORSTUDENT FROM TEACHERS T, QUESTIONS Q, EXAMSQUESTIONS EQ WHERE EQ.EXAM='"+rs.getString(1)+"' AND EQ.QUESTION = Q.ID AND T.ID = Q.AUTHOR ;");

				while (rs1.next())
				{
					Person author = new Person(rs1.getString(1),rs1.getString(2)+" "+rs1.getString(3));
					Question question = new Question(rs1.getString(4), author, rs1.getString(5), rs1.getString(6), rs1.getString(7), rs1.getString(8), rs1.getString(9), rs1.getInt(10));
					QuestionInExam questionInExam = new QuestionInExam(question,rs1.getInt(11));
					questionInExam.setNoteForStudent(rs1.getString(12));						
					questionsList.add(questionInExam);

				}
				exam = new Exam (rs.getString(1), examCourse, examSubject, examAuthor, rs.getString(9), questionsList, rs.getInt(10));					
				exam.setNote(rs.getString(11));										
				}
				
				
				return exam;
				
			} catch (SQLException e) {			
				e.printStackTrace();
				return null;
			}
		}

		

		public static ArrayList<Object> startExam(ConnectionToClient client, Student student, Exam exam, String examExecutionCode)
		{
			
			return ServerWatch.addExaminee(client, student, exam, examExecutionCode, "Online");			
		}


		public static void endExam(ConnectionToClient client, String reason) {
			System.out.println("i send packet");			
			try {
				Packet packet = new Packet(reason,null);
				packet.setID(-1);
				if(client != null)	
					client.sendToClient(packet);
			} catch (IOException e) {			
				e.printStackTrace();
			}		
		
	}
		
		public static int getNumberOfExams() {		
			Statement stmt;
			ResultSet rs;
			try {
				
				stmt = Server.conn.createStatement();	
				rs = stmt.executeQuery("SELECT COUNT(*) AS NUMBEROFEXAMS FROM EXECUTEDEXAMS;");
				rs.next();
				return rs.getInt(1);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return 0;
		}
		
		
		public static HashMap<Exam,String> getActiveExams(String executorID)
		{
			HashMap<Exam,String> activeExams = new HashMap<Exam,String>();
			Statement stmt;
			ResultSet rs;	
			try {	
				stmt = Server.conn.createStatement();	
				if(executorID == null)
					rs = stmt.executeQuery("SELECT CODE, EXAM FROM ACTIVEEXAMS;");
				else
					rs = stmt.executeQuery("SELECT CODE, EXAM FROM ACTIVEEXAMS WHERE TEACHER = '"+executorID+"';");
				while(rs.next()){		
					activeExams.put(getExamByID(rs.getString(2)),rs.getString(1));
				}
				
				return activeExams;
			} catch (SQLException e) {			
				e.printStackTrace();
				return null;
			}
			
		}
		
		public static void submitExam(FinishedExam exam, Examinee examinee, String reason) {
			Statement stmt1,stmt2;
			ResultSet rs1;
			int grade=-1;
			if(exam == null)
			{
				submitEmptyExam(examinee,reason);
				return;
			}
			exam.finish();
			try {
				stmt1 = Server.conn.createStatement();
				stmt2 = Server.conn.createStatement();
				rs1 = stmt1.executeQuery("SELECT ID FROM ACTIVEEXAMS WHERE CODE='"+examinee.getExamExecutionCode()+"';");
				rs1.next();
				int ID = rs1.getInt(1);
				grade=exam.getGrade();	
				Long completionTime = (exam.getFinishTime().getTime()-exam.getStartTime().getTime())/60000;
				stmt2.executeUpdate("INSERT INTO FINISHEDEXAMS VALUES ('"+ID+"','"+exam.getID()+"','"+examinee.getID()+"','"+exam.getStartTime().toString()+"','"+exam.getFinishTime().toString()+"','"+completionTime.intValue()+"','"+reason+"','"+grade+"','-1', '"+null+"', '"+examinee.getType()+"');");
				addAnswers(ID, exam, examinee.getID());
				ServerWatch.removeExaminee(examinee);			
			} catch (SQLException e) {			
				e.printStackTrace();
			}
		}
		
		
		public static void submitEmptyExam(Examinee examinee, String reason) 
		{
			Statement stmt1,stmt2;
			ResultSet rs1;
			try {
				stmt1 = Server.conn.createStatement();
				stmt2 = Server.conn.createStatement();
				rs1 = stmt1.executeQuery("SELECT ID, EXAM FROM ACTIVEEXAMS WHERE CODE='"+examinee.getExamExecutionCode()+"';");
				rs1.next();
				int ID = rs1.getInt(1);
				int examID = rs1.getInt(2);
				stmt2.executeUpdate("INSERT INTO FINISHEDEXAMS VALUES ('"+ID+"','"+examID+"','"+examinee.getID()+"','"+examinee.getStartTime().toString()+"',"+null+",'-1','"+reason+"',0,0, '"+null+"', '"+examinee.getType()+"');");
				ServerWatch.removeExaminee(examinee);
			} catch (SQLException e) {			
				e.printStackTrace();
			}
		}
		
		
		public static void submitManualExam(ManualExamFile exam, Examinee examinee, String reason)
		{


			try {
				File file = new File ("Exams/"+exam.getexamExecutionID()+"/"+examinee.getID()+".docx");
				FileOutputStream fos;
				fos = new FileOutputStream(file);
				BufferedOutputStream bos = new BufferedOutputStream(fos);
				bos.write(exam.getMybytearray());
				bos.close();
				examinee.setFinishTime(new Date());
				Long completionTime = (examinee.getFinishTime().getTime()-examinee.getStartTime().getTime())/60000;
				Statement stmt1;						
				stmt1 = Server.conn.createStatement();									
				stmt1.executeUpdate("INSERT INTO FINISHEDEXAMS VALUES ('"+exam.getexamExecutionID()+"','"+exam.getExam().getID()+"','"+examinee.getID()+"','"+examinee.getStartTime().toString()+"','"+examinee.getFinishTime().toString()+"','"+completionTime.intValue()+"','"+reason+"',0,0, '"+null+"', '"+examinee.getType()+"');");
				ServerWatch.removeExaminee(examinee);

			} catch (Exception e) {

				e.printStackTrace();
			}

		}
		
		private static void addAnswers(int id, FinishedExam exam, String studentID) {
			Statement stmt1;
			HashMap<String,Integer> answers = exam.getAnswers();
			int answer;
			try {
				stmt1 = Server.conn.createStatement();
				for(QuestionInExam question : exam.getQuestions())
				{
					answer = answers.get(question.getID());
					stmt1.executeUpdate("INSERT INTO STUDENTSANSWERS VALUES('"+id+"','"+studentID+"','"+question.getID()+"','"+answer+"',"+null+");");
				}
			}
			catch(Exception e) {
				e.printStackTrace();
			}
		}

		public static void lockExam(String examExecutionCode)
		{
			ServerWatch.lockExam(examExecutionCode);
		}
		public static ArrayList<FinishedExam> getFinishedStudentExams(String ID){
			Statement stmt1,stmt2;
			ResultSet rs1,rs2;
			ArrayList<FinishedExam> StudentExams = new ArrayList<FinishedExam>();
			try {
				stmt1=Server.conn.createStatement();
				stmt2=Server.conn.createStatement();
				
				rs1 = stmt1.executeQuery("SELECT * FROM FINISHEDEXAMS WHERE EXAMINEE='"+ID+"';");
				while(rs1.next()) {
					Person examinee = null;
					Exam exam = getExamByID(rs1.getString(2));
					FinishedExam finishedExam = new FinishedExam(exam,rs1.getString(11));
					Date startTime =  new SimpleDateFormat("EEE MMM dd HH:mm:ss Z yyyy", new Locale("us")).parse(rs1.getString(4));
					Date finishTime =  new SimpleDateFormat("EEE MMM dd HH:mm:ss Z yyyy", new Locale("us")).parse(rs1.getString(5));
					finishedExam.setCompletionTime(rs1.getInt(6));
					finishedExam.setSubmissionType(rs1.getString(7));
					finishedExam.setGrade(rs1.getInt(8));
					finishedExam.setFinalGrade(rs1.getInt(9));
					finishedExam.setStartTime(startTime);
					finishedExam.setFinishTime(finishTime);
					finishedExam.setGradeNote(rs1.getString(10));
					rs2 = stmt2.executeQuery("SELECT ID, FIRSTNAME,LASTNAME FROM STUDENTS WHERE ID = '"+ID+"';");
					if(rs2.next())
					examinee = new Person(rs2.getString(1),rs2.getString(2)+" "+rs2.getString(3));
					finishedExam.setExaminee(examinee);
					ArrayList<Object> answersAndNotes = getAnswers(rs1.getInt(1),examinee.getID());
					finishedExam.setAnswers((HashMap<String, Integer>) answersAndNotes.get(0));
					finishedExam.setCheckedQuestionsNote((HashMap<String, String>) answersAndNotes.get(1));
					StudentExams.add(finishedExam);
					
				}
			}catch (Exception e) {
				e.printStackTrace();
				return null;
			}
			return StudentExams;
		}
		public static Person getexecutorExamByExamID(String ID) {
			Statement stmt1,stmt2;
			ResultSet rs1,rs2;
			Person executor = null;
			try {
				stmt1=Server.conn.createStatement();
				stmt2=Server.conn.createStatement();
			rs1 = stmt1.executeQuery("SELECT EXECUTOR FROM EXECUTEDEXAMS WHERE EXAM='"+ID+"';");
			while(rs1.next()) {
				rs2 = stmt2.executeQuery("SELECT FIRSTNAME FROM TEACHERS WHERE ID='"+rs1.getString(1)+"';");
				if(rs2.next()) {
					executor = new Person(rs1.getString(1),rs2.getString(1));
				}
			}
			}catch (Exception e) {
				e.printStackTrace();
				return null;
			}
			
			return executor;
			
		}
		public static HashMap<ExecutedExam,HashSet<FinishedExam>> getFinishedExamsById(String ID){
			Statement stmt1, stmt2, stmt3;
			ResultSet rs1, rs2, rs3;
			HashMap<ExecutedExam,HashSet<FinishedExam>> exams = new HashMap<ExecutedExam,HashSet<FinishedExam>>();
			try {
				stmt1=Server.conn.createStatement();
				stmt2=Server.conn.createStatement();
				
				rs1 = stmt1.executeQuery("SELECT * FROM EXECUTEDEXAMS WHERE EXECUTOR='"+ID+"' AND ID NOT IN (SELECT ID FROM ACTIVEEXAMS) ;");
				while(rs1.next()) {
					Exam exam = getExamByID(rs1.getString(3));
					Date executionDate =  new SimpleDateFormat("EEE MMM dd HH:mm:ss Z yyyy", new Locale("us")).parse(rs1.getString(4));
					ExecutedExam executedExam = new ExecutedExam(exam,rs1.getInt(1), executionDate, rs1.getString(2));
					rs2 = stmt2.executeQuery("SELECT * FROM FINISHEDEXAMS WHERE ID = "+rs1.getInt(1)+" AND TYPE='ONLINE';");
					while(rs2.next()) {
						Person examinee = null;
						FinishedExam finishedExam = new FinishedExam(exam,"Online");
						finishedExam.setExamExecutionID(rs1.getInt(1));
						Date startTime =  new SimpleDateFormat("EEE MMM dd HH:mm:ss Z yyyy", new Locale("us")).parse(rs2.getString(4));
						Date finishTime =  new SimpleDateFormat("EEE MMM dd HH:mm:ss Z yyyy", new Locale("us")).parse(rs2.getString(5));
						finishedExam.setCompletionTime(rs2.getInt(6));
						finishedExam.setSubmissionType(rs2.getString(7));
						finishedExam.setGrade(rs2.getInt(8));
						finishedExam.setFinalGrade(rs2.getInt(9));
						finishedExam.setStartTime(startTime);
						finishedExam.setFinishTime(finishTime);
						finishedExam.setGradeNote(rs2.getString(10));
						finishedExam.setType(rs2.getString(11));
						stmt3=Server.conn.createStatement();
						rs3 = stmt3.executeQuery("SELECT ID, FIRSTNAME,LASTNAME FROM STUDENTS WHERE ID = '"+rs2.getString(3)+"';");
						if(rs3.next())
							examinee = new Person(rs3.getString(1),rs3.getString(2)+" "+rs3.getString(3));
						finishedExam.setExaminee(examinee);
						ArrayList<Object> answersAndNotes = getAnswers(rs1.getInt(1),examinee.getID());
						finishedExam.setAnswers((HashMap<String, Integer>) answersAndNotes.get(0));
						finishedExam.setCheckedQuestionsNote((HashMap<String, String>) answersAndNotes.get(1));
						HashSet tempExams = exams.get(executedExam);
						if(tempExams==null) {
							tempExams = new HashSet<FinishedExam>();
							exams.put(executedExam,tempExams);
						}
						tempExams.add(finishedExam);
					}
				}
			} catch (Exception e) {
				e.printStackTrace();
				return null;
			}
			return exams;
		}
			
			
			public static ArrayList<Object> getAnswers(int examID, String examineeID){
				Statement stmt1;
				ResultSet rs1;
				ArrayList<Object> data = new ArrayList<Object>();
				HashMap<String, Integer> answers = new HashMap<String,Integer>();
				HashMap<String, String> notes = new HashMap<String,String>();
				try {
					stmt1 = Server.conn.createStatement();
					rs1 = stmt1.executeQuery("SELECT QUESTION, ANSWER, NOTE FROM STUDENTSANSWERS WHERE EXECUTEDEXAM = "+examID+" AND STUDENT = '"+examineeID+"';");
					while(rs1.next()) 
					{
						answers.put(rs1.getString(1),rs1.getInt(2));
						notes.put(rs1.getString(1), rs1.getString(3));
					}
					data.add(answers);
					data.add(notes);
					return data;
				} catch (SQLException e) {
					e.printStackTrace();
				}
				return null;
				
			}
			
			
			
			
			public static void createManualExam(int examID, String examExecutionCode)
			{
				Statement stmt;
				try {				
					File dir = new File("Exams/"+examID);
					if (!dir.exists()) 
			    		dir.mkdirs();
					File file = new File("Exams/"+examID+"/exam_"+examID+".docx");
					FileOutputStream out = new FileOutputStream(file);
					Exam exam = takeExam(examExecutionCode);
					XWPFDocument document = new XWPFDocument();
					XWPFParagraph paragraphHeader = document.createParagraph();
					paragraphHeader.setAlignment(ParagraphAlignment.CENTER);				
					XWPFRun paragraphTitleRun = paragraphHeader.createRun();		
					paragraphTitleRun.setBold(true);
					paragraphTitleRun.setFontSize(40);
					XWPFRun paragraphAuthorRun = paragraphHeader.createRun();
					paragraphAuthorRun.addBreak();				
					paragraphAuthorRun.addBreak();				
					paragraphAuthorRun.setText("Author: "+exam.getAuthor().getName());
					paragraphAuthorRun.setBold(true);
					paragraphAuthorRun.setFontSize(24);
					paragraphAuthorRun.addBreak();				
					XWPFRun paragraphDateRun = paragraphHeader.createRun();
					SimpleDateFormat formatter  = new SimpleDateFormat("dd/MM/yyyy");
					String date = formatter.format(new Date());
					paragraphDateRun.setText(date);
					paragraphDateRun.setBold(true);				
					paragraphDateRun.setFontSize(24);
					
					XWPFParagraph paragraphNote = document.createParagraph();
					paragraphNote.setAlignment(ParagraphAlignment.LEFT);
					XWPFRun paragraphNoteRun = paragraphNote.createRun();
					paragraphNoteRun.addBreak();
					paragraphNoteRun.addBreak();
					paragraphNoteRun.setText(exam.getNote());							
					paragraphNoteRun.setFontSize(16);
					XWPFRun paragraphExamTimeRun = paragraphNote.createRun();
					paragraphExamTimeRun.addBreak();
					paragraphExamTimeRun.addBreak();
					paragraphExamTimeRun.addBreak();
					paragraphExamTimeRun.setText("Exam Time: "+exam.getExamTime()+" Minutes");							
					paragraphExamTimeRun.setFontSize(16);
					
					XWPFParagraph paragraphQuestion = document.createParagraph();
					paragraphQuestion.setAlignment(ParagraphAlignment.LEFT);
					paragraphQuestion.setPageBreak(true);
					int questionNumber = 1;
					
					for (QuestionInExam question : exam.getQuestions())
					{
						char answerSign = 'a';
						XWPFRun paragraphQuestionRun = paragraphQuestion.createRun();
						paragraphQuestionRun.addBreak();
						paragraphQuestionRun.addBreak();
						String note = question.getNoteForStudent();
						
						paragraphQuestionRun.setText("Question "+questionNumber+"("+question.getScore()+" points):");
						paragraphQuestionRun.addBreak();
						if(note == null || note.equals("null"))
							paragraphQuestionRun.setText(question.getQuestion());
						else
							paragraphQuestionRun.setText(question.getQuestion()+" ("+question.getNoteForStudent()+")");
						
						paragraphQuestionRun.setBold(true);
						paragraphQuestionRun.setFontSize(16);	
						paragraphQuestionRun.addBreak();
						for(String answer : question.getAnswers()) {
							XWPFRun paragraphAnswerRun = paragraphQuestion.createRun();
							paragraphAnswerRun.setFontSize(16);
							paragraphAnswerRun.setText(answerSign+". "+answer);
							answerSign++;
							paragraphAnswerRun.addBreak();
						}

						questionNumber++;
						
					}
					
					document.write(out);
					
				} catch (Exception e) {
					e.printStackTrace();
				}
				
				
				
			}
			
			public static ArrayList<Object> takeManualExam(ConnectionToClient client, Student student, String examExecutionCode)
			{
				Statement stmt;
				ArrayList<Object> data;
				Exam exam = takeExam(examExecutionCode);
					try {
						stmt = Server.conn.createStatement();
						ResultSet rs1 = stmt.executeQuery("SELECT ID FROM ACTIVEEXAMS WHERE code = '"+examExecutionCode+"';");
						
						if(!rs1.next())
							return null;
						int ID = rs1.getInt(1);
						File file = new File("Exams/"+ID+"/exam_"+ID+".docx");
						byte [] mybytearray  = new byte [(int) file.length()];
					    FileInputStream fis = new FileInputStream(file);					   
					    BufferedInputStream bis = new BufferedInputStream(fis);			  
					    ManualExamFile manualExamFile = new ManualExamFile(file.getName());	
					    manualExamFile.setExam(exam);
					    manualExamFile.setexamExecutionID(ID);
					    manualExamFile.initArray(mybytearray.length);			  
					    bis.read(manualExamFile.getMybytearray(),0,mybytearray.length);
					    data=ServerWatch.addExaminee(client, student, exam, examExecutionCode, "Manual");
					    data.add(manualExamFile);
	  
					    return data;
						
					} catch (Exception e) {					
						e.printStackTrace();
						return null;
					}
			}
			
		
			public static void confirmExam(FinishedExam exam)
			{
				try {
					int count=0;
					float average=0;
					int median;
					int sum = 0;
					int[] deciles = new int[10];
					ArrayList<Integer> scores = new ArrayList<Integer>();
					Statement stmt = Server.conn.createStatement();
					Statement stmt2 = Server.conn.createStatement();
					stmt.executeUpdate("UPDATE FINISHEDEXAMS SET FINALGRADE = '"+exam.getFinalGrade()+"', GRADENOTE = '"+exam.getGradeNote()+"' WHERE ID ='"+exam.getExamExecutionID()+"' AND EXAMINEE = '"+exam.getExaminee().getID()+"' ;");
					HashMap <String,String> notes = exam.getCheckedQuestionsNote();
					for(String questionID : exam.getCheckedQuestionsNote().keySet())
						stmt.executeUpdate("UPDATE STUDENTSANSWERS SET NOTE = '"+notes.get(questionID)+"' WHERE EXECUTEDEXAM = '"+exam.getExamExecutionID()+"' AND STUDENT = '"+exam.getExaminee().getID()+"' AND QUESTION = '"+questionID+"';" );
					ResultSet rs1 = stmt2.executeQuery("SELECT ID FROM FINISHEDEXAMS WHERE ID = '"+exam.getExamExecutionID()+"' AND FINALGRADE = -1 AND TYPE = 'Online' ;" );
					if(rs1.next())
						return;
					PreparedStatement ps =  Server.conn.prepareStatement("INSERT INTO EXAMSSTATISTICS VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
					ResultSet rs2 = stmt2.executeQuery("SELECT FINALGRADE FROM FINISHEDEXAMS WHERE ID = '"+exam.getExamExecutionID()+"' AND TYPE = 'Online' ;");
					while(rs2.next()) {
						int score = rs2.getInt(1);
						scores.add(score);
						sum+=score;
						if(score==100)
							deciles[9]++;
						else
							deciles[score/10]++;
					}
					scores.sort(null);
					count = scores.size();
					average = sum/count;
					if(scores.size()>1)
						median = scores.get(scores.size()/2-1);
					else
						median=scores.get(0);
					
					ps.setInt(1,exam.getExamExecutionID());
					ps.setString(2,exam.getAuthor().getID());
					ps.setString(3,exam.getCourse().getID());
					ps.setFloat(4,average);
					ps.setInt(5, median);
					for(int i = 0 ; i < 10 ; i ++) {
						ps.setInt(i+6,deciles[i]);
					}
					ps.execute();
				} catch (SQLException e) {				
					e.printStackTrace();
				}
				
			}
			
			public static ArrayList<Exam> getExamsByCourse(String CourseID) {
				
				Statement stmt1, stmt2, stmt3;
				ResultSet rs1, rs2, rs3;
				ArrayList<Exam>  examsList = new ArrayList<Exam> ();
				try {
					stmt1=Server.conn.createStatement();
										
					rs1 = stmt1.executeQuery("SELECT ID FROM EXAMS WHERE COURSE='"+CourseID+"';");
					if(rs1.next()) {
								Exam exam = getExamByID(rs1.getString(1));
								examsList.add(exam);
					}
				}catch (SQLException e) {				
						e.printStackTrace();
						return null;
					}
				return examsList;
			}
			public static ArrayList<ExecutedExam> getExcutedExamsByExamId(String examid) {
				
				Statement stmt1,stmt2;
				ResultSet rs1,rs2;
				ArrayList<ExecutedExam> Exams = new ArrayList<ExecutedExam>();
				try {
					stmt1=Server.conn.createStatement();
					stmt2=Server.conn.createStatement();
					
					rs1 = stmt1.executeQuery("SELECT * FROM EXECUTEDEXAMS WHERE EXAM='"+examid+"';");
					while(rs1.next()) {
						Exam temp = getExamByID(examid);
						Date executionDate =  new SimpleDateFormat("EEE MMM dd HH:mm:ss Z yyyy", new Locale("us")).parse(rs1.getString(4));
						ExecutedExam exam = new ExecutedExam(temp,Integer.parseInt(rs1.getString(1)),executionDate,rs1.getString(2));	
						Exams.add(exam);
						
					}
				}catch (Exception e) {
					e.printStackTrace();
					return null;
				}
				return Exams;
			}
			public static  ArrayList<Exam> getExamByAuthor(String TeacherID) {
				Statement stmt1, stmt2, stmt3;
				ResultSet rs1, rs2, rs3;
				ArrayList<Exam>  examsList = new ArrayList<Exam> ();
				try {
					stmt1=Server.conn.createStatement();
					
					rs1 = stmt1.executeQuery("SELECT ID FROM EXAMS WHERE AUTHOR='"+TeacherID+"';");
					if(rs1.next()) {
								Exam exam = getExamByID(rs1.getString(1));
								examsList.add(exam);
				
						}
					} catch (SQLException e) {				
						e.printStackTrace();
						return null;
					}
				return examsList;	
			}
			
			public static ArrayList getExamDecline(int ID) {
				Statement stmt1;
				ResultSet rs1;
				ArrayList  declins = new ArrayList();
				try {
					stmt1=Server.conn.createStatement();		
					
						rs1 = stmt1.executeQuery("SELECT * FROM EXAMSSTATISTICS WHERE EXECUTEDEXAMID='"+ID+"';");
							if(rs1.next()) {
									for(int i=6;i<16;i++) {
										declins.add(Integer.parseInt(rs1.getString(i)));
									}
							}
						} catch (SQLException e) {				
							e.printStackTrace();
							return null;
						}
							return declins;	
	}
			
			
			public static String extendExamTime(ExtendTimeMessage message)
			{
				
				try {
					Statement stmt = Server.conn.createStatement();
					ResultSet rs = stmt.executeQuery("SELECT ID FROM ACTIVEEXAMS WHERE CODE = '"+message.getExamID()+"' ;");
					
					if(!rs.next())
						return "ExamNotAcitve";
					
					Integer examID = rs.getInt(1);
					ServerWatch.extendExamTime(message.getExamID(), message.getTimeExtension());
					Statement stmt1 = Server.conn.createStatement();
					stmt1.executeUpdate("UPDATE EXECUTEDEXAMS SET ALLOCATEDTIME = ALLOCATEDTIME + '"+message.getTimeExtension()+"' WHERE ID = '"+examID+"' ;" );
					stmt1.executeUpdate("DELETE FROM MANAGERREQUESTSBOX WHERE EXAMID = '"+message.getExamID()+"';");
					return "Success";
				} catch (SQLException e) {				
					e.printStackTrace();
					return "Exception";
				}
				
			}
			
			public static void extendExamineeTime(ConnectionToClient client, String reason, Integer time) {
				
				try {					
					Packet packet = new Packet(reason,time);
					packet.setID(-1);
					if(client != null)	
						client.sendToClient(packet);
				} catch (IOException e) {			
					e.printStackTrace();
				}		
			
		}
			}