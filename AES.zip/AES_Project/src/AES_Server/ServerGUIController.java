package AES_Server;

import java.net.URL;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;

public class ServerGUIController implements Initializable{


	/**==================================
	 *=Server GUI parameters========== 
	 *==================================
	 */
	Server server;
	@FXML private TextField txt_port;
	@FXML private TextField txt_address;
	@FXML private TextField txt_db_username;
	@FXML private PasswordField txt_db_password;
	@FXML private Button btn_connect;
	@FXML private Button btn_disconnect;
	@FXML private ListView<String> ListMsg;
	
	/**
	 	* This method Create connection to database
	    * In Server Controller there is option do connect data base
	    * data base connection by port , address , user name and password of the required data base
	    * there is option to change required data base by change default text fields of connection details
	    * Call server functions that connect to data base
	    * Server GUI will present if connect to client success or not and will show all client connection and Packets that receive from client
	    */
	@FXML
	public void ClickConnect(ActionEvent event) 
	{
		Thread thread = new Thread(new Runnable(){
	          
		   
			public void run(){
		              int port=Integer.parseInt(txt_port.getText());              
		              String [] databaseConnection={txt_address.getText(),txt_db_username.getText(),String.valueOf(txt_db_password.getText())}; 
		            //  System.out.println(databaseConnection[0]+"  "+databaseConnection[1]+"  "+databaseConnection[2]);
		              server = new Server(port,databaseConnection,ListMsg);
				try 
				{
					server.listen(); 
				} 
				catch (Exception ex) 
				{
					ListMsg.getItems().add("ERROR - Could not listen for clients!");					
				}
				
		      }
		      });          
		        thread.start();

		}
	/**
	 * * This method remove connection to database
	    * In Server Controller there is option do disconnect from data base
	    * Call server functions that disconnect to data base
	    * server GUI will present that disconnect Success
	    */
	@FXML
	public void ClickDisconnect(ActionEvent e) {
		server.shutDown();
		ListMsg.getItems().add("Disconnected Successfully");
	}

	/**
	 * The constructor (is called before the initialize()-method).
	 */
	@Override
	public void initialize(URL location, ResourceBundle resc) {
		// TODO Auto-generated method stub
	
	}


}