package AES_Server;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashSet;
import AES_Classes.Course;
import AES_Classes.Subject;


public class CourseAndSubjectController {
	/**
	    * This method Get from database What subject does the teacher teach 
	    * Create Statements to TEACHERSUBJECTS and TEACHER table in data base 
	    * Search in TEACHERSUBJECTS all subject by teacher id  
	    	* Create new subject by the result
	    	* add new subject to array list
	    * Return array list of subject
	     * @param ID  giving by client , this his teacher Id 
	    */
	public static HashSet<Subject> getTeacherSubjects(String ID){
		try {
			Statement stmt1 = Server.conn.createStatement();
			Statement stmt2 = Server.conn.createStatement();
			ResultSet rs = stmt1.executeQuery("SELECT S.Name, S.ID FROM TEACHERSUBJECTS TS, SUBJECTS S WHERE TEACHER='"+ID+"' AND TS.SUBJECT=S.ID ;");
			
			HashSet<Subject> ListOfSubjects = new HashSet<Subject>();
			while(rs.next())		
			{	Subject subject =new Subject(rs.getString(2),rs.getString(1));
				ListOfSubjects.add(subject);
			}						
			return ListOfSubjects;
			
		} catch (SQLException e) {			
			e.printStackTrace();
			return null;
		}
	}
	/**
	    * This method Get from database What course does the teacher teach 
	    * Create Statements to TEACHERCOURSES and TEACHER table in data base 
	    * Search in TEACHERcourseS all course by teacher id  
	    	* Create new course by the result
	    	* add new course to array list
	    * Return array list of course
	     * @param ID  giving by client , this his teacher Id 
	    */
	public static HashSet<Course> getTeacherCourses(String ID){
		try {
			Statement stmt1 = Server.conn.createStatement();
			Statement stmt2 = Server.conn.createStatement();
		
			ResultSet rs = stmt1.executeQuery("SELECT C.ID, C.Name, C.Subject FROM TEACHERCOURSES TC, COURSES C WHERE TC.TEACHER='"+ID+"' AND TC.COURSE= C.ID ;");
			
			HashSet<Course> ListOfCourses = new HashSet<Course>();
			while(rs.next())
			{				
				Course course =new Course(rs.getString(1),rs.getString(2),rs.getString(3));
				ListOfCourses.add(course);
			}			
			
			return ListOfCourses;
			
		} catch (SQLException e) {	
			System.out.println(e);
			e.printStackTrace();
			return null;
		}
	}
	public static ArrayList<Course> getCoursesList(){
		try {
			Statement stmt = Server.conn.createStatement();
			ResultSet rs1 = stmt.executeQuery("SELECT * FROM COURSES;");
			ArrayList<Course> arrayListOfCourses = new ArrayList<Course>();
			while(rs1.next())
			{
				Course course = new Course(rs1.getString(1),rs1.getString(3),rs1.getString(2));
				arrayListOfCourses.add(course);
			}
			
			return arrayListOfCourses;
			
		} catch (SQLException e) {			
			e.printStackTrace();
			return null;
		}
					
	}
	 public static ArrayList<Subject> getAllSubjects(){
			try {
				Statement stmt = Server.conn.createStatement();
				ResultSet rs1 = stmt.executeQuery("SELECT * FROM SUBJECTS;");
				ArrayList<Subject> arrayListOfSubjectes = new ArrayList<Subject>();
				while(rs1.next())
				{
					Subject subject = new Subject(rs1.getString(1),rs1.getString(2));
					arrayListOfSubjectes.add(subject);
				}
				
				return arrayListOfSubjectes;
				
			} catch (SQLException e) {			
				e.printStackTrace();
				return null;
			}		
	 }
	 public static String getIdSubjectByName(String name)
		{
			try {
				String idOfSubject = null;
				Statement stmt1 = Server.conn.createStatement();			
				ResultSet rs = stmt1.executeQuery("SELECT * FROM SUBJECTS WHERE NAME='"+name+"';");
				
				while(rs.next())
				{				
					idOfSubject = rs.getString(1);
				}			
				
				return idOfSubject;
				
			} catch (SQLException e) {	
				System.out.println(e);
				e.printStackTrace();
				return null;
			}
		}

						
}
