package AES_Server;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

import AES_Classes.ExtendTimeMessage;
import AES_Classes.Message;
import AES_Classes.Person;

public class MessageController {

	
	public static String requestTimeExtension(ExtendTimeMessage message)                 
	{
		
		try {
			
			Statement stmt = Server.conn.createStatement();
			Statement stmt1 = Server.conn.createStatement();
			
			ResultSet rs = stmt1.executeQuery("SELECT * FROM ACTIVEEXAMS WHERE CODE = '"+message.getExamID()+"';");
			if(rs.next())
			{			
			stmt.executeUpdate("DELETE FROM MANAGERREQUESTSBOX WHERE EXAMID = '"+message.getExamID()+"';");
			PreparedStatement ps=Server.conn.prepareStatement("INSERT INTO MANAGERREQUESTSBOX VALUES (?,?,?,?,?);");	
			ps.setInt(1, message.getExamID());
			ps.setString(2, message.getSender().getID());
			ps.setString(3, message.getMessage());
			ps.setInt(4, message.getTimeExtension());
			ps.setString(5, message.getDate().toString());
			ps.execute();
			return "Success";
			}
			return "NoExamFound";
			
		} catch (SQLException e) {			
			e.printStackTrace();
			return "Exception";
		}
	}
	
	
	public static ArrayList<ExtendTimeMessage> receiveRequests()
	{
		
		try {
			Statement stmt = Server.conn.createStatement();
			Statement stmt1 = Server.conn.createStatement();
			ResultSet rs2;
			ArrayList<ExtendTimeMessage> messages = new ArrayList<ExtendTimeMessage>();			
			Person sender;						
			Date date;
			ExtendTimeMessage message;
			ResultSet rs = stmt.executeQuery("SELECT * FROM MANAGERREQUESTSBOX ;");
			while(rs.next())			{
				
				rs2 = stmt1.executeQuery("SELECT FIRSTNAME, LASTNAME FROM TEACHERS WHERE ID = '"+rs.getString(2)+"' ;");
				if(!rs2.next())
					return null;
				sender = new Person(rs.getString(2),rs2.getString(1)+" "+rs2.getString(2));
				date =  new SimpleDateFormat("EEE MMM dd HH:mm:ss Z yyyy", new Locale("us")).parse(rs.getString(5));				
				message = new ExtendTimeMessage(new Message(sender,rs.getString(3)),rs.getInt(1),rs.getInt(4));
				message.setDate(date);
				messages.add(message);
			}
				
				return messages;
			
		} catch (Exception e) {		
			e.printStackTrace();
			return null;
		}
	}
	
	public static void removeRequest(ExtendTimeMessage message) {
		try {
			Statement stmt = Server.conn.createStatement();			
			stmt.executeUpdate("DELETE FROM MANAGERREQUESTSBOX WHERE EXAMID = '"+message.getExamID()+"';");
		} catch (Exception e) {		
			e.printStackTrace();
		}
	}
	
	
	
}
