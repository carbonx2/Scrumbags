package Client;

import java.util.ArrayList;

import Classes.Packet;
import Classes.Question;
import ClientGui.MainClient;

public class QuestionController {

public static ArrayList<Question> getQuestionList()
{
	int ID=MainClient.client.sendToServerAJ(new Packet("GetQuestionsList",null));
	return (ArrayList<Question>) MainClient.client.getResponse(ID).getData();
}
public static ArrayList<Question> getQuestionListBySubject(String Sid)
{
	int ID=MainClient.client.sendToServerAJ(new Packet("GetQuestionListBySubject",Sid));
	return (ArrayList<Question>) MainClient.client.getResponse(ID).getData();
}
public static ArrayList<Question> getQuestionByID(String Qid)
{
	int ID=MainClient.client.sendToServerAJ(new Packet("getQuestionByID",Qid));
	return (ArrayList<Question>) MainClient.client.getResponse(ID).getData();
}
public static void AddQuestion(Question question)
{
	int requestID = MainClient.client.sendToServerAJ(new Packet("AddQuestion",question));	 
	MainClient.client.getResponse(requestID);	
}
public static void DeleteQuestion(String Qid)
{
	int requestID = MainClient.client.sendToServerAJ(new Packet("RemoveQuestion",Qid));	
	MainClient.client.getResponse(requestID);
	
}
public static void updateCorrectAnswer(String ID,int indexNumber)
{
	ArrayList arrayList = new ArrayList();
	arrayList.add(ID);
	arrayList.add(indexNumber);
	int requestID = MainClient.client.sendToServerAJ(new Packet("UpdateAnswer",arrayList));
	MainClient.client.getResponse(requestID);
}
	
}