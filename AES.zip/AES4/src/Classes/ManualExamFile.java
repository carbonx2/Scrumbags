package Classes;

import java.io.Serializable;

public class ManualExamFile implements Serializable {

	private String Description=null;	
	private int examExecutionID;
	private Exam exam;
	private String fileName=null;	
	private int size=0;
	public  byte[] mybytearray;
	

	public Exam getExam() {
		return exam;
	}

	public void setExam(Exam exam) {
		this.exam = exam;
	}

	public int getexamExecutionID() {
		return examExecutionID;
	}

	public void setexamExecutionID(int examExecutionID) {
		this.examExecutionID = examExecutionID;
	}

	
	
	public void initArray(int size)
	{
		mybytearray = new byte [size];
		this.size = size;
	}
	
	public ManualExamFile(String fileName) {
		this.fileName = fileName;
		
	}
	
	
	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	
	public int getSize() {
		return size;
	}

	public void setSize(int size) {
		this.size = size;
	}

	public byte[] getMybytearray() {
		return mybytearray;
	}
	
	public byte getMybytearray(int i) {
		return mybytearray[i];
	}

	public void setMybytearray(byte[] mybytearray) {
		
		for(int i=0;i<mybytearray.length;i++)
		this.mybytearray[i] = mybytearray[i];
	}

	public String getDescription() {
		return Description;
	}

	public void setDescription(String description) {
		Description = description;
	}	
}


	
	

