package Classes;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;

import javafx.collections.ObservableList;

public class Exam implements Serializable {
	private String ID;
	private Course course;
	private Subject subject;
	private Person author;
	private String creationDate;
	private ArrayList<QuestionInExam> questions;
	private int examTime;
	private String note;

	public Exam(String ID, Course course, Subject subject, Person author, String creationDate, int examTime) {
		super();
		this.ID = ID;
		this.course = course;
		this.subject = subject;
		this.author = author;
		this.creationDate = creationDate;
		this.examTime = examTime;
		this.questions = new ArrayList<QuestionInExam>();
	}

	public Exam(String ID, Course course, Subject subject, Person author, String creationDate,
			ArrayList<QuestionInExam> questions, int examTime) {
		this(ID, course, subject, author, creationDate, examTime);
		this.questions = questions;
	}
	
	public Exam(Exam exam) {
		this(exam.getID(),exam.getCourse(),exam.getSubject(),exam.getAuthor(),exam.getCreationDate(), exam.getQuestions(),exam.getExamTime());
	}
	
	public void setExamTime(int examTime) {
		this.examTime=examTime;
	}

	public String getID() {
		return ID;
	}
	

	public Course getCourse() {
		return course;
	}

	public Subject getSubject() {
		return subject;
	}

	public Person getAuthor() {
		return author;
	}

	public String getCreationDate() {
		return creationDate;
	}

	public ArrayList<QuestionInExam> getQuestions() {
		return questions;
	}

	public int getExamTime() {
		return examTime;
	}

	public void setNote(String note) {
		this.note = note;
	}
	
	public String getNote() {
		return note;
	}

	public void addQuestion(Question question, int score) {
		questions.add(new QuestionInExam(question, score));
	}
	
	public void setQuestions(ObservableList<QuestionInExam> questions)
	{
		for(QuestionInExam question:questions)
			this.questions.add(question);
	}

	public String toString() {
		StringBuilder questionSB = new StringBuilder();
		for (QuestionInExam question : questions)
			questionSB.append(question + ", score(" + question.getScore() + ")\n");
		return "ID(" + ID + "), course(" + course + "), subject(" + subject + "), author(" + author + "), creationDate("
				+ creationDate + "), examTime(" + examTime + ") \nNote: "+note+"\nquestions:\n" + questionSB + " \n";

	}
}
