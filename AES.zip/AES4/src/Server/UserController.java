



package Server;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashSet;
import Classes.Course;
import Classes.Permission;
import Classes.Student;
import Classes.Subject;
import Classes.Teacher;
import Classes.User;
import ocsf.server.ConnectionToClient;

public class UserController {

public static ArrayList<Object> logIn(String ID, String password, ConnectionToClient client)
	{
	User user = null;
	ArrayList<Object> arrayList = new ArrayList<Object>();
	String answer = "Failure";
	
	
		try {
			Statement stmt1= Server.conn.createStatement();
			Statement stmt2=Server.conn.createStatement();		
			ResultSet rs=stmt1.executeQuery("SELECT * FROM USERS WHERE ID='"+ID+"' AND Password='"+password+"' ;");	
			
			
			if(rs.next()) {		
				if(!ServerWatch.addUser(ID, client))
				{
					answer = "AlreadyLoggedIn";
					arrayList.add(answer);
					arrayList.add(user);
					return arrayList;
				}
				ResultSet rs1;				
				switch (rs.getString(3))
				{
				case "1":					
					rs1=stmt2.executeQuery("SELECT * FROM STUDENTS WHERE ID='"+ID+"';");
					if(rs1.next()) {
						answer = "Sucsses"	;
					 user = new Student(rs.getString(1),rs.getString(2),rs1.getString(2),rs1.getString(3));
					}				
					break;
					
				case "2":
					rs1=stmt2.executeQuery("SELECT * FROM TEACHERS WHERE ID='"+ID+"';");
					if(rs1.next()) {
						answer = "Sucsses"	;
						 user = new Teacher(rs.getString(1),rs.getString(2),rs1.getString(2),rs1.getString(3),CourseAndSubjectController.getTeacherSubjects(ID),CourseAndSubjectController.getTeacherCourses(ID));
					}
					break;	
				/*case "3":
					rs1=stmt2.executeQuery("SELECT * FROM SCHOOLMENGERS WHERE ID='"+ID+"';");
					if(rs1.next()) {
						answer = "Sucsses"	;
						user = new SchoolManger(rs.getString(1),rs.getString(2),rs1.getString(2),rs1.getString(3));
					}
					break;	*/
				}
						
				
				
				}
			arrayList.add(answer);
			arrayList.add(user);
			return arrayList;
			
		} 
			
			catch (SQLException e) {
				e.printStackTrace();
				
				return null;		}
		
	}
	


	public static void logOut(String useID)
	{ 
		
			ServerWatch.removeUser(useID);		
		
		
	}
	
	

}
