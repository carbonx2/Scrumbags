package ClientGui;

import java.io.IOException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.ResourceBundle;

import Classes.Exam;
import Classes.Examinee;
import Classes.FinishedExam;
import Classes.QuestionInExam;
import Client.ExamController;
import javafx.application.Platform;
import javafx.beans.binding.Bindings;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Insets;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Pagination;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;

public class ExamWindowController implements Initializable {
	 	FinishedExam finishedExam;
	    @FXML
	    private Pagination pagination;
	    @FXML
	    private Label RemainingTimeLabel;
	    public static final int itemsPerPage = 4;
		public ArrayList<QuestionInExam> questionsInExam;
		private ArrayList<ExamFormPageController> pagesList;
		private ArrayList<VBox> layoutList;
		@FXML
	    private AnchorPane OurAnchorPane;	
	    @FXML
	    private Button SubmitButton;
		private Examinee examinee;
		private Node firstPageLayout;
		private ExamFirstPageController firstPageController;
		private ArrayList<ExamQuestionPaneController> questionsControllers;
		private Exam exam;
		String examCode;
	    private TakeExamMainPageController takeExamMainPageController;
		
		
	    
	    
	    public void submitExamListener()
	    {
	    	takeExamMainPageController.submitExam();
	    }
	    
	    public void enableSubmitButton()
	    {
	    	takeExamMainPageController.enableSubmitButton();
	    }
	    
	    public void submitExam(String reason, String message) {
	    	HashMap<String,Integer> answers = new HashMap<String,Integer>();
			for(int i = 0 ; i<questionsControllers.size(); i++) {
	    		answers.put(questionsControllers.get(i).getQuestion().getID(),	questionsControllers.get(i).getSelectedAnswer());  	    		
	    	}
			finishedExam.setAnswers(answers);
	    	ExamController.submitExam(finishedExam, examinee, reason);
	    	closeWindow(message,"The exam has been submitted");
	    	
	    	
	    
	    }
	    
	    public void setRemainingTime(Long remainingTime)
	    {	    	
	    	Platform.runLater(new Runnable(){

				@Override
				public void run() {
					if((remainingTime*1.0)/exam.getExamTime()<=0.5)
						RemainingTimeLabel.setStyle("-fx-background-color: orange;");
					if((remainingTime*1.0)/exam.getExamTime()<0.2)
						RemainingTimeLabel.setStyle("-fx-background-color: red;");
					
					RemainingTimeLabel.setText("Remaining Time: "+remainingTime +" Minutes");					
				}	    		
	    	});
	    }
	    
	    public void alert(String title, String message)
		{
	    	
			Alert alert = new Alert(AlertType.INFORMATION);
			alert.setTitle(title);
			alert.setHeaderText(null);
			alert.setContentText(message);
			alert.showAndWait();
			}
	        
	    
	    public void setExamFinishTime(Date finishTime)
	    {
	    	takeExamMainPageController.setExamFinishTime(finishTime);
	    }
	    
	    public void setTakeExamPageController(TakeExamMainPageController takeExamMainPageController)
	    {
	    	this.takeExamMainPageController = takeExamMainPageController;
	    }
	    
	    
		public void setQuestionsInExam(ArrayList<QuestionInExam> questionsInExam) {
			this.questionsInExam = questionsInExam;
			pagination.setPageCount(1);	
			initPages();
		}
		
		public void closeWindow(String reason , String message)
		{
			Platform.runLater(new Runnable(){

				@Override
				public void run() {
					
					alert(reason,message);
					pagination.getScene().getWindow().hide();
					takeExamMainPageController.closeWindow();
					
					
				}
				
			});
			
		}
		
		public ArrayList<ExamQuestionPaneController> getExamQuestionsControllers()
		{
			return questionsControllers;
		}
		
		public void setExam(Exam exam) {			
			this.exam = exam;
			this.questionsInExam = exam.getQuestions();
			initFirstPage();
		}
		public void setExamCode(String examCode)
		{
			this.examCode = examCode;
		}
		
		public ArrayList<ExamFormPageController> getPagesList()
		{
			return pagesList;
		}
		
		public ArrayList<QuestionInExam> getExamQuestions()
		{
			return questionsInExam;
		}
	    
	    public ScrollPane createPage(int pageIndex) {
	    		
			try {
				ScrollPane scrollPane = new ScrollPane();
				scrollPane.getStylesheets().add("FixScrollbar.css");
				scrollPane.setStyle("-fx-background-color:white");
				if (pageIndex == 0) {			
										
					scrollPane.setContent(firstPageLayout);
					return scrollPane;
				}
		
				scrollPane.setContent(layoutList.get(pageIndex-1));				
				return scrollPane;
			} catch (Exception e) {
				e.printStackTrace();			
				return null;
			}
		}

		public void setPageCount() {			
			if (questionsInExam.size() % itemsPerPage == 0)
				pagination.setPageCount(questionsInExam.size() / itemsPerPage + 1);

			else
				pagination.setPageCount(questionsInExam.size() / itemsPerPage + 2);
			initPages();
			

		}
		
		public void setExaminee(Examinee examinee) {
			this.examinee=examinee;
			finishedExam = new FinishedExam(exam,"Online");
			finishedExam.setStartTime(examinee.getStartTime());
		}
		
		public void initFirstPage()
		{
			FXMLLoader loader = new FXMLLoader();
			try {
				firstPageLayout = loader.load(getClass().getResource("/ClientGui/ExamFirstPage.fxml").openStream());						
				firstPageController = loader.getController();	
				firstPageController.setExamWindowController(this);
				firstPageController.setExamFirstPage(exam);
				firstPageController.setExamCode(examCode);				 					
				
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	    
		
		public void initPages() {
			FXMLLoader loader = new FXMLLoader();			
			for(int pageIndex=0;pageIndex<pagination.getPageCount()-1;pageIndex++) {
				VBox box = new VBox();
				for(int i = 0; i < itemsPerPage && (pageIndex)*4+i<questionsInExam.size() ; i++) {
					try {
						loader = new FXMLLoader();
						Node questionLayout = loader.load(getClass().getResource("/ClientGui/ExamQuestionPane.fxml").openStream());	
						ExamQuestionPaneController controller = loader.getController();	
						controller.setQuestion(questionsInExam.get((pageIndex)*4+i), (pageIndex)*4+i+1);
						questionsControllers.add(controller);
						box.getChildren().add(questionLayout);
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
				box.setStyle("-fx-background-color:white;");
				box.setPadding(new Insets(0,0,0,20));
				layoutList.add(box);
				
			}
		}

	    
	    
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		pagination.setPageFactory((Integer pageIndex) -> createPage(pageIndex));
		firstPageController = null;
		firstPageLayout = null;		;
		layoutList = new ArrayList<VBox>();	
		questionsControllers = new ArrayList<ExamQuestionPaneController>();		
		
		
		
	}

}
