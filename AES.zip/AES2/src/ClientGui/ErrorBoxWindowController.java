package ClientGui;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;

public class ErrorBoxWindowController {

    @FXML
    private Label MessageLabel;

    @FXML
    private Button OkButton;
    
    
    
    public void setMessage(String message)
    {
    	MessageLabel.setText(message);
    }
    
    
    public void okButtonListener()
    {
    	OkButton.getScene().getWindow().hide();
    }

}
