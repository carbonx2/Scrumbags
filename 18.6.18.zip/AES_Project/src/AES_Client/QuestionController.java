package AES_Client;

import java.util.ArrayList;

import AES_Classes.Packet;
import AES_Classes.Question;
import ClientGUI.MainClient;

public class QuestionController {

/**
  * This method get list of question from Data base
  *
  * Build packet with GetQuestionsList request
  * Send this packet to server by client 
  * @return list of question in the data base
*/
public static ArrayList<Question> getQuestionList()
{
	int ID=MainClient.client.sendToServerAJ(new Packet("GetQuestionsList",null));
	return (ArrayList<Question>) MainClient.client.getResponse(ID).getData();
}
/**
 * This method get list of question from Data base by the subject id
 *
 * Build packet with GetquestionsList request and subject id
 * Send this packet to server by client 
 * @return list of question in the data base by the selected subject id
 */
public static ArrayList<Question> getQuestionListBySubject(String Sid)
{
	int ID=MainClient.client.sendToServerAJ(new Packet("GetQuestionListBySubject",Sid));
	return (ArrayList<Question>) MainClient.client.getResponse(ID).getData();
}
/**
 * This method get list of question from Data base by the question id
 *
 * Build packet with GetquestionsList request and subject id
 * Send this packet to server by client 
 * @return list of question in the data base by the selected question id
 */
public static ArrayList<Question> getQuestionByID(String Qid)
{
	int ID=MainClient.client.sendToServerAJ(new Packet("getQuestionByID",Qid));
	return (ArrayList<Question>) MainClient.client.getResponse(ID).getData();
}
/**
 * This method adding question to Data base
 *
 * @param question The question we want to add
 * Build packet with the question and AddQuestion request
 * Send this packet to server by client 
 * send response of request to client
 */
public static void AddQuestion(Question question)
{
	int requestID = MainClient.client.sendToServerAJ(new Packet("AddQuestion",question));	 
	MainClient.client.getResponse(requestID);	
}
/**
 * This method removing question from Data base
 *
 * @param Qid The question id we want to remove
 * Build packet with the question and RemoveQuestion request
 * Send this packet to server by client 
 * Send response of request to client
 */
public static void DeleteQuestion(String Qid)
{
	int requestID = MainClient.client.sendToServerAJ(new Packet("RemoveQuestion",Qid));	
	MainClient.client.getResponse(requestID);
	
}
/**
 * This method update Correct Answer in question
 *
 * @param ID  The question id we want to update
 * @param indexNumber the correct answer to update
 * Build packet with the question id , correct answer and UpdateAnswer request
 * Send this packet to server by client 
 * send response of request to client
 */
public static void updateCorrectAnswer(String ID,int indexNumber)
{
	ArrayList arrayList = new ArrayList();
	arrayList.add(ID);
	arrayList.add(indexNumber);
	int requestID = MainClient.client.sendToServerAJ(new Packet("UpdateAnswer",arrayList));
	MainClient.client.getResponse(requestID);
}
	
}
