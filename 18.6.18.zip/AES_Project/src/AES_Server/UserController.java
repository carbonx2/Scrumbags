package AES_Server;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashSet;

import AES_Classes.Course;
import AES_Classes.Permission;
import AES_Classes.SchoolManger;
import AES_Classes.Student;
import AES_Classes.Subject;
import AES_Classes.Teacher;
import AES_Classes.User;
import OCSF.Server.ConnectionToClient;

public class UserController {

	/**
	 * This method return list to login controller
	    * Receive from client request to log in with user details : Id , password and IP of client 
	    * will check in data base if user exist and return a arratList accordingly , The arraylist will be an answer and an object
	    * * if exist, will return to client new user depending on the type of user and success in answer 
	    * * if not exist ,will return client failure answer only  	    
	    */
	public static ArrayList<Object> logIn(String ID, String password, ConnectionToClient client)
	{
		User user = null;
		ArrayList<Object> arrayList = new ArrayList<Object>();
		String answer = "Failure";
		
	
	
		try {
			Statement stmt1= Server.conn.createStatement();
			Statement stmt2=Server.conn.createStatement();		
			ResultSet rs=stmt1.executeQuery("SELECT * FROM USERS WHERE ID='"+ID+"' AND Password='"+password+"' ;");	
			
			
			if(rs.next()) {		
				if(!ServerWatch.addUser(ID, client))
				{
					answer = "AlreadyLoggedIn";
					arrayList.add(answer);
					arrayList.add(user);
					return arrayList;
				}
				ResultSet rs1;				
				switch (rs.getString(3))
				{
				case "1":					
					rs1=stmt2.executeQuery("SELECT * FROM STUDENTS WHERE ID='"+ID+"';");
					if(rs1.next()) {
						answer = "Sucsses"	;
					 user = new Student(rs.getString(1),rs.getString(2),rs1.getString(2),rs1.getString(3));
					}				
					break;
					
				case "2":
					rs1=stmt2.executeQuery("SELECT * FROM TEACHERS WHERE ID='"+ID+"';");
					if(rs1.next()) {
						answer = "Sucsses"	;
						 user = new Teacher(rs.getString(1),rs.getString(2),rs1.getString(2),rs1.getString(3),CourseAndSubjectController.getTeacherSubjects(ID),CourseAndSubjectController.getTeacherCourses(ID));
					}
					break;		
				case "3":
					rs1=stmt2.executeQuery("SELECT * FROM SCHOOLMENGERS WHERE ID='"+ID+"';");
					if(rs1.next()) {
						answer = "Sucsses"	;
						user = new SchoolManger(rs.getString(1),rs.getString(2),rs1.getString(2),rs1.getString(3));
					}
					break;	
				}
						
				
				
				}
			arrayList.add(answer);
			arrayList.add(user);
			return arrayList;
			
		} 
			
			catch (SQLException e) {
				e.printStackTrace();
				
				return null;		}
		
	}
	
	/**
	 * Receive from client request to log out with user details : Id 
	 * will delete the user from data base 	    
	 */
	public static void logOut(String userID)
	{ 		
		ServerWatch.removeUser(userID);				
		
		
	}
	
	

}
