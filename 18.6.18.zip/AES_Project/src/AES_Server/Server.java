package AES_Server;

import java.awt.List;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import AES_Classes.Packet;
import OCSF.Server.AbstractServer;
import OCSF.Server.ConnectionToClient;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.scene.control.ListView;

public class Server extends AbstractServer {

	/**==================================
	 *=Server parameters========== 
	 *==================================
	 */
	final public static int DEFAULT_PORT = 5556;
	public static Connection conn=null;
	ExecutorService pool;
	String[] databaseConnection;
	@FXML ListView<String> messages;
	
	/**
	 *  * Constructs an instance of the server
	   *  This method Call to connect database.
	   * @param databaseConnection connection by port , address , user name and password of the required data base
	   * @param msg GUI Server will display message about connection	   
	   */

	public Server(int port,String[] databaseConnection,ListView<String> msg) {
		super(port);
		this.messages=msg;
		Platform.runLater(new Runnable() {
		@Override
		public void run() {
		pool=Executors.newCachedThreadPool();
		connectToDatabase(databaseConnection);
		    }
		});	
	}
	/**
	   * This method handles any messages received from the client.
	   * Will send a specific request Packet to the server for execution 
	   * GUI server will display that client send packet
	   * @param msg The request received from the client.
	   * @param client The connection from which the message originated.
	   */

	@Override
	protected void handleMessageFromClient(Object msg, ConnectionToClient client) {
		// TODO Auto-generated method stub
		
		System.out.println("Packet received from: "+client);
		messages.getItems().add("Packet received from: "+client);
		
		 pool.execute(new Runnable() {
			public void run()
			{	
				try {	
					
					PacketHandler.handlePacket((Packet)msg,client);
				} catch (Exception e) {
					e.printStackTrace();
					messages.getItems().add(e.getMessage());
				}
			}
		});
	}
	/**
	   * This method Connect to data base
	   * Will send a specific request Packet to the server for execution 
	   * GUI server will display that client send packet
	   * Get SQL driver for connection
	   * GUI server display if connection succeed
	   * @param databaseConnection connect details : databaseConnection[0]=address , databaseConnection[1]=user name , databaseConnection[2] = password
	   */
	
	public void connectToDatabase(String[] databaseConnection) {
		// TODO Auto-generated method stub
		this.databaseConnection=databaseConnection;
		Platform.runLater(new Runnable() {
			@Override
			public void run() {
		
		try 
		{
		  Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
		  
		} catch (Exception ex) {
			try {
				close();
				messages.getItems().add(ex.getMessage());
			} catch (IOException e) {				
				e.printStackTrace();
			}
		}
		try 	
		{			
			//conn = DriverManager.getConnection("jdbc:mysql://localhost/aes?serverTimezone=UTC&useSSL=false","root","braude");			
			conn = DriverManager.getConnection(databaseConnection[0],databaseConnection[1],databaseConnection[2]);
			System.out.println("SQL connection succeed");
			messages.getItems().add("SQL connection succeed");
		} 
		catch (SQLException ex) 
		{
			System.out.println("SQLException: " + ex.getMessage());
			System.out.println("SQLState: " + ex.getSQLState());
			System.out.println("VendorError: " + ex.getErrorCode());
			messages.getItems().add(ex.getMessage());
			try {
				close();
				conn.close();
			} catch (Exception e) {				
				e.printStackTrace();
			}
		}	
			}
		});
}
	/**
	 *  This method display that server start listening for connections
	 *  Called By client side to connect
	 *  GUI server will display that Server start listening to port 
	 */

protected void serverStarted()
	{
		Platform.runLater(new Runnable() {
			@Override
			public void run() {
	    System.out.println("Server listening for connections on port " + getPort());
	    messages.getItems().add("Server listening for connections on port " + getPort());
			}
		});		
	}

/**
 *  This method display that server stops listening for connections
 *  Called By client side to disconnect
 *  GUI server will display that Server stop listening to port
 */

protected void serverStopped()	{
	Platform.runLater(new Runnable() {
		@Override
		public void run() {
		System.out.println("Server has stopped listening for connections.");
		messages.getItems().add("Server has stopped listening for connections.");
		}
	});
}

/**
 * This method display that server has been connected
 * Called By client side to connect
 * * GUI server will display that Server start listening to
 */
protected void clientConnected(ConnectionToClient client) {
		Platform.runLater(new Runnable() {
			@Override
			public void run() {
		System.out.println("This client has been connected: "+client);
		messages.getItems().add("This client has been connected: "+client);
			}
		});
	}
/**
 * This method display that server has been disconnected
 * Called By client side to disconnect
 * * GUI server will display that Server stop listening to
 */
synchronized protected void clientDisconnected(ConnectionToClient client){
	Platform.runLater(new Runnable() {
		@Override
		public void run() {
			System.out.println("This client has been disconnected: "+client);
			messages.getItems().add("This client has been disconnected: "+client);
		}
	});
}
/**
 * This method close connection to data base
 * This method Called By client side to disconnect
 */
public void shutDown(){
	Platform.runLater(new Runnable() {
		@Override
		public void run() {
		 try { 
			 close();
			conn.close();			
		} catch (Exception e) {		
			e.printStackTrace();
			messages.getItems().add(e.getMessage());
		}
		}
	});
}
}
