package AES_Classes;

import java.io.Serializable;
import java.net.URL;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.ResourceBundle;


import javafx.fxml.Initializable;

public class FinishedExam extends Exam implements Serializable  {
	
	private Date startTime;
	private Date finishTime;
	private HashMap<String, Integer> answers;
	private String type;
	private int grade;
	private String submissionType;
	private int completionTime;
	private int finalGrade;
	private Person examinee;
	
	public FinishedExam(Exam exam, String type) {
		super(exam);
		answers = new HashMap<String, Integer>();
		startTime = new Date();
		this.type=type;
	}
	public String getSubmissionType() {
		return submissionType;
	}

	public void setSubmissionType(String submissionType) {
		this.submissionType = submissionType;
	}

	public int getCompletionTime() {
		return completionTime;
	}

	public void setCompletionTime(int completionTime) {
		this.completionTime = completionTime;
	}

	public int getFinalGrade() {
		return finalGrade;
	}

	public void setFinalGrade(int finalGrade) {
		this.finalGrade = finalGrade;
	}

	public Person getExaminee() {
		return examinee;
	}

	public void setExaminee(Person examinee) {
		this.examinee = examinee;
	}

	public void setFinishTime(Date finishTime) {
		this.finishTime = finishTime;
	}

	public void finish() {
		finishTime = new Date();
		if(type.equals("Online"))
			calculateGrade();

	}

	public HashMap<String, Integer> getAnswers() {
		return answers;
	}

	public void setAnswers(HashMap<String, Integer> answers) {
		this.answers = answers;
	}

	public Date getFinishTime() {
		return finishTime;

	}


	public Date getStartTime() {
		return startTime;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public int getGrade() {
		return grade;
	}

	public void setGrade(int grade) {
		this.grade = grade;
	}
	
	public void calculateGrade() {
		ArrayList<QuestionInExam> questions = this.getQuestions();		
		int score=0;
		for(QuestionInExam question:questions) {
			score+= answers.get(question.getID())==question.getCorrectAnswerIndex() ? question.getScore():0;
		}
		
		this.grade=score;
	}

	public void setStartTime(Date startTime) {
		this.startTime=startTime;
		
	}

	@Override
	public String toString() {
		return "FinishedExam [startTime=" + startTime + ", finishTime=" + finishTime + ", answers=" + answers
				+ ", type=" + type + ", grade=" + grade + ", submissionType=" + submissionType + ", completionTime="
				+ completionTime + ", finalGrade=" + finalGrade + ", examinee=" + examinee + "]";
	}
}
