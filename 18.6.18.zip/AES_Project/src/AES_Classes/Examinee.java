package AES_Classes;

import java.io.Serializable;
import java.util.Date;


public class Examinee extends Student implements Serializable, Comparable {
	
	Exam exam;
	String examExecutionCode;
	Date startTime;
	Date finishTime;
	String type;
	/**
	 * This method Create new Student that take exam
	 * @param student The student who doing the exam
	 * @param exam  what exam is examine
	 * @param examExecutionCode  teacher code for take exam by student
	 * @param startTime when student start exam
	 * @param finishTime when student end the exam.
	 */
	public Examinee(Student student, Exam exam, String examExecutionCode, Date startTime, Date finishTime) {
		super(student);
		this.exam = exam;
		this.examExecutionCode = examExecutionCode;
		this.startTime = startTime;
		this.finishTime = finishTime;			
	}
	public String getType() {
		return type;
	}



	public void setType(String type) {
		this.type = type;
	}

	/**
	 * @return finishTime This method Return Date when  student end the exam 
	 */
	public Date getFinishTime() {
		return finishTime;
	}
	/**
	 * @return exam This method Return the exam the student take 
	 */
	public Exam getExam() {
		return exam;
	}
	/**
	 * This method Set exam that student take 
	 */
	public void setExam(Exam exam) {
		this.exam = exam;
	}
	/**
	 * @return examExecutionCode This method Return the code to execute exam 
	 */
	public String getExamExecutionCode() {
		return examExecutionCode;
	}
	/**
	 *This method Set the code to execute exam 
	 */
	public void setExamExecutionCode(String examExecutionCode) {
		this.examExecutionCode = examExecutionCode;
	}
	/**
	 * @return startTime This method Return Date when student start the exam 
	 */
	public Date getStartTime() {
		return startTime;
	}
	/**
	 *This method Set Date when student start the exam 
	 */
	public void setStartTime(Date startTime) {
		this.startTime = startTime;
	}
	/**
	 *This method Set Date when student end the exam 
	 */
	public void setFinishTime(Date finishTime) {
		this.finishTime = finishTime;
	}
	/**
	 *This method compare the exam finish time to time student really end exam
	 **@return returns positive number  
	 ** @return negative number  
	 **@return 0  
	 */
	@Override
	public int compareTo(Object o) {
		return this.finishTime.compareTo(((Examinee) o).getFinishTime());
	}}