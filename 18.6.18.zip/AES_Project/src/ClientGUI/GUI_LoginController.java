package ClientGUI;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Optional;
import java.util.ResourceBundle;


import AES_Classes.Packet;
import AES_Classes.User;
import AES_Client.UserController;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.layout.AnchorPane;
import javafx.scene.paint.Color;



public class GUI_LoginController implements Initializable{
	
	@FXML private TextField txt_username;
	@FXML private TextField txt_port;
	@FXML private TextField txt_address;
	@FXML private PasswordField txt_password;
	@FXML private Button btn_signin;
	@FXML private Button btn_connect;
	@FXML private Label status;
	public static User user; 
	
	@FXML
	public void ClickConnect(ActionEvent event) {
		Platform.runLater(new Runnable() {
			
		    @Override
		public void run() {
		String address=txt_address.getText();
        int port =Integer.parseInt(txt_port.getText());
        MainClient.connect(address,port);
        
        checkConection();
			
		}
		});
	}
	public void checkConection() {
		
		if(MainClient.connected) {
			status.setTextFill(Color.GREEN);
			status.setText("Connected");
		}else {
			status.setTextFill(Color.RED);
			status.setText("Disconnected");
		}
			
	
	}
	@FXML
	public void ClickSignIn(ActionEvent event) {		          	
	       	            
	        	  ArrayList<String> login= new ArrayList<String>();
	        	  login.add(txt_username.getText());
	        	  login.add(String.valueOf(txt_password.getText()));
	        	        	 
	        	  
	        try {    	 
	              
	            
	        	ArrayList<Object> answer = UserController.loginUser(login);
	        	
	        	
	            if(answer.get(0).equals("Failure"))
	            {
	            	Alert alert = new Alert(AlertType.CONFIRMATION);
	    			alert.setContentText("Incorrect username or password");
	    			alert.setHeaderText(null);
	    			alert.setGraphic(null);
	    			Optional<ButtonType> result = alert.showAndWait();
	                	                               
	            }
	            	 
	            else if(answer.get(0).equals("AlreadyLoggedIn")) 
	            {
	            	Alert alert = new Alert(AlertType.CONFIRMATION);
	    			alert.setContentText("User Already loggedin");
	    			alert.setHeaderText(null);
	    			alert.setGraphic(null);
	    			Optional<ButtonType> result = alert.showAndWait();
	                            
	               
	            }	            
	            else  
	            {
	            	
	            	user=(User)answer.get(1);
	            	//new inbal 
	            	//Go to home page
	            	
	            	try {
	        			FXMLLoader loader = new FXMLLoader(MainClient.class.getResource("HomePageGUI.fxml"));
	        			AnchorPane page = (AnchorPane) loader.load();
	        			Scene scene = new Scene(page,1250,800);
	        			MainClient.swittchscene(scene);
	        			        			
	            	}
	            	catch (IOException e) {
	            		
	        			e.printStackTrace();
	        		}
	            }		                  
	                     
	       }
	        catch (Exception e)
	        {
	            System.out.println(e.getMessage());
	        }
	      }
	     
	
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		
		// TODO Auto-generated method stub
		
		checkConection();
		
	}

}
