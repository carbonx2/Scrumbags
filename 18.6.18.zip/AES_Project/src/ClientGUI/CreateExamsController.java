package ClientGUI;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

import AES_Classes.Exam;
import AES_Classes.Question;
import AES_Classes.QuestionInExam;
import AES_Client.QuestionController;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableColumn.CellEditEvent;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.cell.TextFieldListCell;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.util.StringConverter;

public class CreateExamsController implements Initializable {

	/**==================================
	 *=CreateExamsController GUI parameters========== 
	 *==================================
	 */
	public ObservableList<QuestionInExam> questionsInExamList = FXCollections.observableArrayList();
	public ObservableList<Question> questionsList = FXCollections.observableArrayList();
	@FXML private TableView<QuestionInExam> QuestionsInExamList;
	@FXML private TableColumn<QuestionInExam, String> QuestionsColumn;
	@FXML private TableColumn<QuestionInExam, String> ScoresColumn;
	@FXML private ListView<Question> QuestionsList;
	@FXML private TextArea QuestionPreviewText;
	@FXML private Button AddQuestionToExamButton;
	@FXML private Button RemoveQuestionFromExamButton;
	@FXML private Button SubmitExamButton;
	@FXML private  Button CancelButton;
	private Exam exam;

	/**
	 * The method close the create exam window
	 * Action when cancel button press	   
	   */
	public void cancelButtonListener() {
		CancelButton.getScene().getWindow().hide();
	}
	/**
	 *This method Opens a Exam preview window that show the exam by the selected exam that set
	 *Show teacher the exam he create that she will can edit and submit the exam            
	 */
	public void submitExamListener() {
		Stage examPreviewStage = new Stage();
		examPreviewStage.setTitle("Exam Preview Page");
		Parent root;
		try {
			FXMLLoader loader = new FXMLLoader();
			root = loader.load(getClass().getResource("PreviewAndSubmitExamGUI.fxml").openStream());
			ExamPreviewAndSubmitGUIController controller = loader.getController();
			controller.setQuestionsInExam(questionsInExamList);
			controller.setExam(exam);
			examPreviewStage.setOnCloseRequest(e -> {controller.onCloseOperation(e);});
			Scene scene = new Scene(root);
			examPreviewStage.setScene(scene);			
			examPreviewStage.initModality(Modality.APPLICATION_MODAL);
			examPreviewStage.initOwner(SubmitExamButton.getScene().getWindow());
			examPreviewStage.showAndWait();
			cancelButtonListener();

		} catch (IOException e) {

			e.printStackTrace();
		}

	}
	/**
	 *=This method update question list of by the exam subject              
	 */
	public void updateQuestionsList() {
		String subjectID = exam.getSubject().getID();
		ArrayList<Question> questionlist = QuestionController.getQuestionListBySubject(subjectID);
		questionsList.setAll(questionlist);
	}
	/**
	 *=This method show selected question present details
	 *@param question To preview the selected question, get is details               
	 */
	public void showQuestionPreview(Question question) {
		QuestionPreviewText.setText("Question: " + question.getQuestion() + "\n\n1)" + question.getAnswer(1) + "\n2)"
				+ question.getAnswer(2) + "\n3)" + question.getAnswer(3) + "\n4)" + question.getAnswer(4)
				+ "\n\nAuthor: " + question.getAuthor().getName());
	}
	/**
	 *=This method add question to question list in exam
	 *@param question the question we wants to add
	 *Now that exam have question user can submit the exam             
	 */
	public void addQuestionToExam(Question question) {
		questionsInExamList.add(new QuestionInExam(question, 0));
		questionsList.remove(question);
		SubmitExamButton.setDisable(false);
	}
	/**
	 *=This method remove question from question list in exam
	 *@param question the question we wants to remove
	 *if there are no more question in exam \ user can not submit the exam             
	 */
	public void removeQuestionFromExam(QuestionInExam question) {
		questionsList.add(new Question(question));
		questionsInExamList.remove(question);
		if(questionsInExamList.size()==0)
			SubmitExamButton.setDisable(true);
	}
	/**
	 *This method performed when left Arrow Button Clicked to add question to exam
	 *Call addQuestionToExam  method         
	 */
	public void leftArrowButtonClicked() {
		Question question = QuestionsList.getSelectionModel().getSelectedItem();
		if (question != null)
			addQuestionToExam(question);
	}
	/**
	 *This method performed when right Arrow Button Clicked click to remove question to exam
	 *Call removeQuestionFromExam  method         
	 */
	public void rightArrowButtonClicked() {
		QuestionInExam question = QuestionsInExamList.getSelectionModel().getSelectedItem();
		if (question != null)
			removeQuestionFromExam(question);
	}
	/**
	 *This method set the exam are create in parameters
	 *@param  exam  The exam to add create exam controller       
	 */
	public void setExam(Exam exam) {
		
		System.out.println(exam);
		this.exam=exam;
		
	}

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		// TODO Auto-generated method stub
		SubmitExamButton.setDisable(true);
		
		QuestionsInExamList.setPlaceholder(new Label("No questions added yet"));
		QuestionsList.setItems(questionsList);
		QuestionsInExamList.setItems(questionsInExamList);
		QuestionsColumn.setCellValueFactory(e -> new SimpleStringProperty(e.getValue().getQuestion()));
		ScoresColumn.setCellValueFactory(e -> new SimpleStringProperty(e.getValue().getScore().toString()));
		QuestionsInExamList.setEditable(true);
		ScoresColumn.setEditable(true);
		ScoresColumn.setCellFactory(TextFieldTableCell.forTableColumn());
		ScoresColumn.setOnEditCommit((CellEditEvent<QuestionInExam, String> t) -> {
			QuestionInExam qis = QuestionsInExamList.getSelectionModel().getSelectedItem();
			if (t.getNewValue().matches("[0-9]*"))
				qis.setScore(Integer.parseInt(t.getNewValue()));
			else
				QuestionsInExamList.refresh();
		});

		QuestionsList.setCellFactory(lv -> {
			TextFieldListCell<Question> cell = new TextFieldListCell<Question>();
			cell.setConverter(new StringConverter<Question>() {
				@Override
				public String toString(Question question) {
					return question.getQuestion();
				}

				@Override
				public Question fromString(String string) {
					return null;
				}
			});
			return cell;
		});

		QuestionsList.getSelectionModel().selectedItemProperty().addListener(e -> {
			Question question = QuestionsList.getSelectionModel().getSelectedItem();
			if (question != null)
				showQuestionPreview(question);
		});

		QuestionsInExamList.getSelectionModel().selectedItemProperty().addListener(e -> {
			QuestionInExam questionInExam = QuestionsInExamList.getSelectionModel().getSelectedItem();
			if (questionInExam != null)
				showQuestionPreview(questionInExam);

		});
		
		
	}

	
	}

	

