package AES_Classes;

public class Student extends User {

	String firstName;
	String lastName;

	public Student(String id, String pass, String firstName, String lastName)
	{
		super(id,pass,Permission.STUDENT);
		this.firstName=firstName;
		this.lastName=lastName;
	}


	public Student(Student student)
	{
		super(student);
		this.firstName = student.getFirstName();
		this.lastName = student.getLastName();		
		
	}
	public String getFirstName() {
		return firstName;
	}


	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}


	public String getLastName() {
		return lastName;
	}


	public void setLastName(String lastName) {
		this.lastName = lastName;
	}


	@Override
	public String toString() {
		return "Student [firstName=" + firstName + ", lastName=" + lastName + "]";
	}

}