package ClientGUI;

import AES_Classes.QuestionInExam;
import javafx.fxml.FXML;
import javafx.scene.control.Label;

public class ViewExamQuestionPaneController {
	@FXML
    private Label ScoreLabel;
	@FXML
	private Label QuestionLabel;

	@FXML
	private Label Answer1Label;

	@FXML
	private Label Answer2Label;

	@FXML
	private Label Answer3Label;

	@FXML
	private Label Answer4Label;


	

	public void setQuestion(QuestionInExam question, int questionNumber) {
		QuestionLabel.setText("Question "+questionNumber+"("+question.getScore()+" points):\n"+question.getQuestion());
		Answer1Label.setText("a. " + question.getAnswer(1));
		Answer2Label.setText("b. " + question.getAnswer(2));
		Answer3Label.setText("c. " + question.getAnswer(3));
		Answer4Label.setText("d. " + question.getAnswer(4));			
	}

	
}
