package ClientGUI;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

import AES_Classes.AlertMessage;
import AES_Classes.Packet;
import AES_Classes.User;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;



public class GUI_LoginController implements Initializable{
	
	@FXML private TextField txt_username;
	@FXML private PasswordField txt_password;
	@FXML private Button btn_signin;
	public static User user; 
	
	@FXML
	private void ClickSignIn(ActionEvent event) {		          	
	       	            
	        	  ArrayList<String> login= new ArrayList<String>();
	        	  login.add(txt_username.getText());
	        	  login.add(String.valueOf(txt_password.getText()));
	        	  System.out.println(login);
	        	  Packet packet=new Packet("LogIn", login); 
	        try {
	        	 
	            int request=MainClient.client.sendToServerAJ(packet);        
	            
	            Packet response=MainClient.client.getResponse(request); 
	            
	            if(response.getOperation().equals("Incorrect"))
	            {
	            	AlertMessage.Display("login error", "Incorrect Username or Password");
	                	                               
	            }
	            	 
	            else if(response.getOperation().equals("AlreadyLoggedIn")) 
	            {
	            	AlertMessage.Display("login error", "You already logged in");
	                            
	               
	            }	            
	            else  
	            {
	            	
	            	user=(User)response.getData();
	            	//new inbal 
	            	//Go to home page
	            	
	            	try {
	        			FXMLLoader loader = new FXMLLoader(MainClient.class.getResource("HomePageGUI.fxml"));
	        			AnchorPane page = (AnchorPane) loader.load();
	        			Scene scene = new Scene(page,1250,800);
	        			MainClient.swittchscene(scene);
	        			        			
	            	}
	            	catch (IOException e) {
	            		
	        			e.printStackTrace();
	        		}
	            }		                  
	                     
	       }
	        catch (Exception e)
	        {
	            System.out.println(e.getMessage());
	        }
	      }
	     
	
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		// TODO Auto-generated method stub
		btn_signin.setOnAction(this::ClickSignIn);
		
	}

}
