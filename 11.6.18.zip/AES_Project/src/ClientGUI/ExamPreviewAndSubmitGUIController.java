package ClientGUI;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Optional;
import java.util.ResourceBundle;

import AES_Classes.Exam;
import AES_Classes.QuestionInExam;
import AES_Client.ExamController;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Insets;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Pagination;
import javafx.scene.control.ScrollPane;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;

public class ExamPreviewAndSubmitGUIController implements Initializable {
	public static final int itemsPerPage = 4;
	public ObservableList<QuestionInExam> questionsInExamList;
	private ArrayList<Node> questionsPagesLayouts;
	private ArrayList<QuestionPaneController> questionControllers;
	@FXML
	private AnchorPane OurAnchorPane;
	@FXML
	public Pagination pagination;

	@FXML
	public Button CancelButton;
	@FXML
	public Button SubmitButton;
	private ExamPreviewPageController firstPageController;
	private Node firstPageLayout;
	private Exam exam;


	public void setQuestionsInExam(ObservableList<QuestionInExam> questionsInExamList) {
		this.questionsInExamList = questionsInExamList;
		setPageCount();

	}

	public void cancelButtonListener(ActionEvent event) {
		Alert alert = new Alert(AlertType.CONFIRMATION);
		alert.setContentText("All information will be lost.\nAre you sure?");
		alert.setHeaderText(null);
		alert.setGraphic(null);
		Optional<ButtonType> result = alert.showAndWait();

		if (result.get() == ButtonType.OK){
			CancelButton.getScene().getWindow().hide();
		} else {
			alert.hide();
		}		

	}


	public void initPages() {
		FXMLLoader loader = new FXMLLoader();
		try {
			Node layout = loader.load(getClass().getResource("ExamPreviewPage.fxml").openStream());
			ExamPreviewPageController controller = loader.getController();
			controller.setExam(exam);
			firstPageController = controller;
			firstPageLayout = layout;
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		for(int pageIndex=0;pageIndex<pagination.getPageCount()-1;pageIndex++) {
			VBox box = new VBox();
			for(int i = 0; i < itemsPerPage && (pageIndex)*4+i<questionsInExamList.size() ; i++) {
				try {
					loader = new FXMLLoader();
					Node layout = loader.load(getClass().getResource("QuestionPane.fxml").openStream());
					QuestionPaneController controller = loader.getController();
					controller.setQuestion(questionsInExamList.get((pageIndex)*4+i), (pageIndex)*4+i+1);
					questionControllers.add(controller);
					box.getChildren().add(layout);
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			box.setStyle("-fx-background-color:white;");
			box.setPadding(new Insets(0,0,0,20));
			questionsPagesLayouts.add(box);
			
		}
	}


	public ScrollPane createPage(int pageIndex) {
			ScrollPane scrollPane = new ScrollPane();
			if(pageIndex==0) 
				scrollPane.setContent(firstPageLayout);
			else 
				scrollPane.setContent(questionsPagesLayouts.get(pageIndex-1));
			scrollPane.getStylesheets().add("FixScrollbar.css");
			return scrollPane;

	}

	public void setPageCount() {
		if (questionsInExamList.size() % itemsPerPage == 0)
			pagination.setPageCount(questionsInExamList.size() / itemsPerPage + 1);

		else
			pagination.setPageCount(questionsInExamList.size() / itemsPerPage + 2);

	}

	public void setExam(Exam exam) {
		this.exam = exam;
		initPages();
	}

	public void submitExam() {
		int score = 0;
		for (QuestionPaneController controller : questionControllers)
			score += controller.getScore();
		if (score != 100) {
			alert("Invalid scores inserted", "The questions scores do not meet the sum of 100");
			return;
		}
		for (QuestionPaneController controller : questionControllers) {
			controller.setNotes();
			controller.setScore();
		}
		firstPageController.setNoteAndTime();
		exam.setQuestions(questionsInExamList);
		ExamController.addExamToRepository(exam);
		alert("Create Exam","Exam has been created successfully");		
	}
	
	public void alert(String title,String message)
	{		
		Alert alert = new Alert(AlertType.INFORMATION);
		alert.setTitle(title);
		alert.setHeaderText(null);
		alert.setContentText(message);
		alert.showAndWait();
	}

	public void onCloseOperation(WindowEvent event)
	{
		event.consume();
		cancelButtonListener(null);
	}

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		// TODO Auto-generated method stub
		pagination.setPageFactory((Integer pageIndex) -> createPage(pageIndex));
		firstPageController = null;
		firstPageLayout = null;
		questionControllers = new ArrayList<QuestionPaneController>();
		questionsPagesLayouts = new ArrayList<Node>();
	}


}
