package ClientGUI;


import java.net.URL;
import java.util.ResourceBundle;

import AES_Classes.QuestionInExam;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;

public class QuestionPaneController implements Initializable{

	@FXML
	private TextArea NoteForStudentTextArea;
	@FXML
	private TextArea NoteForTeacherTextArea;

	@FXML
	private Label QuestionLabel;

	@FXML
	private Label Answer1Label;

	@FXML
	private Label Answer2Label;

	@FXML
	private Label Answer3Label;

	@FXML
	private Label Answer4Label;

	private QuestionInExam question;

	@FXML
	private TextField ScoreTextField;

	
	public void setQuestion(QuestionInExam question, int questionNumber) {
		QuestionLabel.setText("Question "+questionNumber + ":\n" + question.getQuestion());
		Answer1Label.setText("a. " + question.getAnswer(1));
		Answer2Label.setText("b. " + question.getAnswer(2));
		Answer3Label.setText("c. " + question.getAnswer(3));
		Answer4Label.setText("d. " + question.getAnswer(4));
		ScoreTextField.setText(question.getScore().toString());
		this.question = question;
	}

	public void setNotes() {
		question.setNoteForStudent(NoteForStudentTextArea.getText());
		question.setNoteForTeacher(NoteForTeacherTextArea.getText());
	}

	public void scoreTextListener() {

		if (!ScoreTextField.getText().matches("\\d*")) {
			ScoreTextField.setText(ScoreTextField.getText().replaceAll("[^\\d]", ""));
		}
	}
	
	public int getScore() {
		return Integer.parseInt(ScoreTextField.getText());
	}

	
	public void setScore() {
		this.question.setScore(getScore());
		
	}
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		// TODO Auto-generated method stub
		
	}

}
