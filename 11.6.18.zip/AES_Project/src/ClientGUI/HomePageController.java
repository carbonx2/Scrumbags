package ClientGUI;

import java.io.IOException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Optional;
import java.util.ResourceBundle;

import javafx.geometry.Rectangle2D;
import AES_Classes.Course;
import AES_Classes.Exam;
import AES_Classes.Packet;
import AES_Classes.Person;
import AES_Classes.Question;
import AES_Classes.Subject;
import AES_Classes.Teacher;
import AES_Client.ExamController;
import AES_Client.QuestionController;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TreeItem;
import javafx.scene.control.TreeView;
import javafx.scene.control.cell.TextFieldListCell;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Modality;
import javafx.stage.Screen;
import javafx.stage.Stage;
import javafx.util.StringConverter;

public class HomePageController implements Initializable{
	
	Teacher teacher = (Teacher) GUI_LoginController.user;
	int HomePagePermission;
	@FXML Label Message;
	ArrayList<Question> questionList;
	ArrayList<Exam> examsList;
	@FXML private Label txt_loginUsername;
	@FXML private TreeView<String> Options;
	@FXML private Button btn_logOut;
	@FXML private Button btn_viewquestion;
	@FXML private Button ViewExamButton;
	@FXML private ListView<Question> QuestionList= null;   
	@FXML private ListView<Exam> ExamsList = null; 
	@FXML private Label lbl_CQ;
	@FXML private ComboBox<Subject> SubjectCQComboBox;
	@FXML private ComboBox<Subject> SubjectComboBox;
	@FXML private ComboBox<Course> CourseComboBox;
	@FXML private ComboBox<Subject> SubjectEComboBox;
	@FXML private Button ReloadExamsButton;
	@FXML private AnchorPane ExamPreviewPane;
	@FXML private AnchorPane QuestionViewPane;
	@FXML private AnchorPane CreateQuestionPane;
	@FXML private AnchorPane ExamViewPane;
	@FXML private AnchorPane CreateExamPane;
	@FXML private Label CourseNameLabel;
	@FXML private Label AuthorLabel;
	@FXML private Label DateLabel;
	@FXML private Label FreeTextLabel;
	@FXML private Label ExamTimeLabel;
	
	@FXML private ComboBox<Course> CourseECComboBox;
	@FXML private ComboBox<Subject> SubjectECComboBox;
	@FXML private Button ConfirmButton;

	
	public static Stage ViewExamWindow;
	public static Stage QuestionViewWindow;
	public static Stage QuestionCreateWindow;
	public static Stage ExamCreateWindow;

@FXML
private void ClickLogOut(ActionEvent event) {
		
		Platform.runLater(new Runnable(){
            
            public void run()
            {                        
              try {
				MainClient.client.sendToServer(new Packet("LogOut",GUI_LoginController.user.getID()));
				//close   
		    	MainClient.stage.close();
			} catch (IOException e) {				
				e.printStackTrace();
			}	
                                     
         }                
        });          
        
    }
public void alert(String message){
		Alert alert = new Alert(AlertType.CONFIRMATION);
		alert.setContentText(message);
		alert.setHeaderText(null);
		alert.setGraphic(null);
		Optional<ButtonType> result = alert.showAndWait();
		
		if (result.get() == ButtonType.OK)
			 alert.hide();
		 
}
public void CreateTreeView() {	
	
	TreeItem<String> teacher = new TreeItem<>("T-Options");
	TreeItem<String> student = new TreeItem<>("S-Options");
	TreeItem<String> manger = new TreeItem<>("M-Options");
	TreeItem<String> teacherQ = new TreeItem<>("Questions");
	TreeItem<String> teacherE = new TreeItem<>("Exams");
	TreeItem<String> QList = new TreeItem<>("Questions List");
	TreeItem<String> EList = new TreeItem<>("Exam List");
	TreeItem<String> NewQ = new TreeItem<>("Create Question");
	TreeItem<String> NewE = new TreeItem<>("Create Exam");
	
	teacher.getChildren().add(teacherQ);
	teacherQ.setExpanded(true);
	teacher.getChildren().add(teacherE);
	teacherE.setExpanded(true);
	teacherQ.getChildren().add(QList);
	teacherQ.getChildren().add(NewQ);
	teacherE.getChildren().add(EList);
	teacherE.getChildren().add(NewE);
	
				
	if(HomePagePermission == 2) {
					
		Options.setRoot(teacher);
		Options.setShowRoot(false);
		
	}
	if(HomePagePermission == 3) {
		
		Options.setRoot(manger);
		Options.setShowRoot(false);			
	}		
}
@FXML public void ClickOptions() {

	QuestionViewPane.setVisible(false);
	ExamPreviewPane.setVisible(false);
	CreateQuestionPane.setVisible(false);
	ExamViewPane.setVisible(false);
	CreateExamPane.setVisible(false);
	String Click = Options.getSelectionModel().getSelectedItem().getValue();
	System.out.println(Click);
	
	switch(Click)
	{
	
	case "Questions List":
		QuestionViewPane.setVisible(true); 
		updateSubjectBox(SubjectComboBox);
		 break; 
	case "Create Question":
		CreateQuestionPane.setVisible(true);
		updateSubjectBox(SubjectCQComboBox); 			  
	     break;
	case "Exam List":
		ExamViewPane.setVisible(true);
	  updateSubjectBox(SubjectEComboBox);
	  break;
	case "Create Exam":
		CreateExamPane.setVisible(true);
		updateSubjectBox(SubjectECComboBox);
		  break;
		  default:
			  break;
}

	}
public void updateSubjectBox(ComboBox<Subject> Subject) {
	Subject.getItems().clear();
	Subject.getItems().addAll(teacher.getSubjects());
	
}
//Questions
public void SubjectComboBoxAction() {
		
	updateQuestionListBySubject(SubjectComboBox.getValue().getID());
		QuestionList.setVisible(true);
	
	}
public void SubjectCQComboBoxAction() {
			
			CreateQuestionController.subject = SubjectCQComboBox.getValue();
			QuestionCreateWindow = new Stage();
			QuestionCreateWindow.setTitle("Create question");
			QuestionCreateWindow.initModality(Modality.APPLICATION_MODAL);
	    	Parent root;
			try {	
				root = FXMLLoader.load(getClass().getResource("QuestionCreateGUI.fxml"));
				Scene scene = new Scene(root);
				QuestionCreateWindow.setScene(scene);
				QuestionCreateWindow.showAndWait();
				
				
			} catch (IOException e) {			
				e.printStackTrace();
			}
		
	}
@FXML private void ClickQuestionView(ActionEvent event) {
		
		QuestionViewWindow = new Stage();
		QuestionViewWindow.setTitle("Question View");
		QuestionViewWindow.initModality(Modality.APPLICATION_MODAL);
    	Parent root;
		try {	
			QuestionViewGUIController.question = QuestionList.getSelectionModel().getSelectedItem();
			root = FXMLLoader.load(getClass().getResource("QuesionViewDetails.fxml"));
			Scene scene = new Scene(root);
			QuestionViewWindow.setScene(scene);
			QuestionViewWindow.showAndWait();
			updateQuestionListBySubject(SubjectComboBox.getValue().getID());
			
		} catch (IOException e) {			
			e.printStackTrace();
		}
    }
public void updateQuestionListBySubject(String Qid) {
	
	
	QuestionList.getItems().clear();
	
	questionList = QuestionController.getQuestionListBySubject(Qid);
	
	if(questionList.isEmpty()) {
		//do something
	}else {
		QuestionList.getItems().addAll(questionList);

	}
		
}
//Exam
public void updateExamListBySubject(String subjectID) {
			ExamPreviewPane.setVisible(false);
			ExamsList.getItems().clear();
			examsList = ExamController.getExamsListBySubject(subjectID);
			ExamsList.getItems().addAll(examsList);
		}
public void showExamPreview(Exam exam) {
		ExamPreviewPane.setVisible(true);
		CourseNameLabel.setText(exam.getCourse().getName());
		DateLabel.setText(exam.getCreationDate());
		AuthorLabel.setText("" + exam.getAuthor().getName());
		FreeTextLabel.setText(exam.getNote());
		ExamTimeLabel.setText("Exam time: " + exam.getExamTime());
	}
public void subjectSelectionListner() {
			ExamPreviewPane.setVisible(false);
		if(!SubjectEComboBox.getValue().getID().isEmpty()) {
			updateCoursesBox(SubjectEComboBox.getValue().getID());
			updateExamListBySubject(SubjectEComboBox.getValue().getID());
			ExamsList.setVisible(true);
			ReloadExamsButton.setVisible(true);
		}
	}
public void updateExamListByCourse(String courseID) {
		ExamPreviewPane.setVisible(false);
		ExamsList.getItems().clear();
		for (Exam exam : examsList) {
			if (exam.getCourse().getID().equals(courseID))
				ExamsList.getItems().add(exam);

		}
	}
public void courseSelectionListner() {
		ExamPreviewPane.setVisible(false);
		updateExamListByCourse(CourseComboBox.getValue().getID());
		ExamsList.setVisible(true);
		ReloadExamsButton.setVisible(true);
	}
public void updateCoursesBox(String subjectID) {
	ExamPreviewPane.setVisible(false);
	CourseComboBox.getItems().clear();
		CourseComboBox.getItems().addAll(teacher.getCoursesOfSubject(subjectID));
	}
@FXML public void reloadClickedListener() {
		ExamPreviewPane.setVisible(false);
		if (SubjectEComboBox.getValue() != null) {
			updateExamListBySubject(SubjectEComboBox.getValue().getID());
			if (CourseComboBox.getValue() != null)
				updateExamListByCourse(CourseComboBox.getValue().getID());
		} else
			ExamsList.getItems().clear();

	}
@FXML public void ClickViewExam(ActionEvent event) {
	
	if(ExamsList.getSelectionModel().getSelectedItem()== null)
	{
		alert("You need to select an exam before you can view one");	
		return;		}
				
	ViewExamWindow = new Stage();
	ViewExamWindow.setTitle("View Exam");
	
	try {
		
		FXMLLoader loader = new FXMLLoader();
		Parent root1 = loader.load(getClass().getResource("ViewExamGUI.fxml").openStream());			
		ViewExamGUIController controller = loader.getController();
		controller.setQuestionsInExam(ExamsList.getSelectionModel().getSelectedItem().getQuestions());
		controller.setExam(ExamsList.getSelectionModel().getSelectedItem());			
		ViewExamWindow.setScene(new Scene(root1));
		ViewExamWindow.initModality(Modality.APPLICATION_MODAL);
		ViewExamWindow.showAndWait();		
		
		
	} catch (IOException e) {			
		e.printStackTrace();
	}

	
}
//from here create
public void subjectSelectionListener() {
	updateCreateCoursesBox(SubjectECComboBox.getValue().getID());
}
public void courseSelectionListener() {
	ConfirmButton.setDisable(false);
}
public void confirmButtonListener(ActionEvent event) {
	ExamCreateWindow = (Stage) ConfirmButton.getScene().getWindow();
	ExamCreateWindow.setTitle("Create exam");
	
	try {
		
		Course course = CourseECComboBox.getSelectionModel().getSelectedItem();
		Subject subject = SubjectECComboBox.getSelectionModel().getSelectedItem();
		Date date = new Date();  
	    SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");  
	    String strDate= formatter.format(date);  
	    FXMLLoader loader = new FXMLLoader(); 
	    Parent root = loader.load(getClass().getResource("CreateExam.fxml").openStream());			
		CreateExamsController  controller = loader.getController();
		Exam exam = new Exam(subject.getID()+course.getID(),course,subject,new Person(teacher.getID(),teacher.getName()),strDate,0);
		controller.setExam(exam);
		controller.updateQuestionsList();
		Scene scene = new Scene(root);
		ExamCreateWindow.setScene(scene);
		Rectangle2D primScreenBounds = Screen.getPrimary().getVisualBounds();
		ExamCreateWindow.setX((primScreenBounds.getWidth() - ExamCreateWindow.getWidth()) / 2);
		ExamCreateWindow.setY((primScreenBounds.getHeight() - ExamCreateWindow.getHeight()) / 2);
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}

	  

}
public void updateCreateCoursesBox(String subjectID) {
	CourseECComboBox.getItems().clear();
	CourseECComboBox.getItems().addAll(teacher.getCoursesOfSubject(subjectID));
}

//to here

public void setConverters() {
	
		
		SubjectComboBox.setConverter(new StringConverter<Subject>() {
			public String toString(Subject subject) {
				return subject.getName();
			}

			@Override
			public Subject fromString(String arg0) {
				return null;
			}

		});
		SubjectEComboBox.setConverter(new StringConverter<Subject>() {
			public String toString(Subject subject) {
				return subject.getName();
			}

			@Override
			public Subject fromString(String arg0) {
				return null;
			}

		});
		SubjectCQComboBox.setConverter(new StringConverter<Subject>() {			

			@Override
			public String toString(Subject subject) {
				
				return subject.getName();
			}

			@Override
			public Subject fromString(String string) {
				// TODO Auto-generated method stub
				return null;
			}
		});
		SubjectECComboBox.setConverter(new StringConverter<Subject>() {
			public String toString(Subject subject) {
				return subject.getName();
			}

			@Override
			public Subject fromString(String arg0) {
				return null;
			}

		});

		
		CourseComboBox.setConverter(new StringConverter<Course>() {

			public String toString(Course course) {
				return course.getName();
			}

			@Override
			public Course fromString(String arg0) {
				return null;
			}

		});
		CourseECComboBox.setConverter(new StringConverter<Course>() {

			public String toString(Course course) {
				return course.getName();
			}

			@Override
			public Course fromString(String arg0) {
				return null;
			}

		});



		ExamsList.setCellFactory(lv -> {
			TextFieldListCell<Exam> cell = new TextFieldListCell<Exam>();
			cell.setConverter(new StringConverter<Exam>() {
				@Override
				public String toString(Exam exam) {
					return exam.getCreationDate() + "      Course: " + exam.getCourse().getName() + "      Author: "
							+ exam.getAuthor().getName();
				}

				@Override
				public Exam fromString(String string) {
					return null;
				}
			});
			return cell;
		});
	}
	@Override
public void initialize(URL arg0, ResourceBundle arg1) {
		// TODO Auto-generated method stub
		setConverters();
		questionList  = QuestionController.getQuestionList();
		this.HomePagePermission = GUI_LoginController.user.getPermission();
		CreateTreeView();
		btn_logOut.setOnAction(this::ClickLogOut);
		ReloadExamsButton.setOnAction(e->reloadClickedListener());
		btn_viewquestion.setOnAction(this::ClickQuestionView);
		ViewExamButton.setOnAction(this::ClickViewExam);
		ConfirmButton.setOnAction(this::confirmButtonListener);
		QuestionList.getSelectionModel().selectedItemProperty().addListener(e -> {
			btn_viewquestion.setVisible(true);
		});
		ExamsList.getSelectionModel().selectedItemProperty().addListener(e -> {
				Exam exam = ExamsList.getSelectionModel().getSelectedItem();
				if (exam != null)
					showExamPreview(exam);
				ViewExamButton.setVisible(true);
			
		});
		
	}

	
	
}
