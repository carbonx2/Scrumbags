package AES_Server;
import java.util.ArrayList;

import AES_Classes.Packet;
import AES_Classes.Permission;
import AES_Classes.Question;
import AES_Classes.Subject;
import AES_Classes.Teacher;
import AES_Classes.User;
import OCSF.Server.ConnectionToClient;
import OCSF.Server.*;
public class PacketHandler {

	public static void handlePacket(Packet packet,ConnectionToClient client) throws Exception {
		switch(packet.getOperation()) {
			case "AddQuestion":
				QuestionController.addQuestionToRepository((Question)packet.getData());
				break;
			case "GetQuestionsList":	
				ArrayList<Question> list=QuestionController.getQuestionsList();
				Packet userPacket= new Packet("Success",list);
				userPacket.setID(packet.getID());				
				client.sendToClient(userPacket);
				break;
			case "RemoveQuestion":
				QuestionController.removeQuestion((String)packet.getData());
				break;
			case "UpdateAnswer":
				QuestionController.updateCorrectAnswer((String)((ArrayList)packet.getData()).get(0),(int)((ArrayList)packet.getData()).get(1));
				break;
			case "GetQuestionListBySubject":
				ArrayList<Question> list1=QuestionController.getQuestionsOfSubject((String)packet.getData());
				Packet packet2=new Packet("Success",list1);
				packet2.setID(packet.getID());
				client.sendToClient(packet2);
				break;
			case "getQuestionByID":
				ArrayList<Question> list2=QuestionController.getQuestionByID((String)packet.getData());
				Packet packet4=new Packet("Success",list2);
				packet4.setID(packet.getID());
				client.sendToClient(packet4);
				break;
			case "LogIn":				
				Packet userPacket1;
				User user;				
				String id = (String)((ArrayList)packet.getData()).get(0);
				String password = (String)((ArrayList)packet.getData()).get(1);
				String ip = client.getInetAddress().getHostAddress();
				user= UserController.logIn(id, password, ip);		
																
				if(user!=null)
				{    					
					if(user.getPermission()==2)
					{						
						userPacket1 = new Packet("Teacher",user);
	 					userPacket1.setID(packet.getID());
	 					System.out.println(userPacket1.getData());
                        client.sendToClient(userPacket1);
					}
				}
				
				break;
			case "LogOut":
				UserController.logOut((String) packet.getData());
				break;
				
		}
	}
}
 