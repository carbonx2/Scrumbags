package ClientGUI;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.ResourceBundle;

import AES_Classes.Course;
import AES_Classes.Packet;
import AES_Classes.Question;
import AES_Classes.Subject;
import AES_Classes.Teacher;
import AES_Client.QuestionController;
import AES_Client.client;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TreeItem;
import javafx.scene.control.TreeTableView;
import javafx.scene.control.TreeView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.HBox;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.util.StringConverter;

public class HomePageController implements Initializable{

	int HomePagePermission;
	@FXML private Label txt_loginUsername;
	@FXML private TreeView<String> Options;
	@FXML private Button btn_logOut;
	@FXML private Button btn_viewquestion;
	@FXML private ListView<Question> QuestionList;
	@FXML private Label lbl_CQ;
	@FXML private ComboBox<Subject> SubjectCQComboBox;
	ArrayList<Question> questionList;
	@FXML private ComboBox<Subject> SubjectComboBox;
	Teacher teacher = (Teacher) GUI_LoginController.user;
	public static Stage QuestionViewWindow;
	public static Stage QuestionCreateWindow;
			
	public void SubjectComboBoxAction() {
		
		updateListBySubject(SubjectComboBox.getValue().getID());
		
		QuestionList.setVisible(true);
	}
		public void SubjectCQComboBoxAction() {
			
			CreateQuestionController.subject = SubjectCQComboBox.getValue();
			QuestionCreateWindow = new Stage();
			QuestionCreateWindow.setTitle("Create question");
			QuestionCreateWindow.initModality(Modality.APPLICATION_MODAL);
	    	Parent root;
			try {	
				root = FXMLLoader.load(getClass().getResource("QuestionCreateGUI.fxml"));
				Scene scene = new Scene(root);
				QuestionCreateWindow.setScene(scene);
				QuestionCreateWindow.showAndWait();
				
				
			} catch (IOException e) {			
				e.printStackTrace();
			}
		
	}
	public void updateListBySubject(String Qid) {
			
				
		QuestionList.getItems().clear();
		
		questionList = QuestionController.getQuestionListBySubject(Qid);
		
		if(questionList.isEmpty()) {
			//do something
		}else {
			QuestionList.getItems().addAll(questionList);
	
		}
			
	}
	@FXML
	private void ClickQuestionView(ActionEvent event) {
		
		QuestionViewWindow = new Stage();
		QuestionViewWindow.setTitle("Question View");
		QuestionViewWindow.initModality(Modality.APPLICATION_MODAL);
    	Parent root;
		try {	
			QuestionViewGUIController.question = QuestionList.getSelectionModel().getSelectedItem();
			root = FXMLLoader.load(getClass().getResource("QuesionViewDetails.fxml"));
			Scene scene = new Scene(root);
			QuestionViewWindow.setScene(scene);
			QuestionViewWindow.showAndWait();
			updateListBySubject(SubjectComboBox.getValue().getID());
			
		} catch (IOException e) {			
			e.printStackTrace();
		}
    }

	@FXML
	private void ClickLogOut(ActionEvent event) {
		
		Platform.runLater(new Runnable(){
            
            public void run()
            {                        
              try {
				MainClient.client.sendToServer(new Packet("LogOut",GUI_LoginController.user.getID()));
				//close   
		    	MainClient.stage.close();
			} catch (IOException e) {				
				e.printStackTrace();
			}	
                                     
         }                
        });          
        
    }
	
	public void CreateTreeView() {	
		
		TreeItem<String> teacher = new TreeItem<>("T-Options");
		TreeItem<String> student = new TreeItem<>("S-Options");
		TreeItem<String> manger = new TreeItem<>("M-Options");
		TreeItem<String> teacherQ = new TreeItem<>("Questions");
		TreeItem<String> teacherE = new TreeItem<>("Exams");
		TreeItem<String> QList = new TreeItem<>("Questions List");
		TreeItem<String> EList = new TreeItem<>("Exam List");
		TreeItem<String> NewQ = new TreeItem<>("Create Question");
		TreeItem<String> NewE = new TreeItem<>("Create Exam");
		
		teacher.getChildren().add(teacherQ);
		teacherQ.setExpanded(true);
		teacher.getChildren().add(teacherE);
		teacherE.setExpanded(true);
		teacherQ.getChildren().add(QList);
		teacherQ.getChildren().add(NewQ);
		teacherE.getChildren().add(EList);
		teacherE.getChildren().add(NewE);
		
					
		if(HomePagePermission == 2) {
						
			Options.setRoot(teacher);
			Options.setShowRoot(false);
			
		}
		if(HomePagePermission == 3) {
			
			Options.setRoot(manger);
			Options.setShowRoot(false);			
		}		
	}
	
	@FXML
	public void ClickOptions() {

		String Click = Options.getSelectionModel().getSelectedItem().getValue();
		System.out.println(Click);
		SubjectComboBox.setVisible(false);
		SubjectCQComboBox.setVisible(false);
		QuestionList.setVisible(false);
		lbl_CQ.setVisible(false);
		switch(Click)
		{
		
		case "Questions List":
			SubjectComboBox.setVisible(true); 
			updateSubjectBox(SubjectComboBox);
			 break; 
		case "Create Question":
			SubjectCQComboBox.setVisible(true);
			lbl_CQ.setVisible(true);
			updateSubjectBox(SubjectCQComboBox); 			  
		     break;
		case "Exam List":
		  System.out.println("Exam List");
		  break;
		case "Create Exam":
			  System.out.println("Create Exam");
			  break;
			  default:
				  break;
	}
	
		}

	public void updateSubjectBox(ComboBox<Subject> Subject) {
		// TODO Auto-generated method stub
		Subject.getItems().clear();
		Subject.getItems().addAll(teacher.getSubjects());
		
	}
	
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		// TODO Auto-generated method stub
		
		SubjectComboBox.setConverter(new StringConverter<Subject>() {			

			@Override
			public String toString(Subject subject) {
				
				return subject.getName();
			}

			@Override
			public Subject fromString(String string) {
				// TODO Auto-generated method stub
				return null;
			}
		});
		SubjectCQComboBox.setConverter(new StringConverter<Subject>() {			

			@Override
			public String toString(Subject subject) {
				
				return subject.getName();
			}

			@Override
			public Subject fromString(String string) {
				// TODO Auto-generated method stub
				return null;
			}
		});
		questionList  = QuestionController.getQuestionList();
		this.HomePagePermission = GUI_LoginController.user.getPermission();
		CreateTreeView();
		btn_logOut.setOnAction(this::ClickLogOut);
		btn_viewquestion.setOnAction(this::ClickQuestionView);
		QuestionList.getSelectionModel().selectedItemProperty().addListener(e -> {
			btn_viewquestion.setVisible(true);
			
		});
		
	}

	
	
}
