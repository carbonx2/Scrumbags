package ClientGUI;

import java.net.URL;
import java.util.ResourceBundle;

import AES_Classes.AlertMessage;
import AES_Classes.Person;
import AES_Classes.Question;
import AES_Classes.Subject;
import AES_Classes.Teacher;
import AES_Client.QuestionController;
import AES_Client.client;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;

public class CreateQuestionController implements Initializable{

    @FXML private TextField txt_subject;
    @FXML private Button btn_save;
    @FXML private TextField txt_Question;
    @FXML private TextField txt_Author;
    @FXML private TextField txt_correctAnswer;
    @FXML private Button btn_close;
    @FXML private TextField q_answer1;
    @FXML private TextField q_answer2;
    @FXML private TextField q_answer3;
    @FXML private TextField q_answer4;
    public static Subject subject;
    public static Question NewQuestion;
    
    
    @FXML 
    public void ClickSaveChanges(ActionEvent event) {
    	int count=0;    	
    	 	
    		if((q_answer1.getText().isEmpty())||(q_answer2.getText().isEmpty())||(q_answer3.getText().isEmpty())||(q_answer4.getText().isEmpty()))
    				{AlertMessage.Display("Create Error", "all answers need to be filled");
    
    		}    		else { count++;}
    		if(txt_Question.getText().isEmpty()) {
    		
    			AlertMessage.Display("Create Error", "No Question to save");
    		}{ count++;}
    		
    		if(txt_correctAnswer.getText().isEmpty()){
    			AlertMessage.Display("Create Error", "No correct answer to save");
    			
    		}else {
    				int canswer = Integer.parseInt(txt_correctAnswer.getText());
    		if((canswer <1 ) || (canswer > 4))
    		{
    			AlertMessage.Display("Create Error", "correct answer error");
    		}
    		else{ count++;}
    		}
    		
    		if(count == 3) {
    	    	Person author = new Person(GUI_LoginController.user.getID() ,((Teacher)(GUI_LoginController.user)).getName());
    	    	
    	    	NewQuestion = new Question(subject.getID(),author,txt_Question.getText(),q_answer1.getText(),q_answer2.getText(),q_answer3.getText(),q_answer4.getText(),Integer.parseInt(txt_correctAnswer.getText()));
    			QuestionController.AddQuestion(NewQuestion);
    			AlertMessage.Display("Save question", "Question was edit to repository");
    		}
    		
    		
    }

    @FXML
    void ClickClose(ActionEvent event) {
    	
    	HomePageController.QuestionCreateWindow.close();
    	
    }

    public void CreateQuestionView() {
    	txt_subject.setText(subject.getName());
    	txt_Author.setText(((Teacher)(GUI_LoginController.user)).getName());
    	
    }
 
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		// TODO Auto-generated method stub

		CreateQuestionView();
		btn_save.setOnAction(this::ClickSaveChanges);
		btn_close.setOnAction(this::ClickClose);
	}
    
    

}
