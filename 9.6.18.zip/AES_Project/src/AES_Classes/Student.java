package AES_Classes;

import java.io.Serializable;

public class Student extends User implements Serializable{
	
	String firstName;
	String lastName;
	
	public Student(String ID, String password,String firstname , String lastname) {
		super(ID, password, Permission.STUDNET);
		this.firstName=firstname;
		this.lastName=lastname;
	}
	
	
	public String toString()
	{
		return "Name:"+firstName+" Last Name:"+lastName+" ID:"+getID()+" Permission:"+getPermission();
	}
	
	public String getName()
	{
		return firstName+" "+lastName;
	}
	

}
