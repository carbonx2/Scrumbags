package AES_Classes;

public enum Permission{NONE,STUDNET,TEACHER, MANAGER,ADMIN};
 