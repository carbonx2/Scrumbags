package AES_Classes;

import java.io.Serializable;

public class Subject implements Serializable {

	String name;
	String ID;
		
	
	public Subject(String name,String ID)
	{
		this.name=name;
		this.ID=ID;
	}
	
	
	public String getName() {
		return name;
	}	


	public String getID() {
		return ID;
	}

	
	
}
