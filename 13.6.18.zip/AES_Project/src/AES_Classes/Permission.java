package AES_Classes;

public enum Permission {
	NONE, STUDENT, TEACHER, MANAGER, ADMIN
};
