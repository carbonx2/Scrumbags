package AES_Server;

import java.util.ArrayList;

import AES_Classes.Exam;
import AES_Classes.Packet;
import AES_Classes.Permission;
import AES_Classes.Question;
import AES_Classes.Student;
import AES_Classes.User;
import OCSF.Server.ConnectionToClient;

public class PacketHandler {

	public static void handlePacket(Packet packet, ConnectionToClient client) throws Exception {
		Packet userPacket;
		Object data = null;
		String answer = "Success";
			
		switch (packet.getOperation()) {
		case "AddQuestion":
			answer = QuestionController.addQuestionToRepository((Question) packet.getData());
			break;
		case "GetQuestionsList":
			data = QuestionController.getQuestionsList();
			if (data == null)
				answer = "Failure";
			break;
		case "RemoveQuestion":
			answer = QuestionController.removeQuestion((String) packet.getData());
			break;
		case "UpdateAnswer":
			answer = QuestionController.updateCorrectAnswer((String) ((ArrayList) packet.getData()).get(0),
					(int) ((ArrayList) packet.getData()).get(1));
			break;
		case "GetQuestionListBySubject":
			data = QuestionController.getQuestionsOfSubject((String) packet.getData());
			if (data == null)
				answer = "Failure";
			break;
		case "AddExam":
			answer = ExamController.addExamToRepository((Exam) packet.getData());
			break;
		case "GetExamsList":
			data = ExamController.getExamsList();
			if (data == null)
				answer = "Failure";
			break;
		case "GetExamsListBySubject":
			data = ExamController.getExamsListBySubject((String) packet.getData());
			if (data == null)
				answer = "Failure";
			break;
		case "RemoveExam":
			answer = ExamController.removeExamFromRepository((String) packet.getData());
			break;
			
		case "ExecuteExam": 
			ArrayList<String> data1 = (ArrayList<String>) packet.getData();
			String executionCode = data1.get(0);
			String examID = data1.get(1);
			String teacherID = data1.get(2);		
			boolean answer1 = ExamController.executeExam(executionCode, examID, teacherID);			
			if (!answer1)
				answer="Failure";
			break;			
			
		case "CheckExamCode":
			if(!ExamController.checkExamCode((String)packet.getData()))
				answer="Failure";
			break;
			
		case "TakeExam":
			data = ExamController.takeExam((String)packet.getData());
			break;
			
		case "StartExam":
			
			ArrayList data2 = ((ArrayList)packet.getData());
			Student student = (Student) data2.get(0);
			Exam exam = (Exam) data2.get(1);
			String examExecutionCode = (String) data2.get(2);			
			ExamController.startExam(client, student, exam, examExecutionCode);
			break;
			
		case "LogIn":
			Packet userPacket1;			
			ArrayList<Object> arrayList;
			String id = (String) ((ArrayList) packet.getData()).get(0);
			String password = (String) ((ArrayList) packet.getData()).get(1);
			String ip = client.getInetAddress().getHostAddress();
			arrayList = UserController.logIn(id, password, ip);
			
			if (arrayList != null) {
				answer = (String) arrayList.get(0);
				data = arrayList.get(1);
			}
			break;
				
		case "LogOut":
			UserController.logOut((String) packet.getData());
			break;

		}
		userPacket = new Packet(answer, data);
		userPacket.setID(packet.getID());
		client.sendToClient(userPacket);

	}
}
