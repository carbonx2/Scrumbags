package AES_Server;

import java.awt.List;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import AES_Classes.Packet;
import OCSF.Server.AbstractServer;
import OCSF.Server.ConnectionToClient;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.scene.control.ListView;

public class Server extends AbstractServer {


	final public static int DEFAULT_PORT = 5556;
	public static Connection conn=null;
	ExecutorService pool;
	String[] databaseConnection;
	@FXML ListView<String> messages;
	
	public Server(int port,String[] databaseConnection,ListView<String> msg) {
		super(port);
		this.messages=msg;
		Platform.runLater(new Runnable() {
		@Override
		public void run() {
		pool=Executors.newCachedThreadPool();
		connectToDatabase(databaseConnection);
		    }
		});	
	}
	@Override
	protected void handleMessageFromClient(Object msg, ConnectionToClient client) {
		// TODO Auto-generated method stub
		
		System.out.println("Packet received from: "+client);
		messages.getItems().add("Packet received from: "+client);
		
		 pool.execute(new Runnable() {
			public void run()
			{	
				try {	
					
					PacketHandler.handlePacket((Packet)msg,client);
				} catch (Exception e) {
					e.printStackTrace();
					messages.getItems().add(e.getMessage());
				}
			}
		});
	}
	public void connectToDatabase(String[] databaseConnection) {
		// TODO Auto-generated method stub
		this.databaseConnection=databaseConnection;
		Platform.runLater(new Runnable() {
			@Override
			public void run() {
		
		try 
		{
		  Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
		  
		} catch (Exception ex) {
			try {
				close();
				messages.getItems().add(ex.getMessage());
			} catch (IOException e) {				
				e.printStackTrace();
			}
		}
		try 	
		{
			
			conn = DriverManager.getConnection("jdbc:mysql://localhost/aes?serverTimezone=UTC&useSSL=false","root","braude");			
			//conn = DriverManager.getConnection(databaseConnection[0],databaseConnection[1],databaseConnection[2]);
			System.out.println("SQL connection succeed");
			messages.getItems().add("SQL connection succeed");
		} 
		catch (SQLException ex) 
		{
			System.out.println("SQLException: " + ex.getMessage());
			System.out.println("SQLState: " + ex.getSQLState());
			System.out.println("VendorError: " + ex.getErrorCode());
			messages.getItems().add(ex.getMessage());
			try {
				close();
				conn.close();
			} catch (Exception e) {				
				e.printStackTrace();
			}
		}	
			}
		});
}
protected void serverStarted()
	{
		Platform.runLater(new Runnable() {
			@Override
			public void run() {
	    System.out.println("Server listening for connections on port " + getPort());
	    messages.getItems().add("Server listening for connections on port " + getPort());
			}
		});		
	}
protected void serverStopped()	{
	Platform.runLater(new Runnable() {
		@Override
		public void run() {
		System.out.println("Server has stopped listening for connections.");
		messages.getItems().add("Server has stopped listening for connections.");
		}
	});
}


	protected void clientConnected(ConnectionToClient client) {
		Platform.runLater(new Runnable() {
			@Override
			public void run() {
		System.out.println("This client has been connected: "+client);
		messages.getItems().add("This client has been connected: "+client);
			}
		});
	}
synchronized protected void clientDisconnected(ConnectionToClient client){
	Platform.runLater(new Runnable() {
		@Override
		public void run() {
			System.out.println("This client has been disconnected: "+client);
			messages.getItems().add("This client has been disconnected: "+client);
		}
	});
}
public void shutDown(){
	Platform.runLater(new Runnable() {
		@Override
		public void run() {
		 try { 
			 close();
			conn.close();			
		} catch (Exception e) {		
			e.printStackTrace();
			messages.getItems().add(e.getMessage());
		}
		}
	});
}
}
