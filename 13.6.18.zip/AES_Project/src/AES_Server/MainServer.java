package AES_Server;

import java.io.IOException;

import javax.swing.UIManager;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;


public class MainServer extends Application{

	@Override
	public void start(Stage primaryStage) throws Exception {
		// TODO Auto-generated method stub
		primaryStage.setTitle("AES Server");
		
		try {
			FXMLLoader loader = new FXMLLoader(MainServer.class.getResource("GUI_Server.fxml"));
			AnchorPane page = (AnchorPane) loader.load();
			Scene scene = new Scene(page, 600, 400);
			primaryStage.setScene(scene);
			primaryStage.show();
			
		} catch (IOException e) {
			e.printStackTrace();
		}
        
    }


	public static void main(String[] args) {
		launch(args);
	}
}
