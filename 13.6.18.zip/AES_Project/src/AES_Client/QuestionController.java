package AES_Client;

import java.util.ArrayList;

import AES_Classes.Packet;
import AES_Classes.Question;
import ClientGUI.MainClient;

public class QuestionController {

public static ArrayList<Question> getQuestionList()
{
	int ID=MainClient.client.sendToServerAJ(new Packet("GetQuestionsList",null));
	return (ArrayList<Question>) MainClient.client.getResponse(ID).getData();
}
public static ArrayList<Question> getQuestionListBySubject(String Sid)
{
	int ID=MainClient.client.sendToServerAJ(new Packet("GetQuestionListBySubject",Sid));
	return (ArrayList<Question>) MainClient.client.getResponse(ID).getData();
}
public static ArrayList<Question> getQuestionByID(String Qid)
{
	int ID=MainClient.client.sendToServerAJ(new Packet("getQuestionByID",Qid));
	return (ArrayList<Question>) MainClient.client.getResponse(ID).getData();
}
public static void AddQuestion(Question question)
{
	MainClient.client.sendToServerAJ(new Packet("AddQuestion",question)); 	
}
public static void DeleteQuestion(String Qid)
{
	MainClient.client.sendToServerAJ(new Packet("RemoveQuestion",Qid));	
}
public static void updateCorrectAnswer(String ID,int indexNumber)
{
	ArrayList arrayList = new ArrayList();
	arrayList.add(ID);
	arrayList.add(indexNumber);
	MainClient.client.sendToServerAJ(new Packet("UpdateAnswer",arrayList));
}
	
}
