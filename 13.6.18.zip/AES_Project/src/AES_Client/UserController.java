package AES_Client;

import java.io.IOException;
import java.util.ArrayList;

import AES_Classes.AlertMessage;
import AES_Classes.Packet;
import AES_Classes.User;
import ClientGUI.GUI_LoginController;
import ClientGUI.MainClient;

public class UserController {

	public static ArrayList<Object> loginUser(ArrayList<String> login) {
		
		Packet packet=new Packet("LogIn", login); 
		int requestID=MainClient.client.sendToServerAJ(packet);
		ArrayList<Object> answer = new ArrayList<Object>();
		Packet response = MainClient.client.getResponse(requestID);
		answer.add(response.getOperation());
		answer.add(response.getData());
        return answer;
		
	}
	public static void logoutUser(String id){
		
		Packet packet = new Packet("LogOut",id);
		try {
			MainClient.client.sendToServer(packet);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
