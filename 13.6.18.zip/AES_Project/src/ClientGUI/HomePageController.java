package ClientGUI;

import java.io.IOException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Optional;
import java.util.ResourceBundle;

import AES_Classes.*;
import AES_Client.*;

import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Rectangle2D;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextInputDialog;
import javafx.scene.control.TreeItem;
import javafx.scene.control.TreeView;
import javafx.scene.control.cell.TextFieldListCell;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Modality;
import javafx.stage.Screen;
import javafx.stage.Stage;
import javafx.util.StringConverter;

public class HomePageController implements Initializable{
	
	//General Features
		//for functions
	public static User OnlineUser;
	int HomePagePermission;
		//GUI home page
	@FXML private Label txt_title;
	@FXML private TreeView<String> Options;
	@FXML private Button btn_logOut;
	//Question Features	
		//CreateQuestionPane
		@FXML private ComboBox<Subject> SubjectCQComboBox;
		@FXML private Label lbl_CQ;
		@FXML private Label MessageCQ;
		@FXML private AnchorPane CreateQuestionPane;
		
		//QuestionViewPane
		@FXML private ComboBox<Subject> SubjectComboBox;
		@FXML private ListView<Question> QuestionList= null;
		private ArrayList<Question> questionList;
		@FXML private TextArea QuestionPreview;
		@FXML private Button btn_editquestion;
		@FXML private Label lbl_Q;
		@FXML private Button btn_delete;
		@FXML private AnchorPane QuestionViewPane;
		
	//Exam Features		
		//ExamViewPane
		@FXML private Label MessageE;
		@FXML private Label lbl_E;
		@FXML private ListView<Exam> ExamsList = null;
		private ArrayList<Exam> examsList;
		@FXML private ComboBox<Subject> SubjectEComboBox;
		@FXML private ComboBox<Course> CourseComboBox;
		@FXML private Button ReloadExamsButton;
		@FXML private Button btn_remove;
		@FXML private Button ViewExamButton;
		@FXML private Button ExecuteExamButton;
		@FXML private Label CourseNameLabel;
		@FXML private Label AuthorLabel;
		@FXML private Label DateLabel;
		@FXML private Label FreeTextLabel;
		@FXML private Label ExamTimeLabel;
		@FXML private AnchorPane ExamPreviewPane;
		@FXML private AnchorPane ExamViewPane;
		
		//CreateExamPane
		@FXML private Button ConfirmButton;
		@FXML private ComboBox<Course> CourseECComboBox;
		@FXML private ComboBox<Subject> SubjectECComboBox;
		@FXML private Label lbl_CE;
		@FXML private Label MessageCE;
		@FXML private AnchorPane CreateExamPane;		
			
	//Windows
	public static Stage ViewExamWindow;
	public static Stage QuestionViewWindow;
	public static Stage QuestionCreateWindow;
	public static Stage ExamCreateWindow;

//General Home page when user click Log out 
@FXML
public void ClickLogOut(ActionEvent event) {
		
		Platform.runLater(new Runnable(){
            
            public void run()
            {   
            UserController.logoutUser(GUI_LoginController.user.getID());
            
			//close  
			Alert alert = new Alert(AlertType.CONFIRMATION);
			alert.setContentText("Are you sure you want to exit?");
			alert.setHeaderText(null);
			alert.setGraphic(null);
			Optional<ButtonType> result = alert.showAndWait();
			MainClient.stage.close();	
                                     
         }                
        });          
        
    }
//General Home page function when need to alert a message 
public void alert(String title, String message)
{
	Alert alert = new Alert(AlertType.INFORMATION);
	alert.setTitle(title);
	alert.setHeaderText(null);
	alert.setContentText(message);
	alert.showAndWait();

}
public boolean confirmationAlert(String title,String message)
{
	Alert alert = new Alert(AlertType.CONFIRMATION);
	alert.setContentText(message);
	alert.setHeaderText(title);
	alert.setGraphic(null);
	Optional<ButtonType> result = alert.showAndWait();

	if (result.get() == ButtonType.OK){
		alert.close();
		return true;

	}
	else {
		alert.close();
		return false;
	}		
}
//General Home page function that create option in tree view for specific user
public void CreateTreeView() {	
	
	TreeItem<String> teacher = new TreeItem<>("T-Options");
	TreeItem<String> student = new TreeItem<>("S-Options");
	TreeItem<String> manger = new TreeItem<>("M-Options");
	TreeItem<String> teacherQ = new TreeItem<>("Questions");
	TreeItem<String> teacherE = new TreeItem<>("Exams");
	TreeItem<String> studentE = new TreeItem<>("Exams");
	TreeItem<String> QList = new TreeItem<>("Questions List");
	TreeItem<String> EList = new TreeItem<>("Exam List");
	TreeItem<String> NewQ = new TreeItem<>("Create Question");
	TreeItem<String> NewE = new TreeItem<>("Create Exam");
	TreeItem<String> TakeExam = new TreeItem<>("Take Exam");
	
	//Teacher options in home page
	teacher.getChildren().add(teacherQ);
	teacherQ.setExpanded(true);
	teacher.getChildren().add(teacherE);
	teacherE.setExpanded(true);
	teacherQ.getChildren().add(QList);
	teacherQ.getChildren().add(NewQ);
	teacherE.getChildren().add(EList);
	teacherE.getChildren().add(NewE);
	//Student options in home page
	student.getChildren().add(studentE);
	studentE.setExpanded(true);
	studentE.getChildren().add(TakeExam);
	
	//Set visible option to specific user
	switch(HomePagePermission) {
	
	case 1:
		OnlineUser =(Student) GUI_LoginController.user;
		Options.setRoot(student);
		Options.setShowRoot(false);	
		break;
	case 2:
		OnlineUser =(Teacher) GUI_LoginController.user;
		questionList  = QuestionController.getQuestionList();
		Options.setRoot(teacher);
		Options.setShowRoot(false);
		break;
	case 3:
		//fill school manger user
		Options.setRoot(manger);
		Options.setShowRoot(false);	
		break;
	}
	
}

public void setAllinStartPosion() {
	
	QuestionViewPane.setVisible(false);
	ExamPreviewPane.setVisible(false);
	CreateQuestionPane.setVisible(false);
	ExamViewPane.setVisible(false);
	CreateExamPane.setVisible(false);
	SubjectCQComboBox.getItems().clear();
	SubjectComboBox.getItems().clear();
	SubjectEComboBox.getItems().clear();
	CourseComboBox.getItems().clear();
	CourseECComboBox.getItems().clear();
	SubjectECComboBox.getItems().clear();
	QuestionPreview.setVisible(false);
	btn_editquestion.setVisible(false);
	btn_delete.setVisible(false);
	ReloadExamsButton.setVisible(false);
	ViewExamButton.setVisible(false);
	btn_remove.setVisible(false);
	ExecuteExamButton.setVisible(false);
	QuestionList.setVisible(false);
	ExamsList.setVisible(false);

	
}
////General Home page when user click some option in the tree view 
@FXML public void ClickOptions() {

	setAllinStartPosion();
	
	String Click = Options.getSelectionModel().getSelectedItem().getValue();
	System.out.println(Click);
	
	switch(Click)
	{	
	case "Questions List":
		QuestionViewPane.setVisible(true); 
		updateSubjectBox(SubjectComboBox);
		 break; 
	case "Create Question":
		CreateQuestionPane.setVisible(true);
		updateSubjectBox(SubjectCQComboBox); 			  
	     break;
	case "Exam List":
		ExamViewPane.setVisible(true);
	  updateSubjectBox(SubjectEComboBox);
	  break;
	case "Create Exam":
		CreateExamPane.setVisible(true);
		updateSubjectBox(SubjectECComboBox);
		
		  break;
		  default:
			  break;
}

	}
public void updateSubjectBox(ComboBox<Subject> Subject) {
	Subject.getItems().clear();
	Subject.setPromptText("Subject");
	Subject.getItems().addAll(((Teacher)OnlineUser).getSubjects());
	
}
//Questions functions

@FXML
public void ClickDeleteQuestion(ActionEvent event) {
	
	Question question = QuestionList.getSelectionModel().getSelectedItem();
	boolean answer =confirmationAlert("Remove Question","Are you sure you want to remove the \n selected question from the database?");
	if(answer)
	{
		if(!(question.getAuthor().getID().equals(GUI_LoginController.user.getID())))
		{
			alert("Remove Question", "You do not have permission to remove questions' which were not composed by you");	
			return;
		}
		QuestionController.DeleteQuestion(question.getID());
		updateQuestionListBySubject(SubjectComboBox.getSelectionModel().getSelectedItem().getID());
		QuestionPreview.setVisible(false);
		btn_delete.setVisible(false);
		btn_editquestion.setVisible(false);
		alert("Remove Exam","Exam has been removed from the database");
	}
}
public void QuestionPreview(Question Questionselected) {
	
	Platform.runLater(new Runnable() {
		@Override
		public void run() {
	QuestionPreview.setText("Question details:\n\n ID: "+Questionselected.getID()+"\n Author: "+Questionselected.getAuthor().getName()+"\n\nQuestion: " + Questionselected.getQuestion()+"\n\nAnswer: "+Questionselected.getCorrectAnswer());
	QuestionPreview.setVisible(true);
		}
	});
}
 	//when user select items from combobox in View question
public void SubjectComboBoxAction() {
	
	QuestionPreview.setVisible(false);
	updateQuestionListBySubject(SubjectComboBox.getValue().getID());
	QuestionList.setVisible(true);
		
	
}
	//when user select items from combobox in create question
public void SubjectCQComboBoxAction() {
			
			CreateQuestionController.subject = SubjectCQComboBox.getValue();
			QuestionCreateWindow = new Stage();
			QuestionCreateWindow.setTitle("Create question");
			QuestionCreateWindow.initModality(Modality.APPLICATION_MODAL);
	    	Parent root;
			try {	
				root = FXMLLoader.load(getClass().getResource("QuestionCreateGUI.fxml"));
				Scene scene = new Scene(root);
				QuestionCreateWindow.setScene(scene);
				QuestionCreateWindow.showAndWait();
				
				
			} catch (IOException e) {			
				e.printStackTrace();
			}
		
	}
	//when user wants to see question details
@FXML public void ClickQuestionEdit(ActionEvent event) {		
		QuestionViewWindow = new Stage();
		QuestionViewWindow.setTitle("Question View");
		QuestionViewWindow.initModality(Modality.APPLICATION_MODAL);
    	Parent root;
		try {	
			QuestionViewGUIController.question = QuestionList.getSelectionModel().getSelectedItem();
			root = FXMLLoader.load(getClass().getResource("QuesionViewDetails.fxml"));
			Scene scene = new Scene(root);
			QuestionViewWindow.setScene(scene);
			QuestionViewWindow.initOwner(SubjectComboBox.getScene().getWindow());
			QuestionViewWindow.showAndWait();
			updateQuestionListBySubject(SubjectComboBox.getValue().getID());
			
		} catch (IOException e) {			
			e.printStackTrace();
		}
    }
	////when user select items from combobox in view question the list of questions will be update
public void updateQuestionListBySubject(String Qid) {
	
	QuestionPreview.setVisible(false);
	QuestionList.getItems().clear();
	questionList = QuestionController.getQuestionListBySubject(Qid);
	
	if(questionList.isEmpty()) {
		//do something
	}else {
		QuestionList.getItems().addAll(questionList);

	}
		
}

//Exam
	//when user select items from combobox view exam the list of exams will be update
public void updateExamListBySubject(String subjectID) {
			ExamPreviewPane.setVisible(false);
			ExamsList.getItems().clear();
			examsList = ExamController.getExamsListBySubject(subjectID);
			ExamsList.getItems().addAll(examsList);
		}
	//when user select exam will showing him privew of exam
public void showExamPreview(Exam exam) {
		ExamPreviewPane.setVisible(true);
		CourseNameLabel.setText(exam.getCourse().getName());
		DateLabel.setText(exam.getCreationDate());
		AuthorLabel.setText("" + exam.getAuthor().getName());
		FreeTextLabel.setText(exam.getNote());
		ExamTimeLabel.setText("Exam time: " + exam.getExamTime());
	}
	//when user select items from combobox in create exam 
public void subjectSelectionListner() {
			ExamPreviewPane.setVisible(false);
		if(!SubjectEComboBox.getValue().getID().isEmpty()) {
			updateCoursesBox(SubjectEComboBox.getValue().getID());
			updateExamListBySubject(SubjectEComboBox.getValue().getID());
			ExamsList.setVisible(true);
			ReloadExamsButton.setVisible(true);
		}
	}

public void updateExamListByCourse(String courseID) {
		ExamPreviewPane.setVisible(false);
		ExamsList.getItems().clear();
		for (Exam exam : examsList) {
			if (exam.getCourse().getID().equals(courseID))
				ExamsList.getItems().add(exam);

		}
	}
public void courseSelectionListner() {
		ExamPreviewPane.setVisible(false);
		updateExamListByCourse(CourseComboBox.getValue().getID());
		ExamsList.setVisible(true);
		ReloadExamsButton.setVisible(true);
	}
public void updateCoursesBox(String subjectID) {
	ExamPreviewPane.setVisible(false);
	CourseComboBox.getItems().clear();
	CourseComboBox.setPromptText("Course");
		CourseComboBox.getItems().addAll(((Teacher)OnlineUser).getCoursesOfSubject(subjectID));
	}
@FXML public void reloadClickedListener() {
		ExamPreviewPane.setVisible(false);
		if (SubjectEComboBox.getValue() != null) {
			updateExamListBySubject(SubjectEComboBox.getValue().getID());
			if (CourseComboBox.getValue() != null)
				updateExamListByCourse(CourseComboBox.getValue().getID());
		} else
			ExamsList.getItems().clear();

	}
@FXML public void ClickViewExam(ActionEvent event) {
	
	if(ExamsList.getSelectionModel().getSelectedItem()== null)
	{
		alert("View Exam","You need to select an exam before you can view one");	
		return;		}
				
	ViewExamWindow = new Stage();
	ViewExamWindow.setTitle("View Exam");
	
	try {
		
		FXMLLoader loader = new FXMLLoader();
		Parent root1 = loader.load(getClass().getResource("ViewExamGUI.fxml").openStream());			
		ViewExamGUIController controller = loader.getController();
		controller.setQuestionsInExam(ExamsList.getSelectionModel().getSelectedItem().getQuestions());
		controller.setExam(ExamsList.getSelectionModel().getSelectedItem());			
		ViewExamWindow.setScene(new Scene(root1));
		ViewExamWindow.initModality(Modality.APPLICATION_MODAL);
		ViewExamWindow.initOwner(SubjectEComboBox.getScene().getWindow());
		ViewExamWindow.showAndWait();		
		
		
	} catch (IOException e) {			
		e.printStackTrace();
	}

	
}
@FXML
public void ClickRemoveExam(ActionEvent event) {
	Exam exam = ExamsList.getSelectionModel().getSelectedItem();
	boolean answer =confirmationAlert("Remove Exam","Are you sure you want to remove the selected exam from the database?");
	if(answer)
	{
		if(!(exam.getAuthor().getID().equals(GUI_LoginController.user.getID())))
		{
			alert("Remove Exam", "You do not have permission to remove exams' which were not composed by you");	
			return;
		}
		ExamController.removeExam(exam.getID());
		reloadClickedListener();
		ExamPreviewPane.setVisible(false);
		btn_remove.setDisable(true);
		ViewExamButton.setDisable(true);
		alert("Remove Exam","Exam has been removed from the database");
	}
}

//from here create
public void subjectSelectionListener() {
	ConfirmButton.setDisable(true);
	updateCreateCoursesBox(SubjectECComboBox.getValue().getID());
}
public void courseSelectionListener() {
	ConfirmButton.setDisable(false);
}
public void confirmButtonListener(ActionEvent event) {
	ExamCreateWindow = (Stage) ConfirmButton.getScene().getWindow();
	ExamCreateWindow.setTitle("Create exam");
	
	try {
		ExamCreateWindow = new Stage();
		ExamCreateWindow.setTitle("Create and submit exam");
		Course course = CourseECComboBox.getSelectionModel().getSelectedItem();
		Subject subject = SubjectECComboBox.getSelectionModel().getSelectedItem();
		Date date = new Date();  
	    SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");  
	    String strDate= formatter.format(date);  
	    FXMLLoader loader = new FXMLLoader(); 
	    Parent root = loader.load(getClass().getResource("CreateExam.fxml").openStream());			
		CreateExamsController  controller = loader.getController();
		Exam exam = new Exam(subject.getID()+course.getID(),course,subject,new Person(((Teacher)OnlineUser).getID(),((Teacher)OnlineUser).getName()),strDate,0);
		controller.setExam(exam);
		controller.updateQuestionsList();
		Scene scene = new Scene(root);
		ExamCreateWindow.setScene(scene);
		ExamCreateWindow.initModality(Modality.APPLICATION_MODAL);
		ExamCreateWindow.initOwner(SubjectECComboBox.getScene().getWindow());
		ExamCreateWindow.showAndWait();
		
		
		Rectangle2D primScreenBounds = Screen.getPrimary().getVisualBounds();
		ExamCreateWindow.setX((primScreenBounds.getWidth() - ExamCreateWindow.getWidth()) / 2);
		ExamCreateWindow.setY((primScreenBounds.getHeight() - ExamCreateWindow.getHeight()) / 2);
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}	  

}
public void updateCreateCoursesBox(String subjectID) {
	CourseECComboBox.getItems().clear();
	CourseECComboBox.setPromptText("Course");
	CourseECComboBox.getItems().addAll(((Teacher)OnlineUser).getCoursesOfSubject(subjectID));
}

public void executeButtonListener() {							

	TextInputDialog dialog = new TextInputDialog();		
	dialog.setTitle("Exam Execution");			
	dialog.setContentText("Enter 4 characters execution code: ");
	dialog.setHeaderText(null);
	Optional<String> result = dialog.showAndWait();
	if(result.isPresent())				
		if(result.get().length() == 4)				
			if(ExamController.executeExam(result.get(), ExamsList.getSelectionModel().getSelectedItem().getID(), ((Teacher)OnlineUser).getID() )) {
				dialog.close();
				alert("Exam Execution","Exam was successfully executed!");
			}
			else
				alert("Exam Execution","Code already in use.");
		else
			alert("Exam Execution", "You need to enter 4 characters code");
}


public void setConverters() {
	
		
		SubjectComboBox.setConverter(new StringConverter<Subject>() {
			public String toString(Subject subject) {
				return subject.getName();
			}

			@Override
			public Subject fromString(String arg0) {
				return null;
			}

		});
		SubjectEComboBox.setConverter(new StringConverter<Subject>() {
			public String toString(Subject subject) {
				return subject.getName();
			}

			@Override
			public Subject fromString(String arg0) {
				return null;
			}

		});
		SubjectCQComboBox.setConverter(new StringConverter<Subject>() {			

			@Override
			public String toString(Subject subject) {
				
				return subject.getName();
			}

			@Override
			public Subject fromString(String string) {
				// TODO Auto-generated method stub
				return null;
			}
		});
		SubjectECComboBox.setConverter(new StringConverter<Subject>() {
			public String toString(Subject subject) {
				return subject.getName();
			}

			@Override
			public Subject fromString(String arg0) {
				return null;
			}

		});

		
		CourseComboBox.setConverter(new StringConverter<Course>() {

			public String toString(Course course) {
				return course.getName();
			}

			@Override
			public Course fromString(String arg0) {
				return null;
			}

		});
		CourseECComboBox.setConverter(new StringConverter<Course>() {

			public String toString(Course course) {
				return course.getName();
			}

			@Override
			public Course fromString(String arg0) {
				return null;
			}

		});



		ExamsList.setCellFactory(lv -> {
			TextFieldListCell<Exam> cell = new TextFieldListCell<Exam>();
			cell.setConverter(new StringConverter<Exam>() {
				@Override
				public String toString(Exam exam) {
					return exam.getCreationDate() + "      Course: " + exam.getCourse().getName() + "      Author: "
							+ exam.getAuthor().getName();
				}

				@Override
				public Exam fromString(String string) {
					return null;
				}
			});
			return cell;
		});
	}
	@Override
public void initialize(URL arg0, ResourceBundle arg1) {
		// TODO Auto-generated method stub
		setConverters();
		this.HomePagePermission = GUI_LoginController.user.getPermission();
		CreateTreeView();
		ReloadExamsButton.setOnAction(e->reloadClickedListener());
		ViewExamButton.setOnAction(this::ClickViewExam);
		ConfirmButton.setOnAction(this::confirmButtonListener);
		
		QuestionList.getSelectionModel().selectedItemProperty().addListener(e -> {
			btn_editquestion.setVisible(true);
			btn_delete.setVisible(true);
			Question selectedQuestion = QuestionList.getSelectionModel().getSelectedItem();
			QuestionPreview(selectedQuestion);
			});
		
		QuestionList.setCellFactory(lv -> {
			TextFieldListCell<Question> cell = new TextFieldListCell<Question>();
			cell.setConverter(new StringConverter<Question>() {
				@Override
				public String toString(Question question) {
					return question.getQuestion();
				}

				@Override
				public Question fromString(String string) {
					return null;
				}
			});
			return cell;
		});
		ExamsList.getSelectionModel().selectedItemProperty().addListener(e -> {
				Exam exam = ExamsList.getSelectionModel().getSelectedItem();
				if (exam != null)
					showExamPreview(exam);
				ViewExamButton.setVisible(true);
				ExecuteExamButton.setVisible(true);
				btn_remove.setVisible(true);
			
		});
		ExamsList.setCellFactory(lv -> {
			TextFieldListCell<Exam> cell = new TextFieldListCell<Exam>();
			cell.setConverter(new StringConverter<Exam>() {
				@Override
				public String toString(Exam exam) {
					return "ID:"+exam.getID()+", subject:"+exam.getSubject().getName()+", course:"+exam.getCourse().getName();
				}

				@Override
				public Exam fromString(String string) {
					return null;
				}
			});
			return cell;
		});
		
	}

	
	
}
