package ClientGUI;

import java.net.URL;
import java.util.ResourceBundle;

import AES_Classes.AlertMessage;
import AES_Classes.Question;
import AES_Client.QuestionController;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;

public class QuestionViewGUIController implements Initializable{
	    @FXML private RadioButton q_answer2;
	    @FXML private RadioButton q_answer3;
	    @FXML private RadioButton q_answer1;
	    @FXML private TextField txt_ID;
	    @FXML private RadioButton q_answer4;
	    @FXML private TextField txt_Question;
	    @FXML private TextField txt_Author;
	    @FXML private TextField txt_correctAnswer;
	    @FXML private Button btn_save;
	    @FXML private Button btn_close;
	    
	    public static Question question;
	    private int changeAnswer=0; 
	    
	    public void CreateQuestionView() {
	    	
	    	txt_Question.setText(question.getQuestion());
	    	txt_ID.setText(question.getID());
	    	txt_Author.setText(question.getAuthor().getName());
	    	q_answer1.setText(question.getAnswer(1));
	    	q_answer2.setText(question.getAnswer(2));
	    	q_answer3.setText(question.getAnswer(3));
	    	q_answer4.setText(question.getAnswer(4));
	    	txt_correctAnswer.setText(Integer.toString(question.getCorrectAnswerIndex()));
	    	int correct = question.getCorrectAnswerIndex();
	    	RadioButtonSelection(correct);	

	    }
	    public void RadioButtonSelection(int correct) {
	    	
	    	q_answer1.setSelected(false);
	    	q_answer2.setSelected(false);
	    	q_answer3.setSelected(false);
	    	q_answer4.setSelected(false);
	    	switch(correct)
	    	{
	    	case 1:
	    		q_answer1.setSelected(true);
	    		q_answer1.requestFocus();
	    		break;
	    	case 2:
	    		q_answer2.setSelected(true);
	    		q_answer2.requestFocus();
	    	break;
	    	case 3:
	    		q_answer3.setSelected(true);
	    		q_answer3.requestFocus();
	    		break;
	    	case 4:
	    		q_answer4.setSelected(true);
	    		q_answer4.requestFocus();
	    		break;
	    	
	    	}  
	    }
	   
	    public void ClickRadioButton(int answer) {
	    	switch (answer) {
	    	case 1:
	    		RadioButtonSelection(1);
	    		txt_correctAnswer.setText("1");
	    		break;
	    	case 2:
	    		RadioButtonSelection(2);
	    		txt_correctAnswer.setText("2");
	    		break;
	    	case 3:
	    		RadioButtonSelection(3);
	    		txt_correctAnswer.setText("3");
	    	break;
	    	case 4:
	    		RadioButtonSelection(4);
	    		txt_correctAnswer.setText("4");
	    		break;
	    	}
	    	changeAnswer = answer;
	    	
	    	}

	    @FXML
	    public void ClickSaveChanges() {
	    	if(changeAnswer == 0){
	    		AlertMessage.Display("Save question error", "Nothing to change");
	    	}
	    	else  {
	    		
	    		QuestionController.updateCorrectAnswer(question.getID(),changeAnswer);
	    		AlertMessage.Display("Save question", "Save changes");
	    	}
	    	
	    	
	    }
	    @FXML
	    public void ClickClose(ActionEvent event) {
	    	    	
	    	btn_close.getScene().getWindow().hide();
	    }
		@Override
		public void initialize(URL arg0, ResourceBundle arg1) {
			// TODO Auto-generated method stub
			
			CreateQuestionView();
			btn_save.setOnAction(e->ClickSaveChanges());
			btn_close.setOnAction(this::ClickClose);
			q_answer1.setOnAction(e-> ClickRadioButton(1));
			q_answer2.setOnAction(e-> ClickRadioButton(2));
			q_answer3.setOnAction(e-> ClickRadioButton(3));
			q_answer4.setOnAction(e-> ClickRadioButton(4));
		
			
		}





}
