package AES_Server;

import java.net.URL;
import java.util.ResourceBundle;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;

public class ServerGUIController implements Initializable{

	Server server;
	@FXML private TextField txt_port;
	@FXML private TextField txt_address;
	@FXML private TextField txt_db_username;
	@FXML private PasswordField txt_db_password;
	@FXML private Button btn_connect;
	@FXML private Button btn_disconnect;
	@FXML private ListView<String> ListMsg;
	
	
	@FXML
	private void ClickConnect(ActionEvent event) 
	{
		Thread thread = new Thread(new Runnable(){
	          
		   
			public void run(){
		              int port=Integer.parseInt(txt_port.getText());              
		              String [] databaseConnection={txt_address.getText(),txt_db_username.getText(),String.valueOf(txt_db_password.getText())}; 
		            //  System.out.println(databaseConnection[0]+"  "+databaseConnection[1]+"  "+databaseConnection[2]);
		              server = new Server(port,databaseConnection,ListMsg);
				try 
				{
					server.listen(); 
				} 
				catch (Exception ex) 
				{
					ListMsg.getItems().add("ERROR - Could not listen for clients!");					
				}
				
		      }
		      });          
		        thread.start();

		}
	@FXML
	public void ClickDisconnect(ActionEvent e) {
		server.shutDown();
		ListMsg.getItems().add("Disconnected Successfully");
	}


	/**
	 * The constructor (is called before the initialize()-method).
	 */
	@Override
	public void initialize(URL location, ResourceBundle resc) {
		// TODO Auto-generated method stub
		
		//  Button event.
		btn_connect.setOnAction(this::ClickConnect);
		btn_disconnect.setOnAction(this::ClickDisconnect);
	}


}