package AES_Server;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import AES_Classes.Permission;
import AES_Classes.Teacher;
import AES_Classes.User;

public class UserController {

public static User logIn(String id, String password, String IP)
	{
	
		try {
			Statement stmt1= Server.conn.createStatement();
			Statement stmt2=Server.conn.createStatement();
			Statement stmt3=Server.conn.createStatement();
			
			ResultSet rs=stmt1.executeQuery("SELECT * FROM USERS WHERE ID='"+id+"' AND Password='"+password+"' ;");			
			if(rs.next()) {				
				//stmt2.executeUpdate("INSERT INTO ONLINEUSERS VALUES ('"+id+"','"+IP+"');");
				// new if this teacher
				
				if(rs.getString(3).equals("3"))
				{	
					ResultSet rs1=stmt3.executeQuery("SELECT * FROM TEACHERS WHERE ID='"+id+"';");
					rs1.next();
					return new Teacher(rs.getString(1),rs.getString(2),rs1.getString(2),rs1.getString(3),CourseAndSubjectController.getSubjectList(rs1.getString(1)),CourseAndSubjectController.getCourseList(rs1.getString(1)));
					
				}

			}
		} 
			catch (SQLException e) {
				System.out.println(e);
				return new User("0", "0", Permission.NONE); 
		}
		return null;
	}
	
	public static void logOut(String ID)
	{ 
		
			Statement stnt;
			try {
				stnt = Server.conn.createStatement();
				stnt.executeUpdate("DELETE FROM OnlineUsers WHERE ID='"+ID+"';");
			} catch (SQLException e) {				
				e.printStackTrace();
			}
			
		
		
	}
	
	

}
