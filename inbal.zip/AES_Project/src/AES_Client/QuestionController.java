package AES_Client;

import java.util.ArrayList;

import AES_Classes.Packet;
import AES_Classes.Question;
import ClientGUI.MainClient;

public class QuestionController {

public static ArrayList<Question> getQuestionList()
{
	int ID=MainClient.client.sendToServerAJ(new Packet("GetQuestionsList",null));
	return (ArrayList<Question>) MainClient.client.getResponse(ID).getData();
}
public static ArrayList<Question> getQuestionListBySubject()
{
	int ID=MainClient.client.sendToServerAJ(new Packet("GetQuestionListBySubject",null));
	return (ArrayList<Question>) MainClient.client.getResponse(ID).getData();
}



public static void updateCorrectAnswer(String ID,int indexNumber)
{
	ArrayList arrayList = new ArrayList();
	arrayList.add(ID);
	arrayList.add(indexNumber);
	MainClient.client.sendToServerAJ(new Packet("UpdateAnswer",arrayList));
}
	
}
