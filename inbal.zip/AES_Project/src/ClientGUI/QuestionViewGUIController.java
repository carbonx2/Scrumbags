package ClientGUI;

import java.net.URL;
import java.util.ResourceBundle;

import AES_Classes.Question;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;

public class QuestionViewGUIController implements Initializable{
	    @FXML private RadioButton q_answer2;
	    @FXML private RadioButton q_answer3;
	    @FXML private RadioButton q_answer1;
	    @FXML private TextField txt_ID;
	    @FXML private RadioButton q_answer4;
	    @FXML private TextField txt_Question;
	    @FXML private TextField txt_Author;
	    @FXML private TextField txt_correctAnswer;
	    public static Question question;
	    
	    public void CreateQuestionView() {
	    	txt_ID.setText(question.getID());
	    	txt_Author.setText(question.getAuthor().getName());
	    	q_answer1.setText(question.getAnswer(1));
	    	q_answer2.setText(question.getAnswer(2));
	    	q_answer3.setText(question.getAnswer(3));
	    	q_answer4.setText(question.getAnswer(4));
	    	txt_correctAnswer.setText(question.getCorrectAnswer());
	    	int correct = question.getCorrectAnswerIndex();
	    	switch(correct)
	    	{
	    	case 1:
	    		q_answer1.setSelected(true);
	    		break;
	    	case 2:
	    	break;
	    	case 3:
	    		break;
	    	case 4:
	    		break;
	    	
	    	}
	    	

	    }
	    
		@Override
		public void initialize(URL arg0, ResourceBundle arg1) {
			// TODO Auto-generated method stub
			
		}





}
