package AES_Classes;

public class Subject {

	String name;
	String ID;
		
	
	public Subject(String name,String ID)
	{
		this.name=name;
		this.ID=ID;
	}
	
	
	public String getName() {
		return name;
	}	


	public String getID() {
		return ID;
	}

	
	
}
