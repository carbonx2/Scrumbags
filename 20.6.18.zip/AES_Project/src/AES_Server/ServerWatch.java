package AES_Server;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;

import java.util.SortedSet;import java.util.TreeSet;
import java.util.concurrent.locks.ReentrantLock;

import AES_Classes.Exam;
import AES_Classes.Examinee;
import AES_Classes.Student;
import OCSF.Server.ConnectionToClient;
import AES_Server.ExamController;

public class ServerWatch {

	/**==================================
	 *=Server watch parameters========== 
	 *==================================
	 */
	public static HashMap<String,TreeSet<Examinee>> activeExaminees = new HashMap<String,TreeSet<Examinee>>();	
	public static ReentrantLock examLock = new ReentrantLock();
	public static ArrayList<Examinee> examineesToRemove= new ArrayList<Examinee>();
	public static ReentrantLock userLock = new ReentrantLock();
	public static HashMap <String,ConnectionToClient> onlineUsers = new  HashMap <String,ConnectionToClient>();
	public static ArrayList<String> usersToRemove = new ArrayList<String>();
	public static boolean watch = false;
	
	/**	 
	   *  This method add exam to Examine table in database.
	   * @param client Student user who take exam
	   * @param student who take exam
	   * @param exam The exam that taking by student	
	   * @param examExecutionCode the code that student insert
	   * Give finish time to exam by exam time
	   * Create new examine by examExecutionCode
	   * @return list of exam details: exam , code, student , status of exam
	   */
	public static ArrayList<Object> addExaminee(ConnectionToClient client, Student student, Exam exam, String examExecutionCode, String type)
	{
		
		if(!watch)	
		{				
			watch = true;
			startWatch();
		}
		
		Calendar cal = Calendar.getInstance();
		Date startTime =  cal.getTime();
		cal.add(Calendar.MINUTE, exam.getExamTime());	
		Date finishTime = cal.getTime();
		
		examLock.lock();	
		if(ExamController.checkExamCode(examExecutionCode, student.getID()).equals("ExamCodeDoesntExist"))
			return null;
		ArrayList<Object> examineeS = new ArrayList<Object>();
		String examineeStatus = "Old";
		userLock.lock();                                    /*
														**    only because we dont have login
															*/
		onlineUsers.put(student.getID(), client);
		userLock.unlock();
		Examinee examinee = getExaminee(student.getID(),examExecutionCode);	
		if(examinee == null)		
		{
			examineeStatus = "New";			
			examinee = new Examinee(student,exam,examExecutionCode, startTime, finishTime);			
			TreeSet<Examinee> tempSet = activeExaminees.get(examExecutionCode);			
			if(tempSet==null) {
				tempSet=new TreeSet<Examinee>();
				activeExaminees.put(examExecutionCode,tempSet);
			}			
			tempSet.add(examinee);
			
		}
	
		examinee.setType(type);
			
		examineeS.add(examineeStatus);
		examineeS.add(examinee);		
		examLock.unlock();
			
			
		return examineeS;
	}

	/**	 
	   *fill
	   */
	private static void startWatch()
	{
		
		new Thread(new Runnable() {
			@Override
			public void run() {
				while(true)
				{		
					
					try {
						Thread.sleep(1000);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
					Date currentTime = new Date();					
					examLock.lock();
					for(TreeSet<Examinee> examinees : activeExaminees.values())		
					{
						for(Examinee examinee:examinees) {
							if(examinee.getFinishTime().compareTo(currentTime)==1)
								break;
							
							else
							{
								userLock.lock();
								if(onlineUsers.get(examinee.getID()) != null )								
									ExamController.endExam(onlineUsers.get(examinee.getID()),"Timeout");	
								else
									ExamController.submitEmptyExam(examinee, "Offline");									
								userLock.unlock();
							}
								
							
						}
					}
					if(!examineesToRemove.isEmpty()) {
						for(Examinee examinee:examineesToRemove) {
							activeExaminees.get(examinee.getExamExecutionCode()).remove(examinee);	
							if(activeExaminees.get(examinee.getExamExecutionCode()).isEmpty()) 							
								ExamController.removeActiveExam(examinee.getExamExecutionCode());
							
							
						}
						examineesToRemove.clear();
					}
					examLock.unlock();
					
					userLock.lock();
					for (String user : onlineUsers.keySet())
						if(!onlineUsers.get(user).isAlive())
							usersToRemove.add(user);
					if(!usersToRemove.isEmpty())
					{
						for(String user : usersToRemove)
							onlineUsers.remove(user);
						usersToRemove.clear();
					}	
					
					userLock.unlock();
				}
			}
		}).start();
	}
	/**	 
	   *  This method add user to online user list
	   * @param userID The id of user to add 
	   * @param client The user the connect to client
	   * Add by user id the user if not exist in the list
	   * @return true , add the user 
	   * @return false , not adding the user - exist in list
	   */
	public static boolean  addUser(String userID, ConnectionToClient client)
	{
		if(!watch)	
		{				
			watch = true;
			startWatch();
		}
		
		if(onlineUsers.get(userID)==null)
		{	userLock.lock();
			onlineUsers.put(userID, client);
			userLock.unlock();
			return true;
		}
		return false;
	}
	/**	 
	   *  This method remove user to online user list
	   * @param userID The id of user to remove 
	   */
	 public static void removeUser(String userID)
	 {
		userLock.lock();
		usersToRemove.add(userID);
		userLock.unlock();
	 }

		/**	 
	   *  This method lock exam  \ remove exam from active exams 
	   * @param examExecutionCode The code of the exam
	   * If student take exam , close the exam in student system
	   */
	 public static void lockExam(String examExecutionCode)
		{		

			examLock.lock();	

			if(activeExaminees.get(examExecutionCode)!=null)
			{
				for(Examinee examinee : activeExaminees.get(examExecutionCode)) {						
					{					
						if(onlineUsers.get(examinee.getID())!=null)
							ExamController.endExam(onlineUsers.get(examinee.getID()),"LockExam");
						else
							ExamController.submitEmptyExam(examinee, "OfflineAndLockExam");	
					}
				}
			}
			
			else
			ExamController.removeActiveExam(examExecutionCode);
			
			examLock.unlock();
		}
	/**	 
	   *  This method remove exam to Examine table in database.
	   * @param examinee The examine exam to remove
	   */	
		public static void removeExaminee(Examinee examinee) {
			examLock.lock();
			examineesToRemove.add(getExaminee(examinee.getID(),examinee.getExamExecutionCode()));		
			examLock.unlock();
		}
	/**	 
	   *  This method add exam to Examine table in database.
	   * @param examineeID examine id to get
	   * @param examExecutionCode the code to get exam
	   * Search by code the exam and then check if exam id equals
	   * @return examine we search
	   */
		public static Examinee getExaminee(String examineeID, String examExecutionCode)
		{

			if(activeExaminees.get(examExecutionCode)!=null)
				for(Examinee examinee : activeExaminees.get(examExecutionCode))		
					if(examinee.getID().equals(examineeID))
						return examinee;
			return null;
		}

}
