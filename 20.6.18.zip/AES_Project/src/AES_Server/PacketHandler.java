package AES_Server;

import java.util.ArrayList;

import AES_Classes.Course;
import AES_Classes.Exam;
import AES_Classes.Packet;
import AES_Classes.Permission;
import AES_Classes.Question;
import AES_Classes.SchoolManager;
import AES_Classes.Student;
import AES_Classes.Subject;
import AES_Classes.Teacher;
import AES_Classes.User;
import AES_Classes.Examinee;
import AES_Classes.FinishedExam;
import OCSF.Server.ConnectionToClient;
import AES_Server.ExamController;
import AES_Server.QuestionController;
import AES_Server.UserController;
import AES_Classes.ManualExamFile;

public class PacketHandler {
	
	/**
	    * This method Will handle client requests from the server side 
	    * Any request from the customer will send a corresponding controller
	    	**QuestionController - request that Related to questions
	    	**ExamController - request that Related to exams
	    	**UserController- request that Related to users
	    * After all handle response packet will sent to client with is responseID , answer = "Success" or answer = "Failure" , and data
	     * @param packet  giving by client , Operation - the request handle and Data from client to handle
	     * @param client the connection of specific client the give the request
	    */

	public static void handlePacket(Packet packet, ConnectionToClient client) throws Exception {
		Packet userPacket;
		Object data = null;
		String answer = "Success";
		
		switch (packet.getOperation()) {
		case "AddQuestion":
			answer = QuestionController.addQuestionToRepository((Question) packet.getData());
			break;
		case "GetQuestionsList":
			data = QuestionController.getQuestionsList();
			if (data == null)
				answer = "Failure";
			break;
		case "RemoveQuestion":
			answer = QuestionController.removeQuestion((String) packet.getData());
			break;
		case "UpdateAnswer":
			answer = QuestionController.updateCorrectAnswer((String) ((ArrayList) packet.getData()).get(0),
					(int) ((ArrayList) packet.getData()).get(1));
			break;
		case "GetQuestionListBySubject":
			data = QuestionController.getQuestionsOfSubject((String) packet.getData());
			if (data == null)
				answer = "Failure";
			break;
		case "AddExam":
			answer = ExamController.addExamToRepository((Exam) packet.getData());
			break;
		case "GetExamsList":
			data = ExamController.getExamsList();
			if (data == null)
				answer = "Failure";
			break;
		case "GetExamsListBySubject":
			data = ExamController.getExamsListBySubject((String) packet.getData());
			if (data == null)
				answer = "Failure";
			break;
		case "RemoveExam":
			answer = ExamController.removeExamFromRepository((String) packet.getData());
			break;
			
		case "ExecuteExam": 
			ArrayList<Object> data1 = (ArrayList<Object>) packet.getData();
			String executionCode = (String) data1.get(0);
			Exam exam1 = (Exam) data1.get(1);
			String teacherID = (String) data1.get(2);		
			boolean answer1 = ExamController.executeExam(executionCode, exam1, teacherID);			
			if (!answer1)
				answer="Failure";
			break;			
			
		case "CheckExamCode":
			ArrayList<String> arrayList = (ArrayList<String>) packet.getData();			
			answer=ExamController.checkExamCode(arrayList.get(0),arrayList.get(1));
			break;
			
		case "TakeExam":
			data = ExamController.takeExam((String)packet.getData());
			break;
			
		case "StartExam":
			ArrayList data2 = ((ArrayList)packet.getData());
			Student student = (Student) data2.get(0);
			Exam exam = (Exam) data2.get(1);
			String examExecutionCode = (String) data2.get(2);
			data2 = ExamController.startExam(client, student, exam, examExecutionCode);
			answer = "ExamIsNotActive";
			data = null;
			if (data2!=null)
			{	
			answer = (String) data2.get(0);
			data = data2.get(1);			
			}						
			break;
		case "SubmitExam":
			ArrayList data3 = ((ArrayList)packet.getData());
			ExamController.submitExam((FinishedExam)data3.get(0), (Examinee)data3.get(1), (String)data3.get(2));	
			packet.setID(-1);
			answer= "Submitted";
			break;
		case "GetActiveExams":
			data = ExamController.getActiveExams((String) packet.getData());
			break;
			
		case "LockExam":
			ExamController.lockExam((String) packet.getData());
			break;
		case "TakeManualExam":		
			ArrayList data4 = ((ArrayList)packet.getData());
			Student student1 = (Student) data4.get(0);			
			String examExecutionCode1 = (String) data4.get(1);
			data = ExamController.takeManualExam(client, student1, examExecutionCode1);
			answer = "ExamIsNotActive";			
			if (data!=null)			
				answer = (String) ((ArrayList)data).get(0);					
			break;
		case "SubmitManualExam":
			ArrayList data7 = ((ArrayList)packet.getData());
			ExamController.submitManualExam((ManualExamFile)data7.get(0), (Examinee)data7.get(1), (String)data7.get(2));
			packet.setID(-1);
			answer= "Submitted";
			break;			
		case "GetCourseList":
			ArrayList<Course> courseList=CourseAndSubjectController.getCoursesList();
			Packet packet6= new Packet("Success",courseList);
			packet6.setID(packet.getID());				
			client.sendToClient(packet6);
			break;
		case "GetAllSubjectsList":
			ArrayList<Subject> subjectList=CourseAndSubjectController.getAllSubjects();
			Packet packet7= new Packet("Success",subjectList);
			packet7.setID(packet.getID());				
			client.sendToClient(packet7);
			break;
		case "GetIDSubjectByName":
			String subjectID = CourseAndSubjectController.getIdSubjectByName((String)packet.getData());
			Packet packet8= new Packet("Success",subjectID);
			packet8.setID(packet.getID());				
			client.sendToClient(packet8);
			break;
		case "GetTeachersList":
			ArrayList<Teacher> TeacherList=UserController.getTeachersList();
			Packet packet9= new Packet("Success",TeacherList);
			packet9.setID(packet.getID());				
			client.sendToClient(packet9);
			break;
		case "GetStudentList":
			ArrayList<Student> StudentList=UserController.getStudentsList();
			Packet packet12= new Packet("Success",StudentList);
			packet12.setID(packet.getID());				
			client.sendToClient(packet12);
			break;
			
		case "GetUsersList":
			ArrayList<User> userList=UserController.getUsersList();
			Packet packet10= new Packet("Success",userList);
			packet10.setID(packet.getID());				
			client.sendToClient(packet10);
			break;
		case "GetManagerList":
			ArrayList<SchoolManager> managerList=UserController.getmanagerList();
			Packet packet11= new Packet("Success",managerList);
			packet11.setID(packet.getID());				
			client.sendToClient(packet11);
			break;
		case "GetFinishedExamsByID":
			data = ExamController.getFinishedExamsById((String)packet.getData());
			break;
			
		case "ConfirmExam":
			FinishedExam exam9 = (FinishedExam) packet.getData();
			ExamController.confirmExam(exam9);
			break;	
		case "LogIn":
			Packet userPacket1;			
			ArrayList<Object> arrayList1;
			String id = (String) ((ArrayList) packet.getData()).get(0);
			String password = (String) ((ArrayList) packet.getData()).get(1);			
			arrayList1 = UserController.logIn(id, password, client);
			
			if (arrayList1 != null) {
				answer = (String) arrayList1.get(0);
				data = arrayList1.get(1);
			}
			break;
				
		case "LogOut":
			UserController.logOut((String) packet.getData());
			break;

		}
		
		userPacket = new Packet(answer, data);
		userPacket.setID(packet.getID());
		client.sendToClient(userPacket);

	}
}
