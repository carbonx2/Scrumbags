package AES_Server;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashSet;

import AES_Classes.Course;
import AES_Classes.Permission;
import AES_Classes.SchoolManager;
import AES_Classes.Student;
import AES_Classes.Subject;
import AES_Classes.Teacher;
import AES_Classes.User;
import OCSF.Server.ConnectionToClient;

public class UserController {

	/**
	 * This method return list to login controller
	    * Receive from client request to log in with user details : Id , password and IP of client 
	    * will check in data base if user exist and return a arratList accordingly , The arraylist will be an answer and an object
	    * * if exist, will return to client new user depending on the type of user and success in answer 
	    * * if not exist ,will return client failure answer only  	    
	    */
	public static ArrayList<Object> logIn(String ID, String password, ConnectionToClient client)
	{
		User user = null;
		ArrayList<Object> arrayList = new ArrayList<Object>();
		String answer = "Failure";
		
	
	
		try {
			Statement stmt1= Server.conn.createStatement();
			Statement stmt2=Server.conn.createStatement();		
			ResultSet rs=stmt1.executeQuery("SELECT * FROM USERS WHERE ID='"+ID+"' AND Password='"+password+"' ;");	
			
			
			if(rs.next()) {		
				if(!ServerWatch.addUser(ID, client))
				{
					answer = "AlreadyLoggedIn";
					arrayList.add(answer);
					arrayList.add(user);
					return arrayList;
				}
				ResultSet rs1;				
				switch (rs.getString(3))
				{
				case "1":					
					rs1=stmt2.executeQuery("SELECT * FROM STUDENTS WHERE ID='"+ID+"';");
					if(rs1.next()) {
						answer = "Sucsses"	;
					 user = new Student(rs.getString(1),rs.getString(2),rs1.getString(2),rs1.getString(3));
					}				
					break;
					
				case "2":
					rs1=stmt2.executeQuery("SELECT * FROM TEACHERS WHERE ID='"+ID+"';");
					if(rs1.next()) {
						answer = "Sucsses"	;
						 user = new Teacher(rs.getString(1),rs.getString(2),rs1.getString(2),rs1.getString(3),CourseAndSubjectController.getTeacherSubjects(ID),CourseAndSubjectController.getTeacherCourses(ID));
					}
					break;		
				case "3":
					rs1=stmt2.executeQuery("SELECT * FROM SCHOOLMANAGERS WHERE ID='"+ID+"';");
					if(rs1.next()) {
						answer = "Sucsses"	;
						user = new SchoolManager(rs.getString(1),rs.getString(2),rs1.getString(2),rs1.getString(3));
					}
					break;	
				}
						
				
				
				}
			arrayList.add(answer);
			arrayList.add(user);
			return arrayList;
			
		} 
			
			catch (SQLException e) {
				e.printStackTrace();
				
				return null;		}
		
	}
	
	/**
	 * Receive from client request to log out with user details : Id 
	 * will delete the user from data base 	    
	 */
	public static void logOut(String userID)
	{ 		
		ServerWatch.removeUser(userID);	
		
		
	}
	public static ArrayList<SchoolManager> getmanagerList(){
		try {
			Statement stmt = Server.conn.createStatement();
			ResultSet rs1 = stmt.executeQuery("SELECT * FROM SCHOOLMANAGERS;");
			ArrayList<SchoolManager> arrayListOfmanagers = new ArrayList<SchoolManager>();
			while(rs1.next())
			{
				String password=UserController.getUserPassword(rs1.getString(1));
				SchoolManager manager=new SchoolManager(rs1.getString(1),password,rs1.getString(2),rs1.getString(3));
				arrayListOfmanagers.add(manager);
			}
			
			return arrayListOfmanagers;
		} catch (SQLException e) {			
			e.printStackTrace();
			return null;
		}
					
	}
	public static ArrayList<User> getUsersList(){
		try {
			Statement stmt = Server.conn.createStatement();
			ResultSet rs1 = stmt.executeQuery("SELECT * FROM USERS;");
			ArrayList<User> arrayListOfUsers = new ArrayList<User>();
			while(rs1.next())
			{
				User user=null;
				if(Integer.parseInt(rs1.getString(3))==1){
					user=new User(rs1.getString(1),rs1.getString(2),Permission.STUDENT);
				}else if(Integer.parseInt(rs1.getString(3))==2)
				{
					user=new User(rs1.getString(1),rs1.getString(2),Permission.TEACHER);
				}else if(Integer.parseInt(rs1.getString(3))==3) {
					user=new User(rs1.getString(1),rs1.getString(2),Permission.MANAGER);
				}
			
				arrayListOfUsers.add(user);
			}
			
			return arrayListOfUsers;
		} catch (SQLException e) {			
			e.printStackTrace();
			return null;
		}
					
	}
	public static String getUserPassword(String id)
	{
		try {
			Statement stmt = Server.conn.createStatement();
			ResultSet rs1 = stmt.executeQuery("SELECT * FROM USERS WHERE ID='"+id+"';");
			String password=null;
			while(rs1.next())
			{
				password=rs1.getString(2);
			}
			return password;
		}catch (SQLException e) {	
			System.out.println(e);
			e.printStackTrace();
			return null;
		}
	}
	public static ArrayList<Teacher> getTeachersList(){
		try {
			Statement stmt = Server.conn.createStatement();
			ResultSet rs1 = stmt.executeQuery("SELECT * FROM TEACHERS;");
			ArrayList<Teacher> arrayListOfTeachers = new ArrayList<Teacher>();
			HashSet<Subject> subjectList;
			HashSet<Course> coursesList;
			String id;
			String password;
			String firstName;
			String lastName;
			while(rs1.next())
			{
				id=rs1.getString(1);
				firstName=rs1.getString(2);
				lastName=rs1.getString(3);
				subjectList=CourseAndSubjectController.getTeacherSubjects(id);
				coursesList=CourseAndSubjectController.getTeacherCourses(id);
				password=UserController.getUserPassword(id);
				Teacher teacher=new Teacher(id,password,firstName,lastName,subjectList,coursesList); 
				arrayListOfTeachers.add(teacher);
			}
			
			return arrayListOfTeachers;
		} catch (SQLException e) {			
			e.printStackTrace();
			return null;
		}
					
	}
	public static ArrayList<Student> getStudentsList(){
		try {
			Statement stmt = Server.conn.createStatement();
			ResultSet rs1 = stmt.executeQuery("SELECT * FROM STUDENTS;");
			ArrayList<Student> arrayListOfstudents = new ArrayList<Student>();
			while(rs1.next())
			{
				String password=UserController.getUserPassword(rs1.getString(1));
				Student students=new Student(rs1.getString(1),password,rs1.getString(2),rs1.getString(3));
				arrayListOfstudents.add(students);
			}
			
			return arrayListOfstudents;
		} catch (SQLException e) {			
			e.printStackTrace();
			return null;
		}
					
	}
	

	
	

}
