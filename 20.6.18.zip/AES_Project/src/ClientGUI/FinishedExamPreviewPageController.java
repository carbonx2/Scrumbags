package ClientGUI;

import AES_Classes.FinishedExam;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;

public class FinishedExamPreviewPageController {

	private FinishedExam exam;
    @FXML
    private Label CourseNameLabel;

    @FXML
    private Label AuthorLabel;

    @FXML
    private Label DateLabel;

    @FXML
    private Label ExamTimeLabel;

    @FXML
    private ScrollPane NoteScrollPane;

    @FXML
    private Label ExamNotesLabel;

    @FXML
    private Label GradeLabel;

    @FXML
    private TextField GradeTextField;

    @FXML
    private TextArea GradeReasonTextArea;
	private FinishedExamGUIController finishedExamGUIController;
    
    
    public void setExam(FinishedExam exam) {	
    	this.exam = exam;
		DateLabel.setText(exam.getCreationDate());
		CourseNameLabel.setText(exam.getCourse().getName());
		AuthorLabel.setText(exam.getAuthor().getName());
		ExamNotesLabel.setText(exam.getNote());
		ExamTimeLabel.setText(ExamTimeLabel.getText()+" "+exam.getExamTime());		
		GradeTextField.setText(""+(exam.getGrade()>exam.getFinalGrade()?exam.getGrade():exam.getFinalGrade()));
		GradeReasonTextArea.setText(exam.getGradeNote());
		if(exam.getFinalGrade() != -1)
		{
			GradeTextField.setDisable(true);
			GradeReasonTextArea.setDisable(true);
			if(GradeReasonTextArea.getText().length()>0 && !GradeReasonTextArea.getText().equals("null") )
				GradeReasonTextArea.setVisible(true);
		}
	}
    
    public void gradeTextFieldListener() {
    	
    	if(GradeTextField.getText().trim().length()>0) {
    		
    		if(GradeTextField.getText().charAt(0)=='0') 
    			GradeTextField.setText(GradeTextField.getText().substring(1));
    		if (!GradeTextField.getText().matches("\\d*"))
    			GradeTextField.setText(GradeTextField.getText().replaceAll("[^\\d]", ""));	
    		if(Integer.parseInt(GradeTextField.getText())>100) 
    			GradeTextField.setText(""+100);
    		
    	}
    		
    	if(GradeTextField.getText().equals(Integer.toString(exam.getGrade()))) {
    		GradeReasonTextArea.setVisible(false);
    		finishedExamGUIController.setConfirmationButtonStatus(true);
    	}
    	else {
    		GradeReasonTextArea.setText("");
    		GradeReasonTextArea.setVisible(true);
    		if(GradeReasonTextArea.getText().trim().length()==0)
    			finishedExamGUIController.setConfirmationButtonStatus(false);
    	}
    	
    		
    }
    
    public void GradeReasonTextAreaListener() {
    	if(GradeReasonTextArea.getText().trim().length()==0)
    		finishedExamGUIController.setConfirmationButtonStatus(false);
    	else
    		finishedExamGUIController.setConfirmationButtonStatus(true);
    }
    
    public void setfinishedExamGUIController(FinishedExamGUIController controller) {
    	this.finishedExamGUIController= controller;
    }
    
    public void confirmExam() {
    	exam.setGradeNote(GradeReasonTextArea.getText());
    	exam.setFinalGrade(Integer.parseInt(GradeTextField.getText()));
    }
}
