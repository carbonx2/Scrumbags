package ClientGUI;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.ResourceBundle;

import AES_Classes.FinishedExam;
import AES_Classes.QuestionInExam;
import AES_Client.ExamController;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Insets;
import javafx.scene.Node;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Pagination;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.VBox;
import javafx.stage.WindowEvent;

public class FinishedExamGUIController  implements Initializable {
	public static final int itemsPerPage = 4;
	public ObservableList<QuestionInExam> questionsInExamList;
	private ArrayList<Node> questionsPagesLayouts;
	private ArrayList<FinishedQuestionPaneController> questionControllers;
	@FXML
	private AnchorPane OurAnchorPane;
	@FXML
	public Pagination pagination;
	
	@FXML
	public Button ConfirmButton;
	private FinishedExamPreviewPageController firstPageController;
	private Node firstPageLayout;
	private FinishedExam exam;
	private HomePageController Homepage;
	
	public void setManageExamsController(HomePageController manageExamsController)
	{
		this.Homepage = manageExamsController;
	}	

	public void setConfirmationButtonStatus(boolean state)
	{
		if(state)
			ConfirmButton.setDisable(false);
		else
			ConfirmButton.setDisable(true);
	}

	public void initPages() {
		FXMLLoader loader = new FXMLLoader();
		try {
			Node layout = loader.load(getClass().getResource("FinishedExamPreviewPage.fxml").openStream());
			FinishedExamPreviewPageController controller = loader.getController();
			controller.setExam(exam);			
			controller.setfinishedExamGUIController(this);
			firstPageController = controller;
			firstPageLayout = layout;
		} catch (IOException e) {
			
			e.printStackTrace();
		}
		for(int pageIndex=0;pageIndex<pagination.getPageCount()-1;pageIndex++) {
			VBox box = new VBox();			
			for(int i = 0; i < itemsPerPage && (pageIndex)*4+i<questionsInExamList.size() ; i++) {
				try {
					loader = new FXMLLoader();
					Node layout = loader.load(getClass().getResource("FinishedQuestionPane.fxml").openStream());
					FinishedQuestionPaneController controller = loader.getController();
					controller.setFinishedExamWindowController(this);
					QuestionInExam question =questionsInExamList.get((pageIndex)*4+i);					
					controller.setQuestion(question, (pageIndex)*4+i+1,exam.getAnswers().get(question.getID()), exam.getCheckedQuestionsNote().get(question.getID()));					
					questionControllers.add(controller);
					box.getChildren().add(layout);
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			box.setStyle("-fx-background-color: white;");
			box.setPadding(new Insets(0,0,0,20));
			questionsPagesLayouts.add(box);
			
		}
	}


	public ScrollPane createPage(int pageIndex) {
			ScrollPane scrollPane = new ScrollPane();
			if(pageIndex==0) 
				scrollPane.setContent(firstPageLayout);
			else 
				scrollPane.setContent(questionsPagesLayouts.get(pageIndex-1));
			scrollPane.getStylesheets().add("FixScrollbar.css");
			return scrollPane;

	}

	public void setPageCount() {
		if (questionsInExamList.size() % itemsPerPage == 0)
			pagination.setPageCount(questionsInExamList.size() / itemsPerPage + 1);

		else
			pagination.setPageCount(questionsInExamList.size() / itemsPerPage + 2);

	}

	public void setExam(FinishedExam exam) {
		this.exam = exam;
		questionsInExamList.setAll(exam.getQuestions());
		setPageCount();
		initPages();
		if(exam.getFinalGrade()!=-1)		
			ConfirmButton.setDisable(true);
	}
	
	public void confirmButtonListener() {
		firstPageController.confirmExam();
		HashMap<String, String> questionsNote = new HashMap<String, String>();
		for(FinishedQuestionPaneController questionController : questionControllers) 			
			questionsNote.put(questionController.getQuestion().getID(), questionController.getNote()); 
		
		exam.setCheckedQuestionsNote(questionsNote);
		ExamController.confirmExam(exam);
		Homepage.updateFinishedExamsList();
		ConfirmButton.getScene().getWindow().hide();
		alert("Exam Submitted","Exam has been confirmed");
	}
	
	public FinishedExam getExam()
	{
		return exam;
	}
	
	public void alert(String title,String message)
	{		
		Alert alert = new Alert(AlertType.INFORMATION);
		alert.setTitle(title);
		alert.setHeaderText(null);
		alert.setContentText(message);
		alert.showAndWait();
	}

	public void onCloseOperation(WindowEvent event)
	{
		event.consume();		
	}


	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		// TODO Auto-generated method stub
		pagination.setPageFactory((Integer pageIndex) -> createPage(pageIndex));
		firstPageController = null;
		firstPageLayout = null;
		questionControllers = new ArrayList<FinishedQuestionPaneController>();
		questionsInExamList = FXCollections.observableArrayList();
		questionsPagesLayouts = new ArrayList<Node>();
	}


}
