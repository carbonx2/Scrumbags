package AES_Classes;

import java.io.Serializable;

public class Course implements Serializable {

	String name;
	String ID;
	String subjectID;
		
	/**
	 * This method Create new course
	 * @param ID  unique number to present course 
	 * @param name  name of the course
	 * @param subjectID  The subject id to which the course belongs
	 */
	public Course(String ID,String name, String subjectID)
	{
		this.ID=ID;
		this.name=name;
		this.subjectID=subjectID;
	}
	
	/**
	 * @return subjectID This method Return The subject id to which the course belongs
	  */
	public String getSubjectID() {
		return subjectID;
	}
	public void setSubjectID(String subjectID) {
		this.subjectID = subjectID;
	}
	/**
	 * @return name This method Return course name
	  */
	public String getName() {
		return name;
	}	
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @return ID This method Return course id
	  */
	public String getID() {
		return ID;
	}
	public void setID(String ID) {
		this.ID = ID;
	}
	/**
	 * This method Return all course details
	  */
	public String toString()
	{
		return "ID(" + ID + "), name(" + name + "), subjectID(" + subjectID + ")";
	}
	
}