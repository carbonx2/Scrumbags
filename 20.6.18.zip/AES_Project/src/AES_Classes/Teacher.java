package AES_Classes;

import java.io.Serializable;
import java.util.HashMap;
import java.util.HashSet;

public class Teacher extends User implements Serializable {
	String firstName;
	String lastName;
	HashSet<Subject> subjects;                           
	HashMap<String, HashSet<Course>> courses;   
	
	public Teacher(String ID, String password, String firstName, String lastName,  HashSet<Subject> subjects, HashSet<Course> courses) {
		super(ID,password,Permission.TEACHER);
		this.firstName=firstName;
		this.lastName=lastName;
		this.subjects=subjects;

		HashSet<Course> coursesSet;
		this.courses=new HashMap<String, HashSet<Course>>();
		for(Course course : courses)		
		{
			coursesSet = this.courses.get(course.getSubjectID());
			if(coursesSet==null) {
				coursesSet=new HashSet<Course>();
				this.courses.put(course.getSubjectID(), coursesSet);
			}
			coursesSet.add(course);
		}

	}
	
	public String toString()
	{
		return "Name:"+firstName+" Last Name:"+lastName+" ID:"+getID()+" Permission:"+getPermission();
	}
	
	public String getName()
	{
		return firstName+" "+lastName;
	}
	

	public HashSet<Course> getCoursesOfSubject(String subject) {
		return courses.get(subject);
	}

	public HashSet<Subject> getSubjects() {
		return subjects;
	}
	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

}
