package AES_Classes;

import java.io.Serializable;

public class Packet implements Serializable  {
	String operation;
	Object data;
	int ID;
	/**
	 * This method Create new packet 
	 * packet package is responsible for transferring information between client and server
	 * @param operation  explanation of What we want to do 
	 * @param data  Object to handle by operation function
	 */
	public Packet(String operation, Object data)
	{
		this.operation=operation;
		this.data=data;
	}
	/**
	 * @return operation This method Return explanation of What we want to do 
	  */
	public String getOperation() {
		return operation;
	}
	/**
	 * @return data This method Return Object to handle by operation function 
	  */
	public Object getData() {
		return data;
	}
	/**
	 * This method add to packet id number 
	  */
	public void setID(int ID)
	{
		this.ID=ID;
	}
	/**
	 * @return ID This method Return packet id 
	  */
	public int getID()
	{
		return ID;
	}
	/**
	 * @return This method Return packet all details 
	  */
	public String toString() {
		return operation + " " + data;
	}

	
	
	
	
}
