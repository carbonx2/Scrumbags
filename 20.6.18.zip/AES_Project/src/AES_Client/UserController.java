package AES_Client;

import java.io.IOException;
import java.util.ArrayList;

import AES_Classes.Packet;
import AES_Classes.SchoolManager;
import AES_Classes.Student;
import AES_Classes.Teacher;
import AES_Classes.User;
import ClientGUI.MainClient;

public class UserController {


	/**
	   * This method create login of user
	   *
	   * @param login list of user details
	   * Build packet with the login details and LogIn request
	   * Send this packet to server by client 
	   * @return answer with status of login and new user in some kind (TEACHER,STUDENT,MANGER)
	   */
	public static ArrayList<Object> loginUser(ArrayList<String> login) {
		
		Packet packet=new Packet("LogIn", login); 
		int requestID=MainClient.client.sendToServerAJ(packet);
		ArrayList<Object> answer = new ArrayList<Object>();
		Packet response = MainClient.client.getResponse(requestID);
		answer.add(response.getOperation());
		answer.add(response.getData());
        return answer;
		
	}
	/**
	   * This method create logout of user
	   *
	   * @param id  The id of the user
	   * Build packet with the user id and LogOut request
	   * Send this packet to server by client 
	   */
	public static void logoutUser(String id){
		
		Packet packet = new Packet("LogOut",id);
		
		int requestID = MainClient.client.sendToServerAJ(packet);
		MainClient.client.getResponse(requestID);	
	}
	
	
		public static ArrayList<User> getUsersList()
		{
			int ID=MainClient.client.sendToServerAJ(new Packet("GetUsersList",null));
			return (ArrayList<User>) MainClient.client.getResponse(ID).getData();
		}
		public static ArrayList<Student> getstudentList()
		{
			int ID=MainClient.client.sendToServerAJ(new Packet("GetStudentList",null));
			return (ArrayList<Student>) MainClient.client.getResponse(ID).getData();
		}
		public static ArrayList<Teacher> getTeachersList()
		{
			int ID=MainClient.client.sendToServerAJ(new Packet("GetTeachersList",null));
			return (ArrayList<Teacher>) MainClient.client.getResponse(ID).getData();
		}
		public static ArrayList<SchoolManager> getManagerList()
		{
			int ID=MainClient.client.sendToServerAJ(new Packet("GetManagerList",null));
			return (ArrayList<SchoolManager>) MainClient.client.getResponse(ID).getData();
		}
	}

