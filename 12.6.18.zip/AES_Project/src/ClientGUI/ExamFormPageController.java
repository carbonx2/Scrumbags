package ClientGUI;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

import AES_Classes.QuestionInExam;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.layout.VBox;

public class ExamFormPageController implements Initializable{ 

	private ArrayList<QuestionPaneController> controllers;
	@FXML
	private VBox OurVBox;

	public void addQuestion(QuestionInExam question, int numberOfQuestions) {
		numberOfQuestions++;
		FXMLLoader loader = new FXMLLoader();
		Node node;
		try {
			node = loader.load(getClass().getResource("QuestionPane.fxml").openStream());
			QuestionPaneController controller = loader.getController();
			controller.setQuestion(question, numberOfQuestions);
			controllers.add(controller);
			OurVBox.getChildren().add(node);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void setNotes() {
		for (QuestionPaneController controller : controllers) {
			controller.setNotes();
		}
	}
	
	public void setScores() {
		for (QuestionPaneController controller : controllers) {
			controller.setScore();
		}
	}
	
	public int getScores() {
		int score=0;
		for (QuestionPaneController controller : controllers)
			score+=controller.getScore();
		return score;
	}
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		// TODO Auto-generated method stub
		controllers = new ArrayList<QuestionPaneController>();
	}
	
}

