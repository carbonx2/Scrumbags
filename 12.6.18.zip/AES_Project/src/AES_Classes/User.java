package AES_Classes;

import java.io.Serializable;

import AES_Classes.Permission;

public class User implements Serializable {
	String ID;
	String password;
	int permission;

	public User(String ID, String password, Permission permission) {
		super();
		this.ID = ID;
		this.password = password;
		this.permission = permission.ordinal();
	}

	public User(User user)
	{
		this.ID = user.getID();
		this.password = user.password;
		this.permission = user.getPermission();
	}
	public String getID() {
		return ID;
	}

	public String getPassword()
	{
		return password;
	}
	public int getPermission() {
		return permission;
	}

}
