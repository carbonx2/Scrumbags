package AES_Classes;

import java.io.Serializable;

public class SchoolManger extends User implements Serializable{
	
	String firstName;
	String lastName;
	
	public SchoolManger(String ID, String password,String firstname , String lastname) {
		super(ID, password, Permission.MANAGER);
		this.firstName=firstname;
		this.lastName=lastname;
	}
	
	
	public String toString()
	{
		return "Name:"+firstName+" Last Name:"+lastName+" ID:"+getID()+" Permission:"+getPermission();
	}
	
	public String getName()
	{
		return firstName+" "+lastName;
	}

}
