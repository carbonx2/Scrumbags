package AES_Server;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashSet;

import AES_Classes.Course;
import AES_Classes.Permission;
import AES_Classes.SchoolManger;
import AES_Classes.Student;
import AES_Classes.Subject;
import AES_Classes.Teacher;
import AES_Classes.User;

public class UserController {

public static User logIn(String ID, String password, String IP)
	{
	
		try {
			Statement stmt1= Server.conn.createStatement();
			Statement stmt2=Server.conn.createStatement();		
			ResultSet rs=stmt1.executeQuery("SELECT * FROM USERS WHERE ID='"+ID+"' AND Password='"+password+"' ;");	
			
			if(rs.next()) {				
				ResultSet rs1;
				switch (rs.getString(3))
				{
				case "1":					
					rs1=stmt2.executeQuery("SELECT * FROM STUDENTS WHERE ID='"+ID+"';");
					rs1.next();
					Student student =new Student(rs.getString(1),rs.getString(2),rs1.getString(2),rs1.getString(3));
					return student;	
				case "2":
					rs1=stmt2.executeQuery("SELECT * FROM TEACHERS WHERE ID='"+ID+"';");
					rs1.next();
					Teacher teacher =new Teacher(rs.getString(1),rs.getString(2),rs1.getString(2),rs1.getString(3),CourseAndSubjectController.getTeacherSubjects(ID),CourseAndSubjectController.getTeacherCourses(ID));
					return teacher;	
					
				case "3":
					rs1=stmt2.executeQuery("SELECT * FROM SCHOOLMENGERS WHERE ID='"+ID+"';");
					rs1.next();
					SchoolManger manger =new SchoolManger(rs.getString(1),rs.getString(2),rs1.getString(2),rs1.getString(3));
					return manger;	
				}
							
					
				}
		} 
			catch (SQLException e) {
				System.out.println(e);
				return new User("0", "0", Permission.NONE); 
		}
		return null;
	}
	


	public static void logOut(String ID)
	{ 
		
			Statement stnt;
			try {
				stnt = Server.conn.createStatement();
				stnt.executeUpdate("DELETE FROM OnlineUsers WHERE ID='"+ID+"';");
			} catch (SQLException e) {				
				e.printStackTrace();
			}
			
		
		
	}
	
	

}
