-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: localhost    Database: aes
-- ------------------------------------------------------
-- Server version	8.0.11

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `executedexams`
--

DROP TABLE IF EXISTS `executedexams`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `executedexams` (
  `ID` int(11) NOT NULL,
  `ExecutionCode` varchar(4) NOT NULL,
  `Exam` varchar(6) DEFAULT NULL,
  `Date` varchar(45) DEFAULT NULL,
  `Executor` varchar(9) DEFAULT NULL,
  `AllocatedTime` int(11) DEFAULT NULL,
  `NumberOfExaminees` int(11) DEFAULT NULL,
  `F` int(11) DEFAULT NULL,
  `DNF` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `FK_Exam_idx` (`Exam`),
  KEY `FK_Executor_idx` (`Executor`),
  CONSTRAINT `FK1_Exam` FOREIGN KEY (`Exam`) REFERENCES `exams` (`id`),
  CONSTRAINT `FK_Executor` FOREIGN KEY (`Executor`) REFERENCES `teachers` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `executedexams`
--

LOCK TABLES `executedexams` WRITE;
/*!40000 ALTER TABLE `executedexams` DISABLE KEYS */;
INSERT INTO `executedexams` VALUES (0,'1234','063200','Sun Jun 24 03:09:04 IDT 2018','204677736',3,8,6,2),(9,'6666','031700','Tue Jun 26 12:48:27 IDT 2018','204677736',5,0,0,0),(10,'7654','063400','Sun Jun 24 03:14:21 IDT 2018','307862557',10,0,0,0),(11,'8989','010700','Sun Jun 24 03:14:30 IDT 2018','307862557',3,0,0,0),(12,'1111','063200','Sun Jun 24 03:16:54 IDT 2018','313740664',3,0,0,0),(13,'6565','020500','Sun Jun 24 03:17:05 IDT 2018','313740664',4,11,10,1),(14,'8787','010700','Sun Jun 24 03:17:13 IDT 2018','313740664',3,12,11,1),(19,'4567','010800','Mon Jun 25 08:51:54 IDT 2018','201232055',10,13,13,0),(20,'6666','052900','Mon Jun 25 09:03:39 IDT 2018','314134230',10,21,21,0),(28,'1212','031701','Mon Jun 25 15:34:02 IDT 2018','204677736',5,12,11,1);
/*!40000 ALTER TABLE `executedexams` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-06-26 13:13:30
