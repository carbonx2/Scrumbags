-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: localhost    Database: aes
-- ------------------------------------------------------
-- Server version	8.0.11

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `finishedexams`
--

DROP TABLE IF EXISTS `finishedexams`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `finishedexams` (
  `ID` int(11) NOT NULL,
  `Exam` varchar(6) DEFAULT NULL,
  `Examinee` varchar(9) NOT NULL,
  `StartTime` varchar(45) DEFAULT NULL,
  `FinishTime` varchar(45) DEFAULT NULL,
  `Completion Time` int(11) DEFAULT NULL,
  `SubmissionType` varchar(45) DEFAULT NULL,
  `Grade` int(11) DEFAULT NULL,
  `FinalGrade` int(11) DEFAULT NULL,
  `GradeNote` text,
  `Type` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`ID`,`Examinee`),
  KEY `FK3_Exam_idx` (`Exam`),
  KEY `FK_Examiniee_idx` (`Examinee`),
  KEY `FK_ID_idx` (`ID`),
  CONSTRAINT `FK3_Exam` FOREIGN KEY (`Exam`) REFERENCES `exams` (`id`),
  CONSTRAINT `FK_Examiniee` FOREIGN KEY (`Examinee`) REFERENCES `students` (`id`),
  CONSTRAINT `FK_ID` FOREIGN KEY (`ID`) REFERENCES `executedexams` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `finishedexams`
--

LOCK TABLES `finishedexams` WRITE;
/*!40000 ALTER TABLE `finishedexams` DISABLE KEYS */;
INSERT INTO `finishedexams` VALUES (0,'063200','188888825','Mon Jun 25 09:18:17 IDT 2018','Mon Jun 25 09:21:18 IDT 2018',3,'Timeout',50,50,'null','Online'),(0,'063200','188888826','Mon Jun 25 09:18:40 IDT 2018','Mon Jun 25 09:19:58 IDT 2018',1,'ByUser',50,50,'null','Online'),(0,'063200','188888827','Mon Jun 25 09:19:37 IDT 2018','Mon Jun 25 09:19:53 IDT 2018',0,'ByUser',50,60,'!!','Online'),(0,'063200','188888829','Mon Jun 25 09:20:26 IDT 2018','Mon Jun 25 09:20:41 IDT 2018',0,'ByUser',100,100,'null','Online'),(0,'063200','188888830','Mon Jun 25 09:21:32 IDT 2018','Mon Jun 25 09:22:56 IDT 2018',1,'ByUser',100,100,'null','Online'),(0,'063200','188888881','Mon Jun 25 09:22:03 IDT 2018','Mon Jun 25 09:25:04 IDT 2018',3,'Timeout',25,25,'null','Online'),(0,'063200','188888883','Mon Jun 25 09:21:03 IDT 2018','Mon Jun 25 09:22:14 IDT 2018',1,'ByUser',75,75,'null','Online'),(0,'063200','188888887','Mon Jun 25 09:22:38 IDT 2018','Mon Jun 25 09:24:18 IDT 2018',1,'ByUser',75,75,'null','Online'),(13,'020500','188888812','Tue Jun 26 12:53:34 IDT 2018','Tue Jun 26 12:53:43 IDT 2018',0,'ByUser',0,-1,'null','Online'),(13,'020500','188888813','Tue Jun 26 12:56:18 IDT 2018','Tue Jun 26 12:56:25 IDT 2018',0,'ByUser',40,-1,'null','Online'),(13,'020500','188888814','Tue Jun 26 12:53:58 IDT 2018','Tue Jun 26 12:54:04 IDT 2018',0,'ByUser',100,-1,'null','Online'),(13,'020500','188888816','Tue Jun 26 12:52:02 IDT 2018','Tue Jun 26 12:56:02 IDT 2018',4,'Timeout',100,-1,'null','Online'),(13,'020500','188888819','Tue Jun 26 12:54:20 IDT 2018','Tue Jun 26 12:54:27 IDT 2018',0,'ByUser',0,-1,'null','Online'),(13,'020500','188888821','Tue Jun 26 12:52:40 IDT 2018','Tue Jun 26 12:52:47 IDT 2018',0,'ByUser',60,-1,'null','Online'),(13,'020500','188888822','Tue Jun 26 12:54:45 IDT 2018','Tue Jun 26 12:55:03 IDT 2018',0,'ByUser',0,-1,'null','Online'),(13,'020500','188888824','Tue Jun 26 12:57:27 IDT 2018','Tue Jun 26 12:57:29 IDT 2018',0,'ByUser',0,-1,'null','Online'),(13,'020500','188888826','Tue Jun 26 12:56:47 IDT 2018','Tue Jun 26 12:56:54 IDT 2018',0,'ByUser',100,-1,'null','Online'),(13,'020500','188888828','Tue Jun 26 12:55:56 IDT 2018','Tue Jun 26 12:58:01 IDT 2018',2,'ByUser',0,-1,'null','Online'),(13,'020500','188888830','Tue Jun 26 12:53:05 IDT 2018','Tue Jun 26 12:53:11 IDT 2018',0,'ByUser',40,-1,'null','Online'),(14,'010700','188888811','Tue Jun 26 11:50:39 IDT 2018','Tue Jun 26 11:50:49 IDT 2018',0,'ByUser',50,-1,'null','Online'),(14,'010700','188888815','Tue Jun 26 11:53:39 IDT 2018','Tue Jun 26 11:53:48 IDT 2018',0,'ByUser',75,-1,'null','Online'),(14,'010700','188888816','Tue Jun 26 11:54:04 IDT 2018','Tue Jun 26 11:54:12 IDT 2018',0,'ByUser',25,-1,'null','Online'),(14,'010700','188888817','Tue Jun 26 11:51:16 IDT 2018','Tue Jun 26 11:54:17 IDT 2018',3,'Timeout',0,-1,'null','Online'),(14,'010700','188888820','Tue Jun 26 11:53:07 IDT 2018','Tue Jun 26 11:53:14 IDT 2018',0,'ByUser',25,-1,'null','Online'),(14,'010700','188888826','Tue Jun 26 11:52:41 IDT 2018','Tue Jun 26 11:52:52 IDT 2018',0,'ByUser',75,-1,'null','Online'),(14,'010700','188888827','Tue Jun 26 11:48:50 IDT 2018','Tue Jun 26 11:51:20 IDT 2018',2,'ByUser',75,-1,'null','Online'),(14,'010700','188888828','Tue Jun 26 11:52:13 IDT 2018','Tue Jun 26 11:52:24 IDT 2018',0,'ByUser',100,-1,'null','Online'),(14,'010700','188888830','Tue Jun 26 11:51:46 IDT 2018','Tue Jun 26 11:51:56 IDT 2018',0,'ByUser',75,-1,'null','Online'),(14,'010700','188888880','Tue Jun 26 11:49:18 IDT 2018','Tue Jun 26 11:49:31 IDT 2018',0,'ByUser',75,-1,'null','Online'),(14,'010700','188888884','Tue Jun 26 11:49:47 IDT 2018','Tue Jun 26 11:50:00 IDT 2018',0,'ByUser',75,-1,'null','Online'),(14,'010700','188888888','Tue Jun 26 11:50:14 IDT 2018','Tue Jun 26 11:50:24 IDT 2018',0,'ByUser',50,-1,'null','Online'),(19,'010800','188888810','Tue Jun 26 11:38:49 IDT 2018','Tue Jun 26 11:39:01 IDT 2018',0,'ByUser',20,20,'null','Online'),(19,'010800','188888812','Tue Jun 26 11:39:16 IDT 2018','Tue Jun 26 11:39:28 IDT 2018',0,'ByUser',20,45,'hh','Online'),(19,'010800','188888815','Tue Jun 26 11:39:48 IDT 2018','Tue Jun 26 11:39:59 IDT 2018',0,'ByUser',10,15,'jj','Online'),(19,'010800','188888817','Tue Jun 26 11:40:13 IDT 2018','Tue Jun 26 11:40:24 IDT 2018',0,'ByUser',10,14,'jj','Online'),(19,'010800','188888819','Tue Jun 26 11:40:43 IDT 2018','Tue Jun 26 11:40:45 IDT 2018',0,'ByUser',0,0,'null','Online'),(19,'010800','188888821','Tue Jun 26 11:40:59 IDT 2018','Tue Jun 26 11:44:01 IDT 2018',3,'ByUser',10,10,'null','Online'),(19,'010800','188888825','Tue Jun 26 11:42:17 IDT 2018','Tue Jun 26 11:42:34 IDT 2018',0,'ByUser',65,100,'Bounos','Online'),(19,'010800','188888827','Tue Jun 26 11:43:28 IDT 2018','Tue Jun 26 11:43:55 IDT 2018',0,'ByUser',80,80,'null','Online'),(19,'010800','188888880','Tue Jun 26 11:35:52 IDT 2018','Tue Jun 26 11:44:35 IDT 2018',8,'ByUser',30,30,'null','Online'),(19,'010800','188888882','Tue Jun 26 11:36:29 IDT 2018','Tue Jun 26 11:36:43 IDT 2018',0,'ByUser',10,10,'null','Online'),(19,'010800','188888884','Tue Jun 26 11:36:57 IDT 2018','Tue Jun 26 11:37:12 IDT 2018',0,'ByUser',40,40,'null','Online'),(19,'010800','188888886','Tue Jun 26 11:37:26 IDT 2018','Tue Jun 26 11:37:45 IDT 2018',0,'ByUser',45,45,'null','Online'),(19,'010800','188888888','Tue Jun 26 11:38:01 IDT 2018','Tue Jun 26 11:38:17 IDT 2018',0,'ByUser',40,40,'null','Online'),(20,'052900','188888810','Tue Jun 26 10:50:14 IDT 2018','Tue Jun 26 10:50:28 IDT 2018',0,'ByUser',30,-1,'null','Online'),(20,'052900','188888811','Mon Jun 25 17:20:39 IDT 2018','Mon Jun 25 17:21:28 IDT 2018',0,'ByUser',40,-1,'null','Online'),(20,'052900','188888812','Tue Jun 26 10:50:54 IDT 2018','Tue Jun 26 10:51:05 IDT 2018',0,'ByUser',60,-1,'null','Online'),(20,'052900','188888813','Mon Jun 25 17:21:12 IDT 2018','Mon Jun 25 17:23:01 IDT 2018',1,'ByUser',50,-1,'null','Online'),(20,'052900','188888814','Tue Jun 26 10:51:20 IDT 2018','Tue Jun 26 10:51:35 IDT 2018',0,'ByUser',0,-1,'null','Online'),(20,'052900','188888815','Mon Jun 25 17:21:44 IDT 2018','Mon Jun 25 17:21:58 IDT 2018',0,'ByUser',20,-1,'null','Online'),(20,'052900','188888816','Tue Jun 26 10:51:49 IDT 2018','Tue Jun 26 10:52:09 IDT 2018',0,'ByUser',0,-1,'null','Online'),(20,'052900','188888817','Mon Jun 25 17:22:11 IDT 2018','Mon Jun 25 17:22:23 IDT 2018',0,'ByUser',10,-1,'null','Online'),(20,'052900','188888818','Tue Jun 26 10:52:26 IDT 2018','Tue Jun 26 10:52:40 IDT 2018',0,'ByUser',0,-1,'null','Online'),(20,'052900','188888820','Tue Jun 26 10:52:56 IDT 2018','Tue Jun 26 10:53:09 IDT 2018',0,'ByUser',30,-1,'null','Online'),(20,'052900','188888822','Tue Jun 26 10:53:25 IDT 2018','Tue Jun 26 10:53:40 IDT 2018',0,'ByUser',40,-1,'null','Online'),(20,'052900','188888824','Tue Jun 26 10:53:57 IDT 2018','Tue Jun 26 10:54:14 IDT 2018',0,'ByUser',60,-1,'null','Online'),(20,'052900','188888826','Tue Jun 26 10:54:39 IDT 2018','Tue Jun 26 10:54:50 IDT 2018',0,'ByUser',40,-1,'null','Online'),(20,'052900','188888828','Tue Jun 26 10:55:07 IDT 2018','Tue Jun 26 10:55:20 IDT 2018',0,'ByUser',50,-1,'null','Online'),(20,'052900','188888830','Tue Jun 26 10:55:40 IDT 2018','Tue Jun 26 10:55:53 IDT 2018',0,'ByUser',10,-1,'null','Online'),(20,'052900','188888881','Mon Jun 25 17:17:45 IDT 2018','Mon Jun 25 17:18:33 IDT 2018',0,'ByUser',70,-1,'null','Online'),(20,'052900','188888883','Mon Jun 25 17:18:30 IDT 2018','Mon Jun 25 17:19:49 IDT 2018',1,'ByUser',40,-1,'null','Online'),(20,'052900','188888885','Mon Jun 25 17:18:49 IDT 2018','Mon Jun 25 17:19:17 IDT 2018',0,'ByUser',40,-1,'null','Online'),(20,'052900','188888887','Mon Jun 25 17:19:33 IDT 2018','Mon Jun 25 17:20:25 IDT 2018',0,'ByUser',60,-1,'null','Online'),(20,'052900','188888888','Tue Jun 26 10:48:52 IDT 2018','Tue Jun 26 10:56:01 IDT 2018',7,'ByUser',60,-1,'null','Online'),(20,'052900','188888889','Mon Jun 25 17:20:12 IDT 2018','Mon Jun 25 17:21:00 IDT 2018',0,'ByUser',10,-1,'null','Online'),(28,'031701','188888811','Mon Jun 25 15:41:54 IDT 2018','Mon Jun 25 15:42:00 IDT 2018',0,'ByUser',75,75,'null','Online'),(28,'031701','188888812','Mon Jun 25 15:42:16 IDT 2018','Mon Jun 25 15:43:06 IDT 2018',0,'ByUser',50,50,'null','Online'),(28,'031701','188888813','Mon Jun 25 15:40:30 IDT 2018','Mon Jun 25 15:43:21 IDT 2018',2,'ByUser',75,75,'null','Online'),(28,'031701','188888815','Mon Jun 25 15:40:04 IDT 2018','Mon Jun 25 15:40:13 IDT 2018',0,'ByUser',50,50,'null','Online'),(28,'031701','188888817','Mon Jun 25 15:39:34 IDT 2018','Mon Jun 25 15:39:43 IDT 2018',0,'ByUser',75,75,'null','Online'),(28,'031701','188888822','Mon Jun 25 15:42:53 IDT 2018','Mon Jun 25 15:43:04 IDT 2018',0,'ByUser',75,55,'ko','Online'),(28,'031701','188888826','Mon Jun 25 15:39:04 IDT 2018','Mon Jun 25 15:39:13 IDT 2018',0,'ByUser',75,75,'null','Online'),(28,'031701','188888828','Mon Jun 25 15:38:31 IDT 2018','Mon Jun 25 15:38:42 IDT 2018',0,'ByUser',100,100,'null','Online'),(28,'031701','188888880','Mon Jun 25 15:37:18 IDT 2018','Mon Jun 25 15:37:50 IDT 2018',0,'ByUser',25,10,'copy!','Online'),(28,'031701','188888881','Mon Jun 25 15:41:25 IDT 2018','Mon Jun 25 15:41:34 IDT 2018',0,'ByUser',50,50,'null','Online'),(28,'031701','188888888','Mon Jun 25 15:34:54 IDT 2018','Mon Jun 25 15:37:29 IDT 2018',2,'ByUser',25,25,'null','Online'),(28,'031701','188888889','Mon Jun 25 15:35:42 IDT 2018','Mon Jun 25 15:40:43 IDT 2018',5,'Timeout',25,10,'copy!','Online');
/*!40000 ALTER TABLE `finishedexams` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-06-26 13:13:30
