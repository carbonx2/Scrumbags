-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: localhost    Database: aes
-- ------------------------------------------------------
-- Server version	8.0.11

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `exams`
--

DROP TABLE IF EXISTS `exams`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exams` (
  `ID` varchar(6) NOT NULL,
  `Course` varchar(2) DEFAULT NULL,
  `Subject` varchar(2) DEFAULT NULL,
  `Author` varchar(9) DEFAULT NULL,
  `CreationDate` varchar(10) DEFAULT NULL,
  `ExamTime` int(11) DEFAULT NULL,
  `Note` text,
  PRIMARY KEY (`ID`),
  KEY `eSubject_idx` (`Subject`),
  KEY `eCourse_idx` (`Course`),
  KEY `FK_Author_idx` (`Author`),
  CONSTRAINT `FK_Author` FOREIGN KEY (`Author`) REFERENCES `teachers` (`id`),
  CONSTRAINT `FK_Course` FOREIGN KEY (`Course`) REFERENCES `courses` (`id`),
  CONSTRAINT `FK_Subject` FOREIGN KEY (`Subject`) REFERENCES `subjects` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exams`
--

LOCK TABLES `exams` WRITE;
/*!40000 ALTER TABLE `exams` DISABLE KEYS */;
INSERT INTO `exams` VALUES ('200000','00','20','313740664','06\\03\\2018',180,'On a dark desert highway, cool wind in my hairWarm smell of colitas, rising up through the airUp ahead in the distance, I saw a shimmering lightMy head grew heavy and my sight grew dimI had to stop for the night.There she stood in the doorway;I heard the mission bellAnd I was thinking to myself\'This could be heaven or this could be Hell\'Then she lit up a candle and she showed me the wayThere were voices down the corridor,I thought I heard them sayWelcome to the Hotel CaliforniaSuch a lovely place (such a lovely place)Such a lovely face.Plenty of room at the Hotel CaliforniaAny time of year (any time of year) you can find it hereHer mind is Tiffany-twisted, she got the Mercedes bendsShe got a lot of pretty, pretty boys, that she calls friendsHow they dance in the courtyard, sweet summer sweatSome dance to remember, some dance to forgetSo I called up the Captain,\'Please bring me my wine\'He said, \'we haven\'t had that spirit here since nineteen sixty-nine\'And still those voices are calling from far away,Wake you '),('200001','00','20','313740664','09/06/2018',50,'hahaha'),('200002','00','20','313740664','09/06/2018',0,'');
/*!40000 ALTER TABLE `exams` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-06-09 17:37:31
