package Client;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Toolkit;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import Classes.Packet;
import Classes.Question;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import java.awt.Component;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.ArrayList;
import java.awt.event.ActionEvent;

public class MainFrame extends JFrame {
	public static Client client;
	final static int DEFAULT_PORT = 5555;
	public static JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public MainFrame() {
	    super("AES");
	    try {
		    client= new Client("localhost", DEFAULT_PORT);
	    }
	    catch(Exception e)
	    {
	    	System.out.println(e.getMessage());
	    }
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		LoginPanel panel= new LoginPanel();		
		contentPane = new JPanel();
		contentPane.setPreferredSize(new Dimension(773, 448));
		setContentPane(contentPane);
		contentPane.setLayout(new BorderLayout(0, 0));
		contentPane.add(panel, BorderLayout.CENTER);		
		this.pack();		
		Set_Location();
        setResizable(false);  
	}
	 
	
	
	public void Set_Location()
    {
        Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
        this.setLocation(dim.width/2-this.getSize().width/2, dim.height/2-this.getSize().height/2);
    }
	
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MainFrame frame = new MainFrame();
					frame.setVisible(true);					
					frame.pack();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
		
		
		   

		
	}

}
