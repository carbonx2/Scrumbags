package Classes;

import java.io.Serializable;

public class Author implements Serializable {
	String ID;
	String name;
	
	
	public Author(String ID, String name) {
		this.ID = ID;
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public String getID() { 
		return ID;
	}
	
	public String toString()
	{
		return ID+" "+name;
	}
}
