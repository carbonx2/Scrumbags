package Classes;

import java.io.Serializable;

import Classes.Permission;

public class Teacher extends User implements Serializable {
	String firstName;
	String lastName;
	
	public Teacher(String ID, String password, String firstName, String lastName) {
		super(ID,password,Permission.TEACHER);
		this.firstName=firstName;
		this.lastName=lastName;
	}
	
	public String toString()
	{
		return "Name:"+firstName+" Last Name:"+lastName+" ID:"+getID()+" Permission:"+getPermission();
	}
	
	public String getName()
	{
		return firstName+" "+lastName;
	} 

}
